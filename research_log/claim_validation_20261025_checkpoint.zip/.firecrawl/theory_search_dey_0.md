Title:

Content selection saved. Describe the issue below:

Description:

![](https://arxiv.org/static/base/1.0.1/images/icons/smileybones-small.svg)arXiv is now an independent nonprofit! [Learn more](https://info.arxiv.org/about) ×

[License: arXiv.org perpetual non-exclusive license](https://info.arxiv.org/help/license/index.html#licenses-available)

arXiv:2007.15192v4 \[math.OC\] 16 Sep 2021

# Branch-and-Bound Solves Random Binary IPs in Polytime

The contributions of this manuscript overlap with those of \[ [16](https://arxiv.org/html/2007.15192v4#bib.bib16 "")\]. The differences are noted in the final paragraph of Section [1](https://arxiv.org/html/2007.15192v4#S1 "1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").

Santanu S. Dey
††thanks: santanu.dey@isye.gatech.eduAffiliation: School of Industrial and Systems Engineering, Georgia Institute of Technology
Yatharth Dubey
††thanks: yatharthdubey7@gatech.eduAffiliation: School of Industrial and Systems Engineering, Georgia Institute of Technology
Marco Molinaro
††thanks: molinaro@inf.puc-rio.brAffiliation: Computer Science Department, Pontifical Catholic University of Rio de Janeiro

###### Abstract

Branch-and-bound is the workhorse of all state-of-the-art mixed integer linear programming (MILP) solvers. These implementations of branch-and-bound typically use variable branching, that is, the child nodes are obtained by fixing some variable to 00 in one node and to 11 in the other node. Even though modern MILP solvers are able to solve very large-scale instances efficiently, relatively little attention has been given to understanding why the underlying branch-and-bound algorithm performs so well. In this paper, our goal is to theoretically analyze the performance of the standard variable branching based branch-and-bound algorithm. In order to avoid the exponential worst-case lower bounds, we follow the common idea of considering random instances. More precisely, we consider random integer programs where the entries of the coefficient matrix and the objective function are randomly sampled.

Our main result is that with good probability branch-and-bound with variable branching explores only a polynomial number of nodes to solve these instances, for a fixed number of constraints. To the best of our knowledge this is the first known such result for a standard version of branch-and-bound. We believe that this result provides an
indication as to why branch-and-bound with variable branching works so well in practice.

## 1 Introduction

The branch-and-bound algorithm, first proposed by Land and Doig in \[ [21](https://arxiv.org/html/2007.15192v4#bib.bib21 "")\], is the workhorse of all modern state-of-the-art mixed integer linear programming (MILP) solvers. As is well known, the branch-and-bound algorithm searches the solution space by recursively partitioning it. The progress of the algorithm is monitored by maintaining a “tree”. Each node of the tree corresponds to a linear program (LP) solved, and in particular, the root node corresponds to the LP relaxation of the integer program. After solving the LP corresponding to a node, the feasible region of the LP is partitioned into two subproblems (which correspond to the child nodes of the given node), so that the fractional optimal solution of the LP is not included in either subproblem, but any integer feasible solution contained in the feasible region of the LP is included in one of the two subproblems. This is accomplished by adding an inequality of the form π​x≤π0\\pi x\\leq\\pi\_{0} to first subproblem and the inequality π⊤​x≥π0+1\\pi^{\\top}x\\geq\\pi\_{0}+1 to the second subproblem, where π\\pi is an integer vector and π0\\pi\_{0} is an integer scalar. The process of partitioning at a node stops if (i) the LP at the node is infeasible, (ii) the LP’s optimal solution is integer feasible, or (iii) the LP’s optimal objective function value is worse than an already known integer feasible solution. These three conditions are sometimes referred to as the rules for pruning a node. The algorithm terminates when there are no more “open nodes” to process, i.e. all nodes have been pruned. A branch-and-bound algorithm is completely described by fixing a rule for partitioning the feasible region at each node and a rule for selecting which open node should be solved and branched on next. See  \[ [31](https://arxiv.org/html/2007.15192v4#bib.bib31 ""), [12](https://arxiv.org/html/2007.15192v4#bib.bib12 "")\] for more discussion on the branch-and-bound algorithm.

In 1983, Lenstra \[ [23](https://arxiv.org/html/2007.15192v4#bib.bib23 "")\] showed that general integer programs can be solved in polynomial time in fixed dimension. This algorithm, which is essentially a branch-and-bound algorithm, uses tools from geometry of numbers, in particular the lattice basis reduction algorithm \[ [22](https://arxiv.org/html/2007.15192v4#bib.bib22 "")\] to decide on π\\pi for partitioning the feasible region. Pataki et al. \[ [26](https://arxiv.org/html/2007.15192v4#bib.bib26 "")\] proved that most random packing integer programs can be solved at the root-node using a partitioning scheme similar to the one proposed by Lenstra \[ [23](https://arxiv.org/html/2007.15192v4#bib.bib23 "")\]. While there are some implementations of such general partitioning rules \[ [1](https://arxiv.org/html/2007.15192v4#bib.bib1 "")\], all state-of-the-art solvers use a much simpler (and potentially significantly weaker and restrictive) partitioning rule for solving binary IPs, namely: If xjx\_{j} is fractional in the optimal solution of the LP of a given node, then one child node is obtained by the addition of the constraint xj≤0x\_{j}\\leq 0 and the other with the constraint xj≥1x\_{j}\\geq 1 (i.e., π=ej\\pi=e\_{j}, the unit vector in direction jj for some jj in {1,…,n}\\{1,\\dots,n\\}). The rule for deciding how to partition the feasible region at a node then reduces to choosing which fractional variable should be branched on. This kind of partitioning rule is henceforth referred to as _variable branching_.

As mentioned above, all state-of-the-art MILP solvers use variable branching, which has proven itself to be very successful in practice \[ [7](https://arxiv.org/html/2007.15192v4#bib.bib7 "")\]. Part of this success could be attributed to the fact that variable branching helps maintain the sparsity structure of the original LP relaxation, which can help in solving LPs in the branch-bound-tree faster (see \[ [11](https://arxiv.org/html/2007.15192v4#bib.bib11 ""), [30](https://arxiv.org/html/2007.15192v4#bib.bib30 ""), [14](https://arxiv.org/html/2007.15192v4#bib.bib14 ""), [15](https://arxiv.org/html/2007.15192v4#bib.bib15 "")\]). Additionally, while in the worst-case there can be exponentially many nodes in the branch-and-bound tree (see  \[ [10](https://arxiv.org/html/2007.15192v4#bib.bib10 ""), [13](https://arxiv.org/html/2007.15192v4#bib.bib13 "")\] for explicit examples for variable branching based branch-and-bound), a major reason for its success is that in practice the size of the tree can be quite small \[ [9](https://arxiv.org/html/2007.15192v4#bib.bib9 "")\]. To the best of our knowledge there is no theoretical study of branch-and-bound algorithm using variable branching that attempts to explain its incredible success in practice.

In order to avoid worst-case lower bounds, a standard idea is to consider random instances. A famous example is the study of smoothed analysis for the simplex method \[ [27](https://arxiv.org/html/2007.15192v4#bib.bib27 "")\]. In this paper, we provide what seems to be the first analysis of the branch-and-bound algorithm with variable branching for a set of random instances. More precisely, we consider problems of the form

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | max\\displaystyle\\max | ⟨c,x⟩\\displaystyle\\quad\\langle c,x\\rangle |  |
|  | s.t. | A​x≤b\\displaystyle\\quad Ax\\leq b |  | (IP) |
|  |  | x∈{0,1}n.\\displaystyle\\quad x\\in\\{0,1\\}^{n}. |  |

By a random instance of IP we mean one where we draw the entries of the constraint matrix A∈ℝm×nA\\in\\mathbb{R}^{m\\times n} (m≪nm\\ll n) and the objective vector cc uniformly from \[0,1\]\[0,1\] independently. For the right-hand-side, we will use bj=βj⋅nb\_{j}=\\beta\_{j}\\cdot n, where βj∈(0,12)\\beta\_{j}\\in(0,\\frac{1}{2}) for j∈{1,…,m}j\\in\\{1,\\dots,m\\}. (The case when βj\\beta\_{j} is high is less interesting since all items fit with probability 1 as n→∞n\\rightarrow\\infty and mm is fixed.) We show that if the number of constraints mm is fixed, then the branch-and-bound tree with variable branching has at most polynomial number of nodes with good probability. More precisely, we show the following result.

###### Theorem 1.

Consider a branch-and-bound algorithm using the following rules:

- •


Partitioning rule: Variable branching, where any fractional variable can be used to branch on.

- •


Node selection rule: Select a node with largest LP value as the next node to branch on.


Consider n≥m+1n\\geq m+1 and a random instance of the problem IP​(b)\\textrm{IP}(b) where bj=βj⋅nb\_{j}=\\beta\_{j}\\cdot n and βj∈(0,1/2)\\beta\_{j}\\in(0,1/2) for j∈{1,…,n}j\\in\\{1,\\ldots,n\\}. Then with probability at least 1−1n−2−α​a¯21-\\frac{1}{n}-2^{-\\alpha\\bar{a}\_{2}}, the branch-and-bound algorithm applied to this random instance produces a tree with at most

|     |     |     |
| --- | --- | --- |
|  | na¯1⋅(m+α​log⁡m)n^{\\bar{a}\_{1}\\cdot(m+\\alpha\\log m)} |  |

nodes for all α≤min⁡{30​m,log⁡na¯2}\\alpha\\leq\\min\\{30m\\,,\\,\\frac{\\log n}{\\bar{a}\_{2}}\\}, where a¯1\\bar{a}\_{1} and a¯2\\bar{a}\_{2} are constant depending only on mm and β\\beta.

We note that the node selection rule used here is called the _best-bound method_ in the literature and often used in practice with minor modifications \[ [24](https://arxiv.org/html/2007.15192v4#bib.bib24 "")\]. This node selection rule is known to guarantee the smallest tree for any fixed partitioning rule \[ [31](https://arxiv.org/html/2007.15192v4#bib.bib31 "")\]. Also notice that Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") does not specify a rule for selecting a fractional variable to branch on and therefore even “adversarial” choices lead to a polynomial sized tree with good probability. This indicates that the tree is likely to be even smaller when one uses a “good” variable selection rule, such as _strong branching_\[ [2](https://arxiv.org/html/2007.15192v4#bib.bib2 "")\]. Another reason for the size of the tree to be even smaller in practice is
that Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") relies only on rule (iii) of pruning, i.e., pruning by bounds, to bound the size of the tree. However, pruning may also occur due to rules (i) (LP infeasibility) or (ii) (integer optimality), thus leading to a
smaller tree size than predicted by Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").

Also notice that while IP is written in packing form (e.g., AA is non-negative), our bounds work for every deterministic binary IP that is “well-behaved”, as discussed in Section [7](https://arxiv.org/html/2007.15192v4#S7 "7 Final remarks ‣ Branch-and-Bound Solves Random Binary IPs in Polytime"). Together with the above observations, we believe Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") provides compelling indication of why branch-and-bound with variable branching works so well in practice.

Finally, we note that random (packing) instances have been considered in several previous studies, and it has been shown that they can be solved in polynomial time with high probability. As mentioned earlier, Pataki et al. \[ [26](https://arxiv.org/html/2007.15192v4#bib.bib26 "")\] proves that random packing integer programs can be solved in polynomial-time; however it uses the very heavy machinery of lattice basis reduction, which is not often used in practice.
Other papers considering random packing problems present algorithms that are custom-made enumeration-based schemes that are not equivalent to the general purpose branch-and-bound algorithm. In particular, Lueker \[ [25](https://arxiv.org/html/2007.15192v4#bib.bib25 "")\] showed that the additive integrality gap for random one-row (i.e. m=1m=1) knapsack instances is O⁡(log2⁡nn)O\\left(\\frac{\\log^{2}n}{n}\\right), and using this property Goldberg and Marchetti-Spaccamela \[ [19](https://arxiv.org/html/2007.15192v4#bib.bib19 "")\] presented a polynomial-time enumeration algorithm for these instances. Beier and Vocking \[ [4](https://arxiv.org/html/2007.15192v4#bib.bib4 ""), [5](https://arxiv.org/html/2007.15192v4#bib.bib5 "")\] showed that the so-called knapsack core algorithm with suitable improvements using enumeration runs in polynomial-time with high probability. Finally, Dyer and Frieze \[ [17](https://arxiv.org/html/2007.15192v4#bib.bib17 "")\] generalize the previous results on integrality gap and enumeration techniques to the random instances we consider here.

There has also been follow-up work to the results presented here. Borst et al. \[ [8](https://arxiv.org/html/2007.15192v4#bib.bib8 "")\] show that, when the data is drawn from a standard Gaussian (as opposed to the uniform distribution studied here), the integrality gap is sufficiently small that branch-and-bound solves problems of this type in npoly​(m)n^{\\text{poly}(m)} nodes. Frieze \[ [18](https://arxiv.org/html/2007.15192v4#bib.bib18 "")\] shows that any branch-and-bound tree solving the asymmetric travelling salesperson problem via the assignment problem relaxation has an exponential number of nodes.

The rest of the paper is organized as follows. Section [2](https://arxiv.org/html/2007.15192v4#S2 "2 Preliminaries ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") presents notation, formalizes the set-up and presents some preliminary results needed. Section [3](https://arxiv.org/html/2007.15192v4#S3 "3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") establishes a key result that the size of branch-and-bound tree can be bounded if one can bound all possible “near optimal” solutions for IP​(b)\\textrm{IP}(b) for varying values of bb. Section [4](https://arxiv.org/html/2007.15192v4#S4 "4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") and Section [5](https://arxiv.org/html/2007.15192v4#S5 "5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") build up machinery to prove that the number of “near optimal” solutions is bounded by a polynomial. Section [6](https://arxiv.org/html/2007.15192v4#S6 "6 Proof of Theorem ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") completes the proof of Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").  In Section [7](https://arxiv.org/html/2007.15192v4#S7 "7 Final remarks ‣ Branch-and-Bound Solves Random Binary IPs in Polytime"), we present an upper bound on the size of branch-and-bound tree for general IPs.

An earlier version of this paper is published in the conference SODA \[ [16](https://arxiv.org/html/2007.15192v4#bib.bib16 "")\]. The current paper is a significant improvement over \[ [16](https://arxiv.org/html/2007.15192v4#bib.bib16 "")\]. Although the main result (Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")) is the same, we have significantly simplified the proofs and sharpened the key take-away result in Section [7](https://arxiv.org/html/2007.15192v4#S7 "7 Final remarks ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") that can be applied to obtain upper bounds on the size of branch-and-bound tree for general IP models: see Corollary [3](https://arxiv.org/html/2007.15192v4#Thmcor3 "Corollary 3. ‣ 7 Final remarks ‣ Branch-and-Bound Solves Random Binary IPs in Polytime"). Comparing with \[ [16](https://arxiv.org/html/2007.15192v4#bib.bib16 "")\], we improve this result by reducing the upper bound on size of branch-and-bound trees by a factor of O⁡(nm)O(n^{m}). Also the analysis in Section [3](https://arxiv.org/html/2007.15192v4#S3 "3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") and Section [4](https://arxiv.org/html/2007.15192v4#S4 "4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") are revamped and simplified as compared the original paper \[ [16](https://arxiv.org/html/2007.15192v4#bib.bib16 "")\].

## 2 Preliminaries

### 2.1 Branch-and-bound

Even though the general branch-and-bound algorithm was already described in the introduction, we describe it again here for maximization-type 0/1 IPs and using variable branching as partitioning rule and best-bound as node selection rule, for a clearer mental image. This is what we will henceforth refer to as _the branch-and-bound_ (BB) algorithm.

The algorithm constructs a tree 𝒯\\mathcal{T} where each node has an associated LP; the LP relaxation of original integer program is the LP of the root node. In each iteration the algorithm:

1. 1.


(Node selection) Selects an unpruned leaf NN with highest optimal LP value in the current tree 𝒯\\mathcal{T}, and obtains an optimal solution x~\\tilde{x} to this LP.

2. 2.


(Pruning by integrality) If x~\\tilde{x} is integral, and hence feasible to the original IP, and has higher value than the current best such feasible solution, it sets x~\\tilde{x} as the current best feasible solution. The node NN is marked as _pruned by integrality_.

3. 3.


(Pruning by infeasibility/bound) Else, if the LP is infeasible or its value is worse than the value of the current best feasible solution, the node NN is marked as _pruned by infeasibility/bound_.

4. 4.


(Branching) Otherwise it selects a coordinate jj where x~\\tilde{x} is fractional and adds two children to NN in the tree: on one of them it adds the constraint xj=0x\_{j}=0 to the LP of NN, and on the other it adds the constraint xj=1x\_{j}=1 instead.


One simple but important property of this best-bound node selection rule is the following. (Note that we do not assume that an optimal IP solution is given in the beginning of the procedure: the algorithm starts with no current best feasible solution, which are only found in step _Pruning by integrality_.)

###### Lemma 1(best-bound node selection).

The execution of branch-and-bound with best-bound node selection rule never branches on a node whose LP value is worse than the optimal value of the original IP.

###### Proof.

Let IP∗\\textrm{IP}^{\*} denote the optimal value of the original IP. Notice that throughout the execution, either:

1. 1.


The current best feasible solution has value IP∗\\textrm{IP}^{\*} (i.e. an optimal integer solution has been found)

2. 2.


The LP of an unpruned leaf contains an optimal integer solution, and so this LP value is at least as good as IP∗\\textrm{IP}^{\*}.


This means that in every iteration, the algorithm cannot _select_ and _branch_ on a leaf with LP value strictly less than IP∗\\textrm{IP}^{\*}: in Case 2 such leaf is not selected (due to the best-bound rule), and in Case 1 such leaf is pruned by infeasibility/bound (and hence not branched on) if selected.
∎

### 2.2 (Random) Packing problems

We will use the following standard observation on the number of fractional coordinates in an optimal solution of the LP relaxation of every instance of IP (see for example Section 17.2 of \[ [28](https://arxiv.org/html/2007.15192v4#bib.bib28 "")\]).

###### Lemma 2.

Consider an instance of IP. Then every LP in the BB tree for this instance has an optimal solution with at most mm fractional coordinates.

###### Proof.

Notice that the LP’s in the BB tree for this instance have the form

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | max\\displaystyle\\max | ⟨c,x⟩\\displaystyle\\quad\\langle c,x\\rangle |  |
|  | s.t. | A​x≤b\\displaystyle\\quad Ax\\leq b |  |
|  |  | xj=0,∀j∈J0\\displaystyle\\quad x\_{j}=0,~~~~~~~~\\forall j\\in J\_{0} |  | (1) |
|  |  | xj=1,∀j∈J1\\displaystyle\\quad x\_{j}=1,~~~~~~~~\\forall j\\in J\_{1} |  |
|  |  | xj∈\[0,1\],∀j∉J0∪J1,\\displaystyle\\quad x\_{j}\\in\[0,1\],~~\\forall j\\notin J\_{0}\\cup J\_{1}, |  |

for disjoint subsets J0,J1⊆\[n\]J\_{0},J\_{1}\\subseteq\[n\] (i.e. the fixings of variables due to the branchings up to this node in the tree).

The feasible region PP in ( [1](https://arxiv.org/html/2007.15192v4#S2.E1 "In Proof. ‣ 2.2 (Random) Packing problems ‣ 2 Preliminaries ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")) is bounded, so there is an optimal solution x∗x^{\*} of the LP that is a vertex of PP. This implies that at least nn of the constraints of the LP are satisfied by x∗x^{\*} at equality. Since there are mm constraints in A​x≤bAx\\leq b, at least n−mn-m of these equalities are of the form xj∗=vjx^{\*}\_{j}=v\_{j} (for some vj∈{0,1}v\_{j}\\in\\{0,1\\}) and so at most mmxj∗x^{\*}\_{j}’s can be fractional.
∎

Recall that the _integrality gap_ of IP is IPGap:=OPT​(LP)−OPT​(IP)\\textsc{IPGap}:=\\textrm{OPT}(\\textrm{LP})-\\textrm{OPT}(\\textrm{IP}), namely the optimal value its LP relaxation LP:=max{⟨c,x⟩:Ax≤b,x∈\[0,1\]n}\\textrm{LP}:=\\max\\{\\langle c,x\\rangle:Ax\\leq b,~x\\in\[0,1\]^{n}\\} minus the optimal IP value. Dyer and Frieze proved the following property that will be crucial for our results: for a random instance of IP (defined right after the definition of IP), the integrality gap is O⁡(log2⁡nnCLOSEO(\\frac{\\log^{2}n}{n}).

###### Theorem 2(Theorem 1 of \[ [17](https://arxiv.org/html/2007.15192v4\#bib.bib17 "")\]).

Consider a vector β∈(0,12)n\\beta\\in(0,\\frac{1}{2})^{n} and let b∈ℝnb\\in\\mathbb{R}^{n} be given by bj=βj⋅nb\_{j}=\\beta\_{j}\\cdot n for j∈{1,…,n}j\\in\\{1,\\ldots,n\\}. Then there are scalars a1,a2≥1a\_{1},a\_{2}\\geq 1 depending only on mm and minj⁡βj\\min\_{j}\\beta\_{j} such that the following holds: for a random instance ℐ\\mathcal{I} of IP

|     |     |     |
| --- | --- | --- |
|  | Pr⁡(IPGap​(ℐ)≥α​a1​log2⁡nn)≤2−α​a2\\displaystyle\\Pr\\bigg(\\textsc{IPGap}(\\mathcal{I})\\geq\\alpha a\_{1}\\,\\frac{\\log^{2}n}{n}\\bigg)~\\leq~2^{-\\alpha a\_{2}} |  |

for all α≤3​log⁡na2\\alpha\\leq\\frac{3\\log n}{a\_{2}}.

### 2.3 Notation

We use the shorthands (n≤k):=∑i=0k(ni)\\binom{n}{\\leq k}:=\\sum\_{i=0}^{k}\\binom{n}{i} and \[n\]:={1,2,…,n}\[n\]:=\\{1,2,\\ldots,n\\}. We also use (\[n\]≤k)\\binom{\[n\]}{\\leq k} to denote the family of all subsets of \[n\]\[n\] of size at most kk. We use AjA^{j} to denote the jjth column of the matrix AA. For any vector x∈ℝnx\\in\\mathbb{R}^{n}, we use x+x^{+} to denote the vector that satisfies xi+=max⁡(0,xi)x^{+}\_{i}=\\max(0,x\_{i}) for all i∈\[n\]i\\in\[n\].

## 3 Branch-and-bound and good integer solutions

In this section we connect the size of the BB tree for any instance of IP and the number of its near-optimal solutions.

To make this precise, first let LP be the LP relaxation of IP

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | max\\displaystyle\\max | ⟨c,x⟩\\displaystyle\\quad\\langle c,x\\rangle |  |
|  | s.t. | A​x≤b\\displaystyle\\quad Ax\\leq b |  | (LP) |
|  |  | x∈\[0,1\]n,\\displaystyle\\quad x\\in\[0,1\]^{n}, |  |

and its Lagrangian relaxation

|     |     |     |
| --- | --- | --- |
|  | minλ≥0⁡maxx∈\[0,1\]n​⟨c,x⟩−λ⊤​(A​x−b)≡minλ≥0⁡max⁡∑j∈\[n\]x∈\[0,1\]n⁡(cj−⟨λ,Aj⟩)​xj+⟨b,λ⟩.\\displaystyle\\min\_{\\lambda\\geq 0}\\max\_{x\\in\[0,1\]^{n}}\\langle c,x\\rangle-\\lambda^{\\top}(Ax-b)\\quad\\equiv\\quad\\min\_{\\lambda\\geq 0}\\max\_{x\\in\[0,1\]^{n}}\\sum\_{j\\in\[n\]}(c\_{j}-\\langle\\lambda,A^{j}\\rangle)x\_{j}+\\langle b,\\lambda\\rangle. |  |

Let (x∗,λ∗)(x^{\*},\\lambda^{\*}) be a saddle point of this Lagrangian, namely

|     |     |     |     |
| --- | --- | --- | --- |
|  | x∗\\displaystyle x^{\*} | =argmax⁡{∑j∈\[n\](cj−⟨λ∗,Aj⟩)​xj+⟨b,λ∗⟩:x∈\[0,1\]n}\\displaystyle=\\argmax\\bigg\\{\\sum\_{j\\in\[n\]}(c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle)x\_{j}+\\langle b,\\lambda^{\*}\\rangle~:~x\\in\[0,1\]^{n}\\bigg\\} |  |
|  | λ∗\\displaystyle\\lambda^{\*} | =argmin⁡{∑j∈\[n\](cj−⟨λ,Aj⟩)​xj∗+⟨b,λ⟩:λ≥0}.\\displaystyle=\\argmin\\bigg\\{\\sum\_{j\\in\[n\]}(c\_{j}-\\langle\\lambda,A^{j}\\rangle)x^{\*}\_{j}+\\langle b,\\lambda\\rangle~:~\\lambda\\geq 0\\bigg\\}. |  |

Recall that this saddle point solution has the same value as OPT​(LP)\\textrm{OPT}(\\textrm{LP})\[ [6](https://arxiv.org/html/2007.15192v4#bib.bib6 "")\].
Also notice that cj−⟨λ∗,Aj⟩c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle can be thought as the reduced cost of variable xjx\_{j} and by optimality of x∗x^{\*}

|     |     |     |     |
| --- | --- | --- | --- |
|  | xj∗={1 if ​cj−⟨λ∗,Aj⟩>00 if ​cj−⟨λ∗,Aj⟩<0.\\displaystyle x^{\*}\_{j}=\\begin{cases}1&\\text{ if }c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle>0\\\<br>0&\\text{ if }c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle<0.\\end{cases} |  | (2) |

For any point x∈\[0,1\]nx\\in\[0,1\]^{n}, we define the quantity

|     |     |     |
| --- | --- | --- |
|  | Δrc​(x)=∑j∈\[n\](cj−⟨λ∗,Aj⟩)⋅(xj∗−xj),\\Delta\_{\\text{rc}}(x)=\\sum\_{j\\in\[n\]}(c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle)\\cdot(x^{\*}\_{j}-x\_{j}), |  |

which is then the difference in value between xx and x∗x^{\*} given by the reduced costs. Given this, we say that a 0/1 point xx _good_ if its Δrc\\Delta\_{\\text{rc}} is at most IPGap, and we use GG to denote the set of all good points, namely

|     |     |     |     |
| --- | --- | --- | --- |
|  | G:={x∈{0,1}n:Δrc​(x)≤IPGap}.\\displaystyle G:=\\{x\\in\\{0,1\\}^{n}:\\Delta\_{\\text{rc}}(x)\\leq\\textsc{IPGap}\\}. |  | (3) |

The following is the main result of this section, which states that we can bound the size of the branch-and-bound tree based on the number of these good points.

###### Theorem 3.

Consider the branch-and-bound algorithm with best-bound node selection rule for solving IP. Then its final tree has at most 2​\|G\|​n+12\|G\|n+1 nodes.

The remainder of this section is dedicated to proving this result. So let 𝒯\\mathcal{T} denote the final BB tree constructed by the algorithm, and let 𝒩\\mathcal{N} denote the set of its internal nodes. The first observation is that all LP solutions seen throughout the BB tree have small Δrc\\Delta\_{\\text{rc}}.

###### Lemma 3.

Let NN be a node that is branched on in the BB tree 𝒯\\mathcal{T}, i.e. N∈𝒩N\\in\\mathcal{N}, and let xNx^{N} be an optimal solution for the LP of this node with at most mm fractional coordinates (via Lemma [2](https://arxiv.org/html/2007.15192v4#Thmlemma2 "Lemma 2. ‣ 2.2 (Random) Packing problems ‣ 2 Preliminaries ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")). Then,

|     |     |     |
| --- | --- | --- |
|  | Δrc​(xN)≤IPGap.\\Delta\_{\\text{rc}}(x^{N})\\leq\\textsc{IPGap}. |  |

###### Proof.

First notice that for every feasible solution xx to LP we have

|     |     |     |
| --- | --- | --- |
|  | OPT​(LP)≥⟨c,x⟩+Δrc​(x),\\displaystyle\\textrm{OPT}(\\textrm{LP})\\geq\\langle c,x\\rangle+\\Delta\_{\\text{rc}}(x), |  |

since the equality of optimal value of LP and its Lagrangian and then feasibility of xx give

|     |     |     |     |
| --- | --- | --- | --- |
|  | OPT​(LP)−⟨c,x⟩\\displaystyle\\textrm{OPT}(\\textrm{LP})-\\langle c,x\\rangle | =∑j∈\[n\](cj−⟨λ∗,Aj⟩)​xj∗+⟨b,λ∗⟩−⟨c,x⟩≥∑j∈\[n\](cj−⟨λ∗,Aj⟩)​xj∗+⟨A​x,λ∗⟩−⟨c,x⟩,\\displaystyle=\\sum\_{j\\in\[n\]}(c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle)x^{\*}\_{j}+\\langle b,\\lambda^{\*}\\rangle-\\langle c,x\\rangle\\geq\\sum\_{j\\in\[n\]}(c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle)x^{\*}\_{j}+\\langle Ax,\\lambda^{\*}\\rangle-\\langle c,x\\rangle, |  |

and the claim follows by noticing that the right-hand side is precisely Δrc​(x)\\Delta\_{\\text{rc}}(x). Moreover, by the best-bound node selection rule (Lemma [1](https://arxiv.org/html/2007.15192v4#Thmlemma1 "Lemma 1 (best-bound node selection). ‣ 2.1 Branch-and-bound ‣ 2 Preliminaries ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")) we have that ⟨c,xN⟩≥OPT​(LP)−IPGap\\langle c,x^{N}\\rangle\\geq\\textrm{OPT}(\\textrm{LP})-\\textsc{IPGap}. Putting these observations together proves the result.
∎

In the next two lemmas we will demonstrate an association between BB nodes and good points. In particular, we will show that the association is at least one-to-one and at most nn-to-one. This essentially allows us to conclude the proof of Theorem [3](https://arxiv.org/html/2007.15192v4#Thmthm3 "Theorem 3. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").

###### Lemma 4.

There exists an association r:𝒩→Gr:\\mathcal{N}\\rightarrow G that associates any internal node N∈𝒩N\\in\\mathcal{N} to at least one good point x∈Gx\\in G, i.e. for all N∈𝒩N\\in\\mathcal{N}, it holds that \|r⁡(N)\|≥1\|r(N)\|\\geq 1.

###### Proof.

Let N∈𝒩N\\in\\mathcal{N} be any internal node of 𝒯\\mathcal{T} and xNx^{N} be its optimal LP solution. Let J⊂\[n\]J\\subset\[n\] denote the set of indices where xNx^{N} is fractional. Define r:𝒩→Gr:\\mathcal{N}\\rightarrow G to associate NN with any

|     |     |     |
| --- | --- | --- |
|  | x′∈argmin{Δrc(x):x∈{0,1}n,x=xN∀j∉J}.x^{\\prime}\\in\\arg\\min\\{\ \\Delta\_{\\text{rc}}(x):x\\in\\{0,1\\}^{n},\ x=x^{N}\ \\forall j\\not\\in J\\}. |  |

Noting that the objective function Δrc​(⋅)\\Delta\_{\\text{rc}}(\\cdot) is affine (λ∗\\lambda^{\*} is fixed) and that xNx^{N} is in the convex hull of the 0,10,1 points {x∈{0,1}n:x=xN​∀j∉J}\\{x\\in\\{0,1\\}^{n}:x=x^{N}\ \\forall j\\not\\in J\\}, it must hold that

|     |     |     |
| --- | --- | --- |
|  | Δrc​(x′)≤Δrc​(xN)≤IPGap,\\Delta\_{\\text{rc}}(x^{\\prime})\\leq\\Delta\_{\\text{rc}}(x^{N})\\leq\\textsc{IPGap}, |  |

where the last inequality follows from Lemma [3](https://arxiv.org/html/2007.15192v4#Thmlemma3 "Lemma 3. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime"). Then we see that

|     |     |     |
| --- | --- | --- |
|  | x′∈{x∈{0,1}n:Δrc​(x)≤IPGap}.x^{\\prime}\\in\\{x\\in\\{0,1\\}^{n}:\\Delta\_{\\text{rc}}(x)\\leq\\textsc{IPGap}\\}. |  |

∎

###### Lemma 5.

The association of Lemma [4](https://arxiv.org/html/2007.15192v4#Thmlemma4 "Lemma 4. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") is at most nn-to-11, i.e. for any x∈Gx\\in G, it holds that \|r−1​(x)\|≤n\|r^{-1}(x)\|\\leq n.

###### Proof.

Let x∈Gx\\in G. Let N1,N2N\_{1},N\_{2} be two internal nodes of 𝒯\\mathcal{T}, with optimal LP solutions x(1)x^{(1)} and x(2)x^{(2)} respectively, such that r⁡(x(1))=r⁡(x(2))=x′r(x^{(1)})=r(x^{(2)})=x^{\\prime}. In the following paragraph we show that either N1N\_{1} is a descendant of N2N\_{2}, or vice versa. Then, for any x∈Gx\\in G all nodes associated to xx (i.e. all N∈r−1​(x)N\\in r^{-1}(x)) must lie in the same path from the root in 𝒯\\mathcal{T} (i.e. must all be descendants of one another). So since a path from the root in 𝒯\\mathcal{T} can have length at most nn, we have the desired conclusion.

Suppose, for the sake of contradiction, N1N\_{1} and N2N\_{2} are not one a descendant of the other in the BB tree 𝒯\\mathcal{T}. Let N≠N1,N2N\\neq N\_{1},N\_{2} be their lowest common ancestor in the tree 𝒯\\mathcal{T}, and let f∈{1,…,n}f\\in\\{1,...,n\\} be the index where node NN was branched on. Since nodes N1N\_{1} and N2N\_{2} are on different subtrees under NN, without loss of generality assume that N1N\_{1} is in the subtree with xf=0x\_{f}=0 and N2N\_{2} is in the subtree with xf=1x\_{f}=1. Then since xf(1)=0x\_{f}^{(1)}=0 and r⁡(x(1))=x′r(x^{(1)})=x^{\\prime}, it must be that xf′=0x^{\\prime}\_{f}=0. However, since xf(2)=1x^{(2)}\_{f}=1, we have xf(2)≠xf′x^{(2)}\_{f}\\not=x^{\\prime}\_{f}, so that by definition of r⁡(⋅)r(\\cdot) we have x(2)∉r−1​(x′)x^{(2)}\\notin r^{-1}(x^{\\prime}), getting the desired contradiction.
∎

###### Proof of Theorem [3](https://arxiv.org/html/2007.15192v4\#Thmthm3 "Theorem 3. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").

Combining Lemma [4](https://arxiv.org/html/2007.15192v4#Thmlemma4 "Lemma 4. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") and Lemma [5](https://arxiv.org/html/2007.15192v4#Thmlemma5 "Lemma 5. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime"), we see that the number of internal nodes of 𝒯\\mathcal{T} (i.e. \|𝒩\|\|\\mathcal{N}\|) is upper bounded by \|G\|⋅n\|G\|\\cdot n. Since the total number of nodes in a binary tree is at most twice the number of its internal nodes plus 1, we see that 𝒯\\mathcal{T} has at most 2​\|G\|​n+12\|G\|n+1 nodes, giving the desired bound.
∎

We spend the remainder of this paper obtaining an upper bound of the form nO⁡(m)n^{O(m)} for the number of good solutions ( [3](https://arxiv.org/html/2007.15192v4#S3.E3 "In 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")), which will then prove Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").

## 4 Value of solutions and geometry of items

Going back to ( [2](https://arxiv.org/html/2007.15192v4#S3.E2 "In 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")), we can see the saddle point x∗x^{\*} as being obtained by a _linear classification_ of columns induced by λ∗\\lambda^{\*}, namely xj∗x^{\*}\_{j} is set to 0/1 depending on whether

|     |     |     |
| --- | --- | --- |
|  | cj−⟨λ∗,Aj⟩≷0≡⟨(cj,Aj),(1,−λ∗)⟩≷0,\\displaystyle c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle\\gtrless 0~~\\equiv~~\\langle(c\_{j},A^{j}),(1,-\\lambda^{\*})\\rangle\\gtrless 0, |  |

that is, depending where the column (cj,Aj)(c\_{j},A^{j}) lands relative to the hyperplane in ℝm+1\\mathbb{R}^{m+1}

|     |     |     |
| --- | --- | --- |
|  | H:={y∈ℝm+1:⟨(1,−λ∗),y⟩=0};H:=\\{y\\in\\mathbb{R}^{m+1}:\\langle(1,-\\lambda^{\*}),y\\rangle=0\\}; |  |

see Figure [1](https://arxiv.org/html/2007.15192v4#S4.F1 "Figure 1 ‣ 4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").

![Refer to caption](https://arxiv.org/html/2007.15192v4/slabs.png)Figure 1: Each dot represents an item/column (cj,Aj)(c\_{j},A^{j}) of IP. The grey line coming from the origin is HH. The optimal solution has xj∗=1x^{\*}\_{j}=1 for all items jj above this line, xj∗=0x^{\*}\_{j}=0 for all items jj below this line. Each JℓJ\_{\\ell} is the set of items that lie in one of the colored regions; JremJ\_{\\text{rem}} are the items that lie on the inner most region (yellow).

The next lemma says that the Δrc​(x)\\Delta\_{\\text{rc}}(x) of a 0/1 point xx increases the more it disagrees with x∗x^{\*}, and the penalty for the disagreement on item jj depends on the distance of the column (cj,Aj)(c\_{j},A^{j}) to the hyperplane HH. We use d⁡(z,U)d(z,U) to denote the Euclidean distance between a point zz and a set UU, and 𝟏​(P)\\bm{1}(P) to denote the 0/1 indicator of a predicate PP. This generalizes Lemma 3.1 of \[ [19](https://arxiv.org/html/2007.15192v4#bib.bib19 "")\].

###### Lemma 6.

Consider any x∈{0,1}nx\\in\\{0,1\\}^{n}. Then

|     |     |     |
| --- | --- | --- |
|  | Δrc​(x)≥∑j∈\[n\]d⁡((cj,Aj),H)⋅𝟏​(xj≠xj∗).\\displaystyle\\Delta\_{\\text{rc}}(x)\\geq\\sum\_{j\\in\[n\]}d\\Big((c\_{j},A^{j}),\\,H\\Big)\\cdot\\bm{1}(x\_{j}\\neq x^{\*}\_{j}). |  |

###### Proof.

Recalling the definition of Δrc​(⋅)\\Delta\_{\\text{rc}}(\\cdot), we can rewrite it as follows:

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | Δrc​(x)\\displaystyle\\Delta\_{\\text{rc}}(x) | =∑j∈\[n\](cj−⟨λ∗,Aj⟩)​(xj∗−xj)\\displaystyle=\\sum\_{j\\in\[n\]}(c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle)(x^{\*}\_{j}-x\_{j}) |  | (4) |
|  |  | =∑j:xj∗=0(cj−⟨λ∗,Aj⟩)(xj∗−xj)+∑j:xj∗=1(cj−⟨λ∗,Aj⟩)(xj∗−xj).\\displaystyle=\\sum\_{j:x^{\*}\_{j}=0}(c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle)(x^{\*}\_{j}-x\_{j})+\\sum\_{j:x^{\*}\_{j}=1}(c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle)(x^{\*}\_{j}-x\_{j}). |  | (5) |

To analyze the right-hand side of this equation, consider a term in the first sum. Since xj∗=0x^{\*}\_{j}=0, the term is non-zero exactly when the 0/1 point xx takes value xj=1x\_{j}=1. Moreover, since xj∗=0x^{\*}\_{j}=0 implies that cj−⟨λ∗,Aj⟩c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle is negative, this means that the terms in the first sum of ( [4](https://arxiv.org/html/2007.15192v4#S4.E4 "In Proof. ‣ 4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")) equal \|cj−⟨λ∗,Aj⟩\|⋅𝟏​(xj≠xj∗)\|c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle\|\\cdot\\bm{1}(x\_{j}\\neq x^{\*}\_{j}). A similar analysis shows that the terms in the second sum of ( [4](https://arxiv.org/html/2007.15192v4#S4.E4 "In Proof. ‣ 4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")) also equal \|cj−⟨λ∗,Aj⟩\|⋅𝟏​(xj≠xj∗)\|c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle\|\\cdot\\bm{1}(x\_{j}\\neq x^{\*}\_{j}). Together these give

|     |     |     |     |
| --- | --- | --- | --- |
|  | Δrc​(x)=∑j∈\[n\]\|cj−⟨λ∗,Aj⟩\|⋅𝟏​(xj≠xj∗).\\displaystyle\\Delta\_{\\text{rc}}(x)=\\sum\_{j\\in\[n\]}\|c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle\|\\cdot\\bm{1}(x\_{j}\\neq x^{\*}\_{j}). |  | (6) |

Finally, notice that

|     |     |     |
| --- | --- | --- |
|  | \|cj−⟨λ∗,Aj⟩\|≥d⁡((cj,Aj),H),\|c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle\|\\geq d\\Big((c\_{j},A^{j}),~H\\Big), |  |

because the point (⟨λ∗,Aj⟩,Aj)(\\langle\\lambda^{\*},A^{j}\\rangle,A^{j}) belongs to the hyperplane H⁡(λ)H(\\lambda) we get

|     |     |     |     |
| --- | --- | --- | --- |
|  | d⁡((cj,Aj),H)\\displaystyle d\\Big((c\_{j},A^{j}),~H\\Big) | ≤‖(cj,Aj)−(⟨λ∗,Aj⟩,Aj)‖2\\displaystyle\\leq\\\|(c\_{j},A^{j})-(\\langle\\lambda^{\*},A^{j}\\rangle,A^{j})\\\|\_{2} |  |
|  |  | =\|cj−⟨λ∗,Aj⟩\|.\\displaystyle=\|c\_{j}-\\langle\\lambda^{\*},A^{j}\\rangle\|. |  |

Plugging this bound in ( [6](https://arxiv.org/html/2007.15192v4#S4.E6 "In Proof. ‣ 4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")) concludes the proof of the lemma.
∎

Thus, a good solution, i.e., one with Δrc​(x)≤IPGap\\Delta\_{\\text{rc}}(x)\\leq\\textsc{IPGap}, must disagree with x∗x^{\*} on few items jj whose columns (cj,Aj)(c\_{j},A^{j}) are “far” from the hyperplane HH. To make this quantitative we bucket these distances in powers of 2, so for ℓ≥1\\ell\\geq 1 define the set of items

|     |     |     |     |
| --- | --- | --- | --- |
|  | Jℓ\\displaystyle J\_{\\ell} | :={j:d((cj,Aj),H) is\\displaystyle:=\\bigg\\{j:d\\Big((c\_{j},A^{j}),\\,H\\Big)\\textrm{ is} |  |
|  |  | in the interval (log⁡nn2ℓ,log⁡nn2ℓ+1\]},\\displaystyle\\qquad\\qquad\\quad\\textrm{ in the interval }\\Big(\\tfrac{\\log n}{n}2^{\\ell},~\\tfrac{\\log n}{n}2^{\\ell+1}\\Big\]\\bigg\\}, |  |

and define Jrem=\[n\]∖⋃ℓ≥1JℓJ\_{\\text{rem}}=\[n\]\\setminus\\bigcup\_{\\ell\\geq 1}J\_{\\ell} as the remaining items (see Figure [1](https://arxiv.org/html/2007.15192v4#S4.F1 "Figure 1 ‣ 4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")). Since every item in JℓJ\_{\\ell} has distance at least log⁡nn​2ℓ\\frac{\\log n}{n}2^{\\ell} from HH, we directly have the following.

###### Corollary 1.

If x∈{0,1}nx\\in\\{0,1\\}^{n} is a good point (i.e., Δrc​(x)≤IPGap\\Delta\_{\\text{rc}}(x)\\leq\\textsc{IPGap}), then for every ℓ≥1\\ell\\geq 1 the number of coordinates j∈Jℓj\\in J\_{\\ell} such that xj≠xj∗x\_{j}\\neq x^{\*}\_{j} is at most C2ℓ\\frac{C}{2^{\\ell}}, where C:=nlog⁡n⋅IPGapC:=\\frac{n}{\\log n}\\cdot\\textsc{IPGap}.

Then, an easy counting argument gives an upper bound on the total number of good points GG.

###### Lemma 7.

We have the following upper bound:

|     |     |     |
| --- | --- | --- |
|  | \|G\|≤2\|Jrem\|⋅∏ℓ=1log⁡C(\|Jℓ\|≤C/2ℓ),\\displaystyle\|G\|\\leq 2^{\|J\_{\\text{rem}}\|}\\cdot\\prod\_{\\ell=1}^{\\log C}\\binom{\|J\_{\\ell}\|}{\\leq C/2^{\\ell}}, |  |

where C:=nlog⁡n⋅IPGapC:=\\frac{n}{\\log n}\\cdot\\textsc{IPGap}.111We assume throughout that the C/2ℓC/2^{\\ell}’s are integral to simplify the notation, but it can be easily checked that using ⌈C/2ℓ⌉\\lceil C/2^{\\ell}\\rceil instead does not change the results.

###### Proof.

Notice that every solution in GG can be thought of as being created by starting with the vector x∗x^{\*} and then changing some of its coordinates, and because of Corollary [1](https://arxiv.org/html/2007.15192v4#Thmcor1 "Corollary 1. ‣ 4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") we:

- •


Cannot change the value of x∗x^{\*} in any coordinate jj in a JℓJ\_{\\ell} with ℓ>log⁡C\\ell>\\log C

- •


Can only flip the value of x∗x^{\*} in at most C2ℓ\\frac{C}{2^{\\ell}} of the coordinates j∈Jℓj\\in J\_{\\ell} for each ℓ=1,…,log⁡C\\ell=1,\\ldots,\\log C (recall that x∗x^{\*} is 0/1 in all such coordinates)

- •


Set a new arbitrary 0/1 value for (in principle all) coordinates in JremJ\_{\\text{rem}}.


Since there are at most 2\|Jrem\|⋅∏ℓ=1log⁡C(\|Jℓ\|≤C/2ℓ)2^{\|J\_{\\text{rem}}\|}\\cdot\\prod\_{\\ell=1}^{\\log C}\\binom{\|J\_{\\ell}\|}{\\leq C/2^{\\ell}} options in this process, we have the desired upper bound.
∎

Notice that, ignoring the term 2\|Jrem\|2^{\|J\_{\\text{rem}}\|}, this already gives with good probability a quasi-polynomial bound \|G\|≲O​(n)polylog​(n)\|G\|\\lesssim O(n)^{\\text{polylog}(n)} for random instances of IP: the upper bound on the integrality gap from Theorem [2](https://arxiv.org/html/2007.15192v4#Thmthm2 "Theorem 2 (Theorem 1 of []). ‣ 2.2 (Random) Packing problems ‣ 2 Preliminaries ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") gives that with good probability C≤log⁡nC\\leq\\log n and so we have log⁡log⁡n\\log\\log n binomial terms, each at most (nlog⁡n)≤nlog⁡n\\binom{n}{\\log n}\\leq n^{\\log n} (since \|Jℓ\|≤n\|J\_{\\ell}\|\\leq n).

In order to obtain the desired polynomial bound \|G\|≤nO⁡(m)\|G\|\\leq n^{O(m)}, we need a better control on \|Jℓ\|\|J\_{\\ell}\|, namely the number of points at a distance from the hyperplane HH.

## 5 Number of items at a distance from the hyperplane

To control the size of the sets JℓJ\_{\\ell} we need to consider a random instance of IP and use the fact that the columns (cj,Aj)(c\_{j},A^{j}) are uniformly distributed in \[0,1\]m+1\[0,1\]^{m+1}. Recalling the definition of JℓJ\_{\\ell}, we see that an item jj belongs to this set only if the column (cj,Aj)(c\_{j},A^{j}) lies on the (m+1)(m+1)-dim _slab_ of width log⁡nn​2ℓ+1\\tfrac{\\log n}{n}2^{\\ell+1} around HH:

|     |     |     |
| --- | --- | --- |
|  | {y∈ℝm+1:d⁡(y,H)≤log⁡nn​2ℓ+1}.\\displaystyle\\Big\\{y\\in\\mathbb{R}^{m+1}:d(y,H)\\leq\\tfrac{\\log n}{n}2^{\\ell+1}\\Big\\}. |  |

It can be shown that the volume of this slab intersected with \[0,1\]m+1\[0,1\]^{m+1} is proportional to its width, so as long as HH is independent of the columns, the probability that a random column (cj,Aj)(c\_{j},A^{j}) lies in this slab is ≈log⁡nn​2ℓ+1\\approx\\tfrac{\\log n}{n}2^{\\ell+1}. Thus, we would expect that at most ≈(log⁡n)​ 2ℓ+1\\approx(\\log n)\\,2^{\\ell+1} columns lie in this slab, which gives a much improved upper bound on the (expected) size of JℓJ\_{\\ell} (as indicated above, think ℓ≤log⁡log⁡n\\ell\\leq\\log\\log n). Moreover, using independence of the columns (cj,Aj)(c\_{j},A^{j}), standard concentration inequalities show that for _each_ such slab with good probability the number of columns that land in it is within a multiplicative factor from this expectation.

Unfortunately, the hyperplane HH that we are concerned with, whose normal (1,−λ∗)‖(1,−λ∗)‖2\\frac{(1,-\\lambda^{\*})}{\\\|(1,-\\lambda^{\*})\\\|\_{2}} is determined by the data, is _not_ independent of the columns. So we will show a much stronger _uniform_ bound that shows that with good probability the above phenomenon holds _simultaneously_ for all slabs around _all_ hyperplanes, which then shows that it holds for HH. We abstract this situation and prove such uniform bound. We use 𝕊k−1\\mathbb{S}^{k-1} to denote the unit sphere in ℝk\\mathbb{R}^{k}.

###### Theorem 4(Uniform bound for slabs).

For u∈𝕊k−1u\\in\\mathbb{S}^{k-1} and w≥0w\\geq 0, define the slab of normal uu and width ww as

|     |     |     |
| --- | --- | --- |
|  | Su,w:={y∈ℝk:⟨u,y⟩∈\[−w,w\]}.S\_{u,w}:=\\Big\\{y\\in\\mathbb{R}^{k}:\\langle u,y\\rangle\\in\[-w,w\]\\Big\\}. |  |

Let Y1,…,YnY^{1},\\ldots,Y^{n} be independent random vectors uniformly distributed in the cube \[0,1\]k\[0,1\]^{k}, for n≥kn\\geq k. Then with probability at least 1−1n1-\\frac{1}{n}, we have that for all u∈𝕊k−1u\\in\\mathbb{S}^{k-1} and w≥log⁡nnw\\geq\\tfrac{\\log n}{n} at most 60​n​w​k60nwk of the YjY^{j}’s belong to Su,wS\_{u,w}.

While very general bounds of this type are available (for example, appealing to the low VC-dimension of the family of slabs), we could not find in the literature a good enough such _multiplicative_ bound (i.e., relative to the expectation ≈n​w\\approx nw). The proof of Theorem [4](https://arxiv.org/html/2007.15192v4#Thmthm4 "Theorem 4 (Uniform bound for slabs). ‣ 5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") instead relies on an ε\\varepsilon-net type argument.

This result directly gives the desired upper bound on the size of the sets JremJ\_{\\text{rem}} and JℓJ\_{\\ell}.

###### Corollary 2.

With probability at least 1−1n1-\\frac{1}{n} we have simultaneously

|     |     |     |
| --- | --- | --- |
|  | \|Jrem\|≤120​(m+1)​log⁡n\|J\_{\\text{rem}}\|\\leq 120(m+1)\\log n |  |

|     |     |     |
| --- | --- | --- |
|  | \|Jℓ\|≤60​(m+1)​2ℓ+1​log⁡n,∀ℓ∈\[log⁡n−1\]\|J\_{\\ell}\|\\leq 60(m+1)2^{\\ell+1}\\log n,\\quad\\forall\\ell\\in\[\\log n-1\] |  |

### 5.1 Proof of Theorem [4](https://arxiv.org/html/2007.15192v4\#Thmthm4 "Theorem 4 (Uniform bound for slabs). ‣ 5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")

Let 𝕊′\\mathbb{S}^{\\prime} be a minimal ε\\varepsilon-net, for ε:=log⁡nn​k\\varepsilon:=\\frac{\\log n}{n\\sqrt{k}}, of the sphere 𝕊k−1\\mathbb{S}^{k-1}, namely for each u∈𝕊k−1u\\in\\mathbb{S}^{k-1} there is u′∈𝕊′u^{\\prime}\\in\\mathbb{S}^{\\prime} such that ‖u′−u‖2≤ε\\\|u^{\\prime}-u\\\|\_{2}\\leq\\varepsilon. It is well-known that there is such a net of size at most (3ε)k(\\frac{3}{\\varepsilon})^{k} (Corollary 4.2.13 \[ [29](https://arxiv.org/html/2007.15192v4#bib.bib29 "")\]). Also define the discretized set of widths 𝕎′:={log⁡nn,2​log⁡nn,…,k+log⁡nn}\\mathbb{W}^{\\prime}:=\\{\\frac{\\log n}{n},\\frac{2\\log n}{n},...,\\sqrt{k}+\\frac{\\log n}{n}\\} so that \|𝕎′\|=n​klog⁡n+1\|\\mathbb{W}^{\\prime}\|=\\frac{n\\sqrt{k}}{\\log n}+1.

We start by focusing on a single slab in the net, observing that these slabs are determined independently of the columns. Since the vector YjY^{j} is uniformly distributed in the cube \[0,1\]k\[0,1\]^{k}, the probability that it belongs to a set U⊆\[0,1\]kU\\subseteq\[0,1\]^{k} equals the volume vol​(U)\\textrm{vol}(U). Using this and an upper bound on the volume of a slab (intersected with the cube), we get that the probability that YjY^{j} lands on a slab is at most proportional to the slab’s width.

###### Lemma 8.

For every slab Su′,w′S\_{u^{\\prime},w^{\\prime}}, with u′∈𝕊′u^{\\prime}\\in\\mathbb{S}^{\\prime} and w′∈𝕎′w^{\\prime}\\in\\mathbb{W}^{\\prime}, we have Pr⁡(Yj∈Su′,w′)≤2​2​w′\\Pr(Y^{j}\\in S\_{u^{\\prime},w^{\\prime}})\\leq 2\\sqrt{2}w^{\\prime}.

###### Proof.

Since these slabs are determined independently of the columns, it is equivalent to show that the volume vol​(Su′,w′∩\[0,1\]k)\\textrm{vol}(S\_{u^{\\prime},w^{\\prime}}\\cap\[0,1\]^{k}) is at most 2​2​w′2\\sqrt{2}w^{\\prime}. Let slice​(h):={y∈\[0,1\]k:⟨y,u⟩=h}\\text{slice}(h):=\\{y\\in\[0,1\]^{k}:\\langle y,u\\rangle=h\\} be the slice of the cube with normal u′u^{\\prime} at height hh. It is known that every slice of the cube has (k−1)(k-1)-dim volume volk−1\\textrm{vol}\_{k-1} at most 2\\sqrt{2}\[ [3](https://arxiv.org/html/2007.15192v4#bib.bib3 "")\], and since Su′,w′∩\[0,1\]k=⋃h∈\[−w′,w′\]slice​(h)S\_{u^{\\prime},w^{\\prime}}\\cap\[0,1\]^{k}=\\bigcup\_{h\\in\[-w^{\\prime},w^{\\prime}\]}\\text{slice}(h), by integrating we get

|     |     |     |
| --- | --- | --- |
|  | vol​(Su′,w′∩\[0,1\]k)=∫−w′w′volk−1​(slice​(h))​d​h≤2​2​w′\\displaystyle\\textrm{vol}(S\_{u^{\\prime},w^{\\prime}}\\cap\[0,1\]^{k})=\\int\_{-w^{\\prime}}^{w^{\\prime}}\\textrm{vol}\_{k-1}(\\text{slice}(h))\\,\\textrm{d}h~\\leq~2\\sqrt{2}w^{\\prime} |  |

as desired.
∎

Let Nu,wN\_{u,w} be the number of vectors YjY^{j} that land in the slab Su,wS\_{u,w}. From the previous lemma we have 𝔼​Nu′,w′≤2​2​w′​n\\mathbb{E}N\_{u^{\\prime},w^{\\prime}}\\leq 2\\sqrt{2}w^{\\prime}n. To show that Nu′,w′N\_{u^{\\prime},w^{\\prime}} is concentrated around its expectation we need Bernstein’s Inequality; the following convenient form is a consequence of Appendix A.2 of \[ [20](https://arxiv.org/html/2007.15192v4#bib.bib20 "")\] and the fact Var⁡(∑jZj)=∑jVar⁡(Zj)≤∑j𝔼​Zj2≤𝔼​∑jZj\\mathrm{Var}(\\sum\_{j}Z\_{j})=\\sum\_{j}\\mathrm{Var}(Z\_{j})\\leq\\sum\_{j}\\mathbb{E}Z\_{j}^{2}\\leq\\mathbb{E}\\sum\_{j}Z\_{j} for independent random variables ZjZ\_{j} in \[0,1\]\[0,1\].

###### Lemma 9.

Let Z1,…,ZnZ\_{1},\\ldots,Z\_{n} be independent random variables in \[0,1\]\[0,1\]. Then for all t≥0t\\geq 0,

|     |     |     |     |
| --- | --- | --- | --- |
|  |  | Pr⁡(∑jZj≥𝔼​∑jZj+t)\\displaystyle\\Pr\\bigg(\\sum\_{j}Z\_{j}\\geq\\mathbb{E}\\sum\_{j}Z\_{j}+t\\bigg) |  |
|  |  | ≤exp⁡(−min⁡{t24​𝔼​∑jZj,3​t4}).\\displaystyle~~~~~\\leq\\exp\\bigg(-\\min\\bigg\\{\\frac{t^{2}}{4\\mathbb{E}\\sum\_{j}Z\_{j}}~,~\\frac{3t}{4}\\bigg\\}\\bigg). |  |

###### Lemma 10.

For each u′∈𝕊′u^{\\prime}\\in\\mathbb{S}^{\\prime} and width w′∈𝕎′w^{\\prime}\\in\\mathbb{W}^{\\prime}, we have

|     |     |     |
| --- | --- | --- |
|  | Pr⁡(Nu′,w′≥20​w′​n​k)≤n−4​k.\\Pr(N\_{u^{\\prime},w^{\\prime}}\\geq 20w^{\\prime}nk)\\leq n^{-4k}. |  |

###### Proof.

Let μ:=𝔼​Nu′,w′\\mu:=\\mathbb{E}N\_{u^{\\prime},w^{\\prime}}. Notice that Nu′,w′N\_{u^{\\prime},w^{\\prime}} is the sum of the independent random variables that indicate for each jj whether Yj∈Su′,w′Y^{j}\\in S\_{u^{\\prime},w^{\\prime}}. Then applying the previous lemma with t=4​μ+163​k​ln⁡nt=4\\mu+\\frac{16}{3}k\\ln n we get

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  |  | Pr⁡(Nu′,w′≥ 5​μ+163​k​ln⁡n)\\displaystyle\\Pr\\bigg(N\_{u^{\\prime},w^{\\prime}}\\,\\geq\\,5\\mu+\\frac{16}{3}k\\ln n\\bigg) |  | (7) |
|  |  | ≤exp⁡(−min⁡{163​k​ln⁡n,3⋅(16/3)​k​ln⁡n4})\\displaystyle\\leq\\,\\exp\\bigg(-\\min\\bigg\\{\\frac{16}{3}k\\ln n~,~\\frac{3\\cdot(16/3)k\\ln n}{4}\\bigg\\}\\bigg) |  |
|  |  | ≤n−4​k,\\displaystyle\\leq n^{-4k}, |  |

where in the first inequality we used t2≥(4​μ)⋅(163​k​ln⁡n)t^{2}\\geq(4\\mu)\\cdot(\\frac{16}{3}k\\ln n). From Lemma [8](https://arxiv.org/html/2007.15192v4#Thmlemma8 "Lemma 8. ‣ 5.1 Proof of Theorem ‣ 5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") we get μ≤2​2​n​w′\\mu\\leq 2\\sqrt{2}nw^{\\prime}, and further using the assumption w′≥log⁡nnw^{\\prime}\\geq\\frac{\\log n}{n} (implied by w′∈𝕎′w^{\\prime}\\in\\mathbb{W}^{\\prime}) we see that

|     |     |     |
| --- | --- | --- |
|  | 20​w′​n​k≥(10​2+163)​w′​n​k≥5​μ+163​k​ln⁡n,\\displaystyle 20w^{\\prime}nk~\\geq~\\bigg(10\\sqrt{2}+\\frac{16}{3}\\bigg)w^{\\prime}nk~\\geq~5\\mu+\\frac{16}{3}k\\ln n, |  |

and hence inequality ( [7](https://arxiv.org/html/2007.15192v4#S5.E7 "In Proof. ‣ 5.1 Proof of Theorem ‣ 5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")) upper bounds Pr⁡(Nu′,w′≥20​w′​n​k)\\Pr(N\_{u^{\\prime},w^{\\prime}}\\geq 20w^{\\prime}nk). This concludes the proof. ∎

To prove the theorem we need to show that with high probability we simultaneously have Nu,w≤60​n​w​kN\_{u,w}\\leq 60nwk for all u∈𝕊k−1u\\in\\mathbb{S}^{k-1} and w≥log⁡nnw\\geq\\frac{\\log n}{n}. We associate each slab Su,wS\_{u,w} (for u∈𝕊k−1u\\in\\mathbb{S}^{k-1} and w∈\[0,k\]w\\in\[0,\\sqrt{k}\]) to a “discretized slab” Su′,w′S\_{u^{\\prime},w^{\\prime}} by taking u′u^{\\prime} as a vector in the net 𝕊′\\mathbb{S}^{\\prime} so that ‖u′−u‖2≤ε\\\|u^{\\prime}-u\\\|\_{2}\\leq\\varepsilon and taking w′∈𝕎′w^{\\prime}\\in\\mathbb{W}^{\\prime} so that w′∈\[w+log⁡nn,w+2​log⁡nn\]w^{\\prime}\\in\[w+\\frac{\\log n}{n},w+\\frac{2\\log n}{n}\].

###### Lemma 11.

This association has the following properties: for every u∈𝕊k−1u\\in\\mathbb{S}^{k-1} and w∈\[0,k\]w\\in\[0,\\sqrt{k}\]

1. 1.


The intersected slab Su,w∩\[0,1\]kS\_{u,w}\\cap\[0,1\]^{k} is contained in the associated intersected slab Su′,w′∩\[0,1\]kS\_{u^{\\prime},w^{\\prime}}\\cap\[0,1\]^{k}. In particular, in every scenario Nu,w≤Nu′,w′N\_{u,w}\\leq N\_{u^{\\prime},w^{\\prime}}

2. 2.


If the width satisfies w≥log⁡nnw\\geq\\frac{\\log n}{n}, then w′≤3​ww^{\\prime}\\leq 3w.


###### Proof.

The second property is immediate, so we only prove the first one. Take a point y∈Su,w∩\[0,1\]ky\\in S\_{u,w}\\cap\[0,1\]^{k}. By definition we have ⟨y,u⟩∈\[−w,w\]\\langle y,u\\rangle\\in\[-w,w\], and also

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|⟨y,u′⟩−⟨y,u⟩\|=\|⟨y,u′−u⟩\|\\displaystyle\|\\langle y,u^{\\prime}\\rangle-\\langle y,u\\rangle\|=\|\\langle y,u^{\\prime}-u\\rangle\| | ≤‖y‖2​‖u′−u‖2\\displaystyle\\leq\\\|y\\\|\_{2}\\,\\\|u^{\\prime}-u\\\|\_{2} |  |
|  |  | ≤k​ε=log⁡nn,\\displaystyle\\leq\\sqrt{k}\\varepsilon=\\frac{\\log n}{n}, |  |

where the first inequality is Cauchy-Schwarz, and the second uses the fact that every vector in \[0,1\]k\[0,1\]^{k} has Euclidean norm at most k\\sqrt{k}. Therefore ⟨y,u′⟩∈\[−(w+log⁡nn),w+log⁡nn\]\\langle y,u^{\\prime}\\rangle\\in\[-(w+\\frac{\\log n}{n}),w+\\frac{\\log n}{n}\], and since the associated width satisfies w′≥w+log⁡nnw^{\\prime}\\geq w+\\frac{\\log n}{n} we see that yy belongs to Su′,w′∩\[0,1\]kS\_{u^{\\prime},w^{\\prime}}\\cap\[0,1\]^{k}. This concludes the proof.
∎

###### Proof of Theorem [4](https://arxiv.org/html/2007.15192v4\#Thmthm4 "Theorem 4 (Uniform bound for slabs). ‣ 5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").

We need to show

|     |     |     |     |
| --- | --- | --- | --- |
|  | Pr⁡\[⋁u∈𝕊k−1,w≥log⁡nn(Nu,w>60​w​n​k)\]≤1n.\\displaystyle\\Pr\\bigg\[\\bigvee\_{u\\in\\mathbb{S}^{k-1},w\\geq\\frac{\\log n}{n}}(N\_{u,w}>60wnk)\\bigg\]\\leq\\frac{1}{n}. |  | (8) |

Since there are only nnYjY^{j}’s, we always have Nu,w≤nN\_{u,w}\\leq n and hence it suffices to consider w∈\[log⁡nn,160​k\]w\\in\[\\frac{\\log n}{n},\\frac{1}{60k}\], in which case we can use the inequalities Nu,w≤Nu′,w′N\_{u,w}\\leq N\_{u^{\\prime},w^{\\prime}} and w′≤3​ww^{\\prime}\\leq 3w from the previous lemma; in particular, the event (Nu,w>60​w​n​k)(N\_{u,w}>60wnk) implies the event (Nu′,w′>20​w′​n​k)(N\_{u^{\\prime},w^{\\prime}}>20w^{\\prime}nk). Thus, using Lemma [10](https://arxiv.org/html/2007.15192v4#Thmlemma10 "Lemma 10. ‣ 5.1 Proof of Theorem ‣ 5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")

|     |     |     |     |
| --- | --- | --- | --- |
|  | LHS of ( [8](https://arxiv.org/html/2007.15192v4#S5.E8 "In Proof of Theorem . ‣ 5.1 Proof of Theorem ‣ 5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")) | ≤Pr⁡\[⋁u′∈𝕊′,w′∈𝕎′(Nu′,w′>20​w′​n​k)\]\\displaystyle\\leq~\\Pr\\bigg\[\\bigvee\_{u^{\\prime}\\in\\mathbb{S}^{\\prime},w^{\\prime}\\in\\mathbb{W}^{\\prime}}(N\_{u^{\\prime},w^{\\prime}}>20w^{\\prime}nk)\\bigg\] |  |
|  |  | ≤∑u′∈𝕊′,w′∈𝕎′Pr⁡(Nu′,w′>20​w′​n​k)\\displaystyle\\leq\\sum\_{u^{\\prime}\\in\\mathbb{S}^{\\prime},w^{\\prime}\\in\\mathbb{W}^{\\prime}}\\Pr(N\_{u^{\\prime},w^{\\prime}}>20w^{\\prime}nk) |  |
|  |  | ≤\|𝕊′\|​\|𝕎′\|​n−4​k\\displaystyle\\leq~\|\\mathbb{S}^{\\prime}\|\\,\|\\mathbb{W}^{\\prime}\|\\,n^{-4k} |  |
|  |  | ≤(3​n​klog⁡n)k+1​n−4​k≤1n,\\displaystyle\\leq~\\bigg(\\frac{3n\\sqrt{k}}{\\log n}\\bigg)^{k+1}n^{-4k}~\\leq~\\frac{1}{n}, |  |

where the last inequality uses the assumption n≥kn\\geq k. This concludes the proof.
∎

## 6 Proof of Theorem [1](https://arxiv.org/html/2007.15192v4\#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime")

We can finally conclude the proof of Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime"). To simplify the notation we use O⁡(val)O(\\text{val}) to denote cst⋅val\\text{cst}\\cdot\\text{val} for some constant cst. Because of Theorem [3](https://arxiv.org/html/2007.15192v4#Thmthm3 "Theorem 3. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime"), we show that for a random instance ℐ\\mathcal{I} of IP, with probability at least 1−1n−2−α​a21-\\frac{1}{n}-2^{-\\alpha a\_{2}} the number of good points GG relative to this instance at most nO⁡(m+α​a1​log⁡m)n^{O(m+\\alpha a\_{1}\\log m)}.

For that, let EE be the event where all of the following hold:

1. 1.


Theorem [2](https://arxiv.org/html/2007.15192v4#Thmthm2 "Theorem 2 (Theorem 1 of []). ‣ 2.2 (Random) Packing problems ‣ 2 Preliminaries ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") holds for ℐ\\mathcal{I}, namely IPGap​(ℐ)\\textsc{IPGap}(\\mathcal{I}) is at most α​a1​log2​nn\\frac{\\alpha a\_{1}\\log^{2}n}{n},

2. 2.


The bound of Corollary [2](https://arxiv.org/html/2007.15192v4#Thmcor2 "Corollary 2. ‣ 5 Number of items at a distance from the hyperplane ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") on the sizes of JremJ\_{\\text{rem}} and JℓJ\_{\\ell} for all ℓ∈\[log⁡n−1\]\\ell\\in\[\\log n-1\], determined by the arrangement of random vectors (cj,Aj)(c\_{j},A^{j})’s that comprise the columns of ℐ\\mathcal{I}.


By taking a union bound over these results we see that EE holds with probability at least 1−1n−2−α​a21-\\frac{1}{n}-2^{-\\alpha a\_{2}}.

From the first item in the definition of EE, under EE we have that C:=nlog⁡n⋅IPGap​(ℐ)C:=\\frac{n}{\\log n}\\cdot\\textsc{IPGap}(\\mathcal{I}) is at most α​a1​log⁡n\\alpha a\_{1}\\log n. Therefore, using the standard estimate (a≤b)≤(4​a/b)b\\binom{a}{\\leq b}\\leq(4a/b)^{b} that holds for a≥4​ba\\geq 4b, we get that, under EE:

|     |     |     |     |
| --- | --- | --- | --- |
|  | ∏ℓ=log⁡a12log⁡C(\|Jℓ\|≤C/2ℓ)\\displaystyle\\prod\_{\\ell=\\frac{\\log a\_{1}}{2}}^{\\log C}\\binom{\|J\_{\\ell}\|}{\\leq C/2^{\\ell}}~ | ≤∏ℓ=1log⁡C(O⁡(m)​ 22​ℓ​log⁡nα​a1​log⁡n)C/2ℓ\\displaystyle\\leq~\\prod\_{\\ell=1}^{\\log C}\\bigg(\\frac{O(m)\\,2^{2\\ell}\\log n}{\\alpha a\_{1}\\log n}\\bigg)^{C/2^{\\ell}} |  |
|  |  | =∏ℓ=1log⁡C(O⁡(m)​ 22​ℓα​a1)C/2ℓ\\displaystyle=~\\prod\_{\\ell=1}^{\\log C}\\bigg(\\frac{O(m)\\,2^{2\\ell}}{\\alpha a\_{1}}\\bigg)^{C/2^{\\ell}} |  |
|  |  | ≤(O⁡(m)α​a1)C​∑ℓ≥112ℓ⋅22​C​∑ℓ≥1ℓ2ℓ\\displaystyle~\\leq~\\bigg(\\frac{O(m)}{\\alpha a\_{1}}\\bigg)^{C\\sum\_{\\ell\\geq 1}\\frac{1}{2^{\\ell}}}\\cdot 2^{2C\\sum\_{\\ell\\geq 1}\\frac{\\ell}{2^{\\ell}}} |  |
|  |  | ≤(O⁡(m)α​a1)O⁡(C),\\displaystyle~\\leq~\\bigg(\\frac{O(m)}{\\alpha a\_{1}}\\bigg)^{O(C)}, |  |

where we started the product from ℓ=log⁡a12\\ell=\\frac{\\log a\_{1}}{2} to ensure we could apply the binomial estimate given only the assumption α≤30​m\\alpha\\leq 30m; for the lower terms we can use the crude upper bound

|     |     |     |     |
| --- | --- | --- | --- |
|  | ∏ℓ<log⁡a12(\|Jℓ\|≤C/2ℓ)\\displaystyle\\prod\_{\\ell<\\frac{\\log a\_{1}}{2}}\\binom{\|J\_{\\ell}\|}{\\leq C/2^{\\ell}}~ | ≤∏ℓ<log⁡a122\|Jℓ\|\\displaystyle\\leq~\\prod\_{\\ell<\\frac{\\log a\_{1}}{2}}2^{\|J\_{\\ell}\|} |  |
|  |  | ≤2O⁡(m​a1​log⁡a1​log​n)\\displaystyle\\leq~2^{O(ma\_{1}\\log a\_{1}\\log n)} |  |
|  |  | =nO⁡(m​a1​log⁡a1).\\displaystyle~=~n^{O(ma\_{1}\\log a\_{1})}. |  |

Plugging these bounds on Lemma [7](https://arxiv.org/html/2007.15192v4#Thmlemma7 "Lemma 7. ‣ 4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime"), we get that under EE the number of good points GG relative to the instance ℐ\\mathcal{I} is upper bounded as

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|G\|\\displaystyle\|G\| | ≤2O⁡(m​log⁡n)⋅nO⁡(m​a1​log⁡a1)⋅(O⁡(m)α​a1)O⁡(α​a1​log⁡n)\\displaystyle\\leq 2^{O(m\\log n)}\\cdot n^{O(ma\_{1}\\log a\_{1})}\\cdot\\bigg(\\frac{O(m)}{\\alpha a\_{1}}\\bigg)^{O(\\alpha a\_{1}\\log n)} |  |
|  |  | ≤nO⁡(m​a1​log⁡a1+α​a1​log⁡m).\\displaystyle\\leq n^{O(ma\_{1}\\log a\_{1}+\\alpha a\_{1}\\log m)}. |  |

Finally, plugging this bound on Theorem [3](https://arxiv.org/html/2007.15192v4#Thmthm3 "Theorem 3. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") we get that under EE the branch-and-bound tree for the instance ℐ\\mathcal{I} has at most

|     |     |     |     |
| --- | --- | --- | --- |
|  |  | 2​n⋅nO⁡(m​a1​log⁡a1+α​a1​log⁡m)+1\\displaystyle 2\\,n\\cdot\\,n^{O(ma\_{1}\\log a\_{1}+\\alpha a\_{1}\\log m)}+1 |  |
|  |  | ≤nO⁡(m​a1​log⁡a1+α​a1​log⁡m)\\displaystyle\\qquad\\qquad~~~\\leq~n^{O(ma\_{1}\\log a\_{1}+\\alpha a\_{1}\\log m)} |  |

nodes. This concludes the proof of Theorem [1](https://arxiv.org/html/2007.15192v4#Thmthm1 "Theorem 1. ‣ 1 Introduction ‣ Branch-and-Bound Solves Random Binary IPs in Polytime").

## 7 Final remarks

We note that most of the above arguments hold not only for random problems but actually for _every_ 0/1 IP. In particular, Theorem [3](https://arxiv.org/html/2007.15192v4#Thmthm3 "Theorem 3. ‣ 3 Branch-and-bound and good integer solutions ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") and Lemma [7](https://arxiv.org/html/2007.15192v4#Thmlemma7 "Lemma 7. ‣ 4 Value of solutions and geometry of items ‣ Branch-and-Bound Solves Random Binary IPs in Polytime") hold in such generality, which combined give the following.

###### Corollary 3.

Consider any instance of IP with arbitrary A∈ℝm×nA\\in\\mathbb{R}^{m\\times n} and b∈ℝmb\\in\\mathbb{R}^{m}. Then the tree of the best-bound branch-and-bound algorithm applied to this instance has at most

|     |     |     |
| --- | --- | --- |
|  | 2​(2\|Jrem\|⋅∏ℓ=1log⁡C(\|Jℓ\|≤C/2ℓ))​n+1\\displaystyle 2\\bigg(2^{\|J\_{\\text{rem}}\|}\\cdot\\prod\_{\\ell=1}^{\\log C}\\binom{\|J\_{\\ell}\|}{\\leq C/2^{\\ell}}\\bigg)n+1 |  |

nodes, where C:=nlog⁡n⋅IPGapC:=\\frac{n}{\\log n}\\cdot\\textsc{IPGap}.

This shows that the effectiveness of branch-and-bound actually hold for every “well-behaved” 0/1 IP (or distributions that generate such IPs with good probability), where “well-behaved” means that the integrality gap must be small and there cannot be too many columns (cj,Aj)(c\_{j},A^{j}) concentrated around a hyperplane (in order to control the terms \|Jℓ\|\|J\_{\\ell}\|).

## Acknowledgments

We are extremely grateful to Daniel Dadush for suggesting several improvements to the paper.

## References

- \[1\]
Karen Aardal, Robert E Bixby, Cor AJ Hurkens, Arjen K Lenstra, and Job W
Smeltink.

Market split and basis reduction: Towards a solution of the
cornuéjols-dawande instances.

_INFORMS Journal on Computing_, 12(3):192–202, 2000.

- \[2\]
Tobias Achterberg, Thorsten Koch, and Alexander Martin.

Branching rules revisited.

_Operations Research Letters_, 33(1):42–54,
2005.

- \[3\]
Keith Ball.

Cube slicing in rn.

_Proceedings of the American Mathematical Society_, 97(3):465–473, 1986.

ISSN 00029939, 10886826.

URL [http://www.jstor.org/stable/2046239](http://www.jstor.org/stable/2046239 "").

- \[4\]
René Beier and Berthold Vöcking.

Random knapsack in expected polynomial time.

In Lawrence L. Larmore and Michel X. Goemans, editors, _STOC_,
pages 232–241. ACM, 2003.

ISBN 1-58113-674-9.

URL
[http://dblp.uni-trier.de/db/conf/stoc/stoc2003.html#BeierV03](http://dblp.uni-trier.de/db/conf/stoc/stoc2003.html#BeierV03 "").

- \[5\]
René Beier and Berthold Vöcking.

Probabilistic analysis of knapsack core algorithms.

In J. Ian Munro, editor, _SODA_, pages 468–477. SIAM, 2004.

ISBN 0-89871-558-X.

URL
[http://dblp.uni-trier.de/db/conf/soda/soda2004.html#BeierV04](http://dblp.uni-trier.de/db/conf/soda/soda2004.html#BeierV04 "").

- \[6\]
Aharon Ben-Tal and Arkadi Nemirovski.

_Lectures on modern convex optimization: analysis, algorithms,_
_and engineering applications_.

SIAM, 2001.

- \[7\]
Robert Bixby and Edward Rothberg.

Progress in computational mixed integer programming–a look back from
the other side of the tipping point.

_Annals of Operations Research_, 149(1):37,
2007.

- \[8\]
Sander Borst, Daniel Dadush, Sophie Huiberts, and Samarth Tiwari.

On the integrality gap of binary integer programs with gaussian data.

In _IPCO_, pages 427–442, 2021.

- \[9\]
Kevin K. H. Cheung, Ambros M. Gleixner, and Daniel E. Steffy.

Verifying integer programming results.

In Friedrich Eisenbrand and Jochen Könemann, editors,
_Integer Programming and Combinatorial Optimization - 19th International_
_Conference, IPCO 2017, Waterloo, ON, Canada, June 26-28, 2017,_
_Proceedings_, volume 10328 of _Lecture Notes in Computer Science_, pages
148–160. Springer, 2017.

doi: 10.1007/978-3-319-59250-3\\\_13.

URL [https://doi.org/10.1007/978-3-319-59250-3\_13](https://doi.org/10.1007/978-3-319-59250-3_13 "").

- \[10\]
Vasek Chvátal.

Hard knapsack problems.

_Operations Research_, 28(6):1402–1411,
1980.

- \[11\]
Thomas F. Coleman, editor.

_Chapter 3 Large sparse linear programming_, pages 35–46.

Springer Berlin Heidelberg, Berlin, Heidelberg, 1984.

ISBN 978-3-540-38796-1.

doi: 10.1007/3-540-12914-6\_3.

URL [https://doi.org/10.1007/3-540-12914-6\_3](https://doi.org/10.1007/3-540-12914-6_3 "").

- \[12\]
Michele Conforti, Gérard Cornuéjols, Giacomo Zambelli, et al.

_Integer programming_, volume 271.

Springer, 2014.

- \[13\]
Sanjeeb Dash.

An exponential lower bound on the length of some classes of
branch-and-cut proofs.

In _International Conference on Integer Programming and_
_Combinatorial Optimization_, pages 145–160. Springer, 2002.

- \[14\]
Santanu S Dey, Marco Molinaro, and Qianyi Wang.

Approximating polyhedra with sparse inequalities.

_Mathematical Programming_, 154(1-2):329–352, 2015.

- \[15\]
Santanu S Dey, Marco Molinaro, and Qianyi Wang.

Analysis of sparse cutting planes for sparse milps with applications
to stochastic milps.

_Mathematics of Operations Research_, 43(1):304–332, 2018.

- \[16\]
Santanu S Dey, Yatharth Dubey, and Marco Molinaro.

Branch-and-bound solves random binary ips in polytime.

In _Proceedings of the 2021 ACM-SIAM Symposium on Discrete_
_Algorithms (SODA)_, pages 579–591. SIAM, 2021.

- \[17\]
M. E. Dyer and A. M. Frieze.

Probabilistic analysis of the multidimensional knapsack problem.

_Mathematics of Operations Research_, 14(1):162–176, 1989.

ISSN 0364765X, 15265471.

URL [http://www.jstor.org/stable/3689842](http://www.jstor.org/stable/3689842 "").

- \[18\]
Alan M Frieze.

On the expected efficiency of branch and bound for the asymmetric
tsp.

2020.

- \[19\]
Andrew V. Goldberg and Alberto Marchetti-Spaccamela.

On finding the exact solution of a zero-one knapsack problem.

In Richard A. DeMillo, editor, _STOC_, pages 359–368. ACM,
1984.

URL
[http://dblp.uni-trier.de/db/conf/stoc/stoc84.html#GoldbergM84](http://dblp.uni-trier.de/db/conf/stoc/stoc84.html#GoldbergM84 "").

- \[20\]
Vladimir Koltchinskii.

_Oracle Inequalities in Empirical Risk Minimization and Sparse_
_Recovery Problems_.

Springer-Verlag, 2011.

- \[21\]
Alisa H Land and Alison G Doig.

An automatic method of solving discrete programming problems.

_Econometrica_, 28:497–520, 1960.

- \[22\]
Hendrik Willem Lenstra, Arjen K Lenstra, Lászl’o Lovász, et al.

Factoring polynomials with rational coeficients.

_Mathematische Annalen_, 261:515–534, 1982.

- \[23\]
Hendrik W Lenstra Jr.

Integer programming with a fixed number of variables.

_Mathematics of operations research_, 8(4):538–548, 1983.

- \[24\]
Jeff T Linderoth and Martin WP Savelsbergh.

A computational study of search strategies for mixed integer
programming.

_INFORMS Journal on Computing_, 11(2):173–187, 1999.

- \[25\]
G. S. Lueker.

On the average difference between the solutions to linear and integer
knapsack problems.

In _Applied Probability – Computer Science, The Interface_,
volume 1. Birkhäuser, 1982.

- \[26\]
Gábor Pataki, Mustafa Tural, and Erick B Wong.

Basis reduction and the complexity of branch-and-bound.

In _Proceedings of the twenty-first annual ACM-SIAM symposium on_
_discrete algorithms_, pages 1254–1261. SIAM, 2010.

- \[27\]
Daniel A Spielman and Shang-Hua Teng.

Smoothed analysis of algorithms: Why the simplex algorithm usually
takes polynomial time.

_Journal of the ACM (JACM)_, 51(3):385–463,
2004.

- \[28\]
V. Vazirani.

_Approximation algorithms_.

Springer, 2001.

ISBN 9783540653677.

URL [http://books.google.com/books?id=EILqAmzKgYIC](http://books.google.com/books?id=EILqAmzKgYIC "").

- \[29\]
Roman Vershynin.

_High-Dimensional Probability: An Introduction with Applications_
_in Data Science_.

Cambridge Series in Statistical and Probabilistic Mathematics.
Cambridge University Press, 2018.

doi: 10.1017/9781108231596.

- \[30\]
Matthias Walter.

Sparsity of lift-and-project cutting planes.

In _Operations Research Proceedings 2012_, pages 9–14.
Springer, 2014.

- \[31\]
Laurence A Wolsey and George L Nemhauser.

_Integer and combinatorial optimization_, volume 55.

John Wiley & Sons, 1999.