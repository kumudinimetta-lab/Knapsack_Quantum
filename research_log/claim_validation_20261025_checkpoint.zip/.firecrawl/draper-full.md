##### Report GitHub Issue

×

Title:

Content selection saved. Describe the issue below:

Description:

Submit without GitHubSubmit in GitHub

![](https://arxiv.org/static/base/1.0.1/images/icons/smileybones-small.svg)arXiv is now an independent nonprofit! [Learn more](https://info.arxiv.org/about) ×

[![arXiv logo](https://arxiv.org/static/base/1.0.1/images/arxiv-logo-primary-light.svg)Back to arXiv](https://arxiv.org/)

[Why HTML?](https://info.arxiv.org/about/accessible_HTML.html) [Report Issue](https://arxiv.org/html/quant-ph/0008033v1# "Report an Issue") [Back to Abstract](https://arxiv.org/abs/quant-ph/0008033v1 "Back to abstract page") [Download PDF](https://arxiv.org/pdf/quant-ph/0008033v1 "Download PDF")

1. [Abstract](https://arxiv.org/html/quant-ph/0008033v1#abstract1 "In Addition on a Quantum Computer")
2. [1 Introduction](https://arxiv.org/html/quant-ph/0008033v1#S1 "In Addition on a Quantum Computer")
3. [2 Classical Addition](https://arxiv.org/html/quant-ph/0008033v1#S2 "In Addition on a Quantum Computer")
4. [3 The Quantum Fourier Transform](https://arxiv.org/html/quant-ph/0008033v1#S3 "In Addition on a Quantum Computer")
5. [4 The Approximate QFT](https://arxiv.org/html/quant-ph/0008033v1#S4 "In Addition on a Quantum Computer")
6. [5 Quantum Addition](https://arxiv.org/html/quant-ph/0008033v1#S5 "In Addition on a Quantum Computer")
7. [6 Implications](https://arxiv.org/html/quant-ph/0008033v1#S6 "In Addition on a Quantum Computer")
8. [References](https://arxiv.org/html/quant-ph/0008033v1#bib "In Addition on a Quantum Computer")

[License: Assumed arXiv.org perpetual non-exclusive license](https://info.arxiv.org/help/license/index.html#licenses-available)

arXiv:quant-ph/0008033v1 \[quant-ph\] 07 Aug 2000

# Addition on a Quantum Computer

Thomas G. Draper

Written: September 1, 1998    Revised: June 15, 2000

###### Abstract

A new method for computing sums on a quantum computer is introduced. This technique uses the quantum Fourier transform and reduces the number of qubits necessary for addition by removing the need for temporary carry bits. This approach also allows the addition of a classical number to a quantum superposition without encoding the classical number in the quantum register. This method also allows for massive parallelization in its execution.

###### Contents

1. [1 Introduction](https://arxiv.org/html/quant-ph/0008033v1#S1 "In Addition on a Quantum Computer")
2. [2 Classical Addition](https://arxiv.org/html/quant-ph/0008033v1#S2 "In Addition on a Quantum Computer")
3. [3 The Quantum Fourier Transform](https://arxiv.org/html/quant-ph/0008033v1#S3 "In Addition on a Quantum Computer")
4. [4 The Approximate QFT](https://arxiv.org/html/quant-ph/0008033v1#S4 "In Addition on a Quantum Computer")
5. [5 Quantum Addition](https://arxiv.org/html/quant-ph/0008033v1#S5 "In Addition on a Quantum Computer")
6. [6 Implications](https://arxiv.org/html/quant-ph/0008033v1#S6 "In Addition on a Quantum Computer")
7. [References](https://arxiv.org/html/quant-ph/0008033v1#bib "In Addition on a Quantum Computer")

## 1 Introduction

Traditionally, addition algorithms designed for a quantum computer have mirrored their classical counterparts\[ [2](https://arxiv.org/html/quant-ph/0008033v1#bib.bib2 ""), [6](https://arxiv.org/html/quant-ph/0008033v1#bib.bib6 ""), [9](https://arxiv.org/html/quant-ph/0008033v1#bib.bib9 "")\], with the necessary extensions for reversible computation. Faster quantum addition algorithms implement carry-save techniques\[ [5](https://arxiv.org/html/quant-ph/0008033v1#bib.bib5 ""), [10](https://arxiv.org/html/quant-ph/0008033v1#bib.bib10 "")\], but still follow a classical model. However, the ideal addition algorithm for a quantum computer may not be similar to its classical counterpart. This paper presents a new paradigm for addition on a quantum computer.

The addition method used takes two values aa and bb, computes F⁡(a)F(a) the quantum Fourier transform (QFT) of aa and then uses bb to evolve F⁡(a)F(a) into F⁡(a+b)F(a+b). The inverse quantum Fourier transform may then be applied and the sum recovered. Since there is a cost of computing the transform before and after the sum, as much computation as possible should be performed in the transform range before leaving.

This paper assumes a rudimentary background in the ideas of quantum computation. For an introduction to quantum computation the reader is encouraged to read Art Pittenger’s, ”An Introduction to Quantum Computing Algorithms”\[ [7](https://arxiv.org/html/quant-ph/0008033v1#bib.bib7 "")\] or Andrew Steane’s, ”Quantum Computing”\[ [8](https://arxiv.org/html/quant-ph/0008033v1#bib.bib8 "")\]. For further study, an excellent searchable pre-print server is maintained by Los Alamos laboratories. Papers on quantum computing/cryptography may be found at http://xxx.lanl.gov/quant-ph.

## 2 Classical Addition

A number of papers have been published concerning the implementation of addition on a quantum computer \[ [2](https://arxiv.org/html/quant-ph/0008033v1#bib.bib2 ""), [5](https://arxiv.org/html/quant-ph/0008033v1#bib.bib5 ""), [7](https://arxiv.org/html/quant-ph/0008033v1#bib.bib7 ""), [9](https://arxiv.org/html/quant-ph/0008033v1#bib.bib9 ""), [10](https://arxiv.org/html/quant-ph/0008033v1#bib.bib10 "")\]. All of the implementations use at least 3​n3n qubits to add two nn-bit numbers. The method presented here follows the outline in \[ [7](https://arxiv.org/html/quant-ph/0008033v1#bib.bib7 "")\]. The adder is composed of two basic unitary computational units.

Carry Gate

A carry gate with the dark bar on the left side is considered to be a normal carry gate executed in reverse order. The following diagram shows how these two unitary gates are combined to form a reversible adder.

Reversible Adder for Two 3-bit Numbers

\|0⟩\|a1⟩\|b1⟩\|0⟩\|a2⟩\|b2⟩\|0⟩\|a3⟩\|b3⟩\|0⟩\|0⟩\|a1⟩\|(+ab)1⟩\|0⟩\|a2⟩\|(+ab)2⟩\|0⟩\|a3⟩\|(+ab)3⟩\|(+ab)4⟩

The construction of an n-bit reversible adder is a straightforward extension of the 3-bit adder. Note that an additional nn qubits were needed as temporary carry bits. These qubits are reversibly set back to zero after they are used so they may be used for later computation. Therefore, even though the input and output may be stored using only 2​n2n qubits, 3​n3n qubits must be used for the computation.

## 3 The Quantum Fourier Transform

For simplification of notation, let e⁡(t)=e2​π​i​te(t)=e^{2\\pi it}. Let a∈𝐙2na\\in{\\bf Z}\_{2^{n}}, the additive group of integers modulo 2n2^{n}. Let anan−1⋯a2a1a\_{n}a\_{n-1}\\cdots a\_{2}a\_{1} be the binary representation for aa, where a=an​2n−1+an−1​2n−2+⋯+a2​21+a1​20a=a\_{n}2^{n-1}+a\_{n-1}2^{n-2}+\\cdots+a\_{2}2^{1}+a\_{1}2^{0}. Then \|a⟩=\|an⟩⊗\|an−1⟩⊗⋯⊗\|a2⟩⊗\|a1⟩\|a\\rangle=\|a\_{n}\\rangle\\otimes\|a\_{n-1}\\rangle\\otimes\\cdots\\otimes\|a\_{2}\\rangle\\otimes\|a\_{1}\\rangle. The quantum Fourier transform (QFT) of \|a⟩\|a\\rangle is the mapping

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|a⟩⟶F2n12n2​∑k=02n−1e⁡(a​k/2n)​\|k⟩.\|a\\rangle\\stackrel{{\\scriptstyle F\_{2^{n}}}}{{\\longrightarrow}}\\frac{1}{2^{\\frac{n}{2}}}\\sum\_{k=0}^{2^{n}-1}e(ak/2^{n})\|k\\rangle. |  | (1) |

It turns out that ( [1](https://arxiv.org/html/quant-ph/0008033v1#S3.E1 "In 3 The Quantum Fourier Transform ‣ Addition on a Quantum Computer")) is unentangled\[ [3](https://arxiv.org/html/quant-ph/0008033v1#bib.bib3 "")\]. Let

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|ϕk​(a)⟩=12​(\|0⟩+e⁡(a/2k)​\|1⟩).\|\\phi\_{k}(a)\\rangle=\\frac{1}{\\sqrt{2}}(\|0\\rangle+e(a/2^{k})\|1\\rangle). |  | (2) |

Then ( [1](https://arxiv.org/html/quant-ph/0008033v1#S3.E1 "In 3 The Quantum Fourier Transform ‣ Addition on a Quantum Computer")) factors as

|     |     |     |
| --- | --- | --- |
|  | ∑k=02n−1e(ak/2n)\|k⟩=\|ϕn(a)⟩⊗⋯⊗\|ϕ2(a)⟩⊗\|ϕ1(a)⟩.\\sum\_{k=0}^{2^{n}-1}e(ak/2^{n})\|k\\rangle=\|\\phi\_{n}(a)\\rangle\\otimes\\cdots\\otimes\|\\phi\_{2}(a)\\rangle\\otimes\|\\phi\_{1}(a)\\rangle. |  |

It is also helpful to notice that e(a/2k)=e(0.ak…a1)e(a/2^{k})=e(0.a\_{k}\\ldots a\_{1}), where (0.ak…a1)(0.a\_{k}\\ldots a\_{1}) is a binary fraction. Therefore, each \|ϕk​(a)⟩\|\\phi\_{k}(a)\\rangle contains the lower kk binary digits of aa. Consider the following two gate operations:

|     |     |     |
| --- | --- | --- |
|  | Conditional RotationHadamard TransformRk=<br>k<br>=<br>k<br>=\[100001000010000​e​(12k)​\]and<br>H<br>=12​\[111−1\]\\begin{array}\[\]{ccc}\\hbox{Conditional Rotation}&&\\hbox{Hadamard Transform}\\\<br>{R\_{k}=\\begin{array}\[\]{c}\\begin{picture}(0.0,0.0)\\put(0.0,5.0){\\line{1}{0}{1.0}}\\put(11.0,5.0){\\line{1}{0}{1.0}}\\put(6.0,5.0){\\circle{10.0}}\\put(0.0,0.0){\\vbox to15.0pt{\\vfill\\hbox to18.0pt{\\hfill$k$\\hfill}\\vfill}}\\end{picture}\\\<br>\\begin{picture}(0.0,0.0)\\put(6.0,5.0){\\circle\*{2.0}}\\put(0.0,5.0){\\line{1}{0}{12.0}}\\put(6.0,5.0){\\line{0}{1}{5.0}}\\end{picture}\\end{array}}={\\begin{array}\[\]{c}\\begin{picture}(0.0,0.0)\\put(6.0,5.0){\\circle\*{2.0}}\\put(0.0,5.0){\\line{1}{0}{12.0}}\\put(6.0,5.0){\\line{0}{-1}{5.0}}\\end{picture}\\\<br>\\begin{picture}(0.0,0.0)\\put(0.0,5.0){\\line{1}{0}{1.0}}\\put(11.0,5.0){\\line{1}{0}{1.0}}\\put(6.0,5.0){\\circle{10.0}}\\put(0.0,0.0){\\vbox to15.0pt{\\vfill\\hbox to18.0pt{\\hfill$k$\\hfill}\\vfill}}\\end{picture}\\end{array}}=\\left\[\\begin{array}\[\]{\*{4}{c}}1&0&0&0\\\<br>0&1&0&0\\\<br>0&0&1&0\\\<br>0&0&0&$$e(\\frac{1}{2^{k}})$$\\end{array}\\right\]&\\hbox{and}&\\begin{array}\[\]{c}\\begin{picture}(0.0,0.0)\\put(1.0,0.0){\\line{0}{1}{10.0}}\\put(11.0,0.0){\\line{0}{1}{10.0}}\\put(1.0,0.0){\\line{1}{0}{10.0}}\\put(1.0,10.0){\\line{1}{0}{10.0}}\\put(0.0,5.0){\\line{1}{0}{1.0}}\\put(11.0,5.0){\\line{1}{0}{1.0}}\\put(0.0,0.0){\\vbox to15.0pt{\\vfill\\hbox to18.0pt{\\hfill H\\hfill}\\vfill}}\\end{picture}\\end{array}=\\frac{1}{\\sqrt{2}}\\left\[\\begin{array}\[\]{cc}1&1\\\<br>1&-1\\end{array}\\right\]\\end{array} |  |

The conditional rotation gate performs a phase rotation between two qubits conditioned on their superposition. For example, if the state between two qubits was α⁡\|00⟩+β⁡\|01⟩+γ⁡\|10⟩+δ⁡\|11⟩\\alpha\|00\\rangle+\\beta\|01\\rangle+\\gamma\|10\\rangle+\\delta\|11\\rangle, then after performing a conditional kk rotation gate their joint state would be α⁡\|00⟩+β⁡\|01⟩+γ⁡\|10⟩+e⁡(1/2k)​δ​\|11⟩\\alpha\|00\\rangle+\\beta\|01\\rangle+\\gamma\|10\\rangle+e(1/2^{k})\\delta\|11\\rangle. The Hadamard transform gate operates on a single qubit and transforms the state α​\|0⟩+β​\|1⟩\\alpha\|0\\rangle+\\beta\|1\\rangle to 12​((α+β)​\|0⟩+(α−β)​\|1⟩)\\frac{1}{\\sqrt{2}}((\\alpha+\\beta)\|0\\rangle+(\\alpha-\\beta)\|1\\rangle).
Computing the QFT may be done according to the following wire diagram.

|     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Quantum Fourier Transform |
| \|an⟩\|a\_{n}\\rangle | H | 2 | ⋯\\cdots | -n1 | n |  |  |  |  | ⋯\\cdots |  |  |  | \|ϕn​(a)⟩\|\\phi\_{n}(a)\\rangle |
| \|an−1⟩\|a\_{n-1}\\rangle |  |  |  |  |  | H | ⋯\\cdots | -⁢n-2 | -⁢n-1 | ⋯\\cdots |  |  |  | \|ϕn−1​(a)⟩\|\\phi\_{n-1}(a)\\rangle |
| ⋮\\vdots |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| \|a2⟩\|a\_{2}\\rangle |  |  |  |  |  |  |  |  |  | ⋯\\cdots | H | 2 |  | \|ϕ2​(a)⟩\|\\phi\_{2}(a)\\rangle |
| \|a1⟩\|a\_{1}\\rangle |  |  |  |  |  |  |  |  |  | ⋯\\cdots |  |  | H | \|ϕ1​(a)⟩\|\\phi\_{1}(a)\\rangle |

To see the effect of the transform on a qubit, we will follow what each gate does to the qubit \|an⟩\|a\_{n}\\rangle.

|     |     |     |
| --- | --- | --- |
| \|an⟩\|a\_{n}\\rangle⟶\\longrightarrow | 12(\|0⟩+e(0.an)\|1⟩)\\frac{1}{\\sqrt{2}}(\|0\\rangle+e(0.a\_{n})\|1\\rangle) | Hadamard transform |
| ⟶\\longrightarrow | 12(\|0⟩+e(0.anan−1)\|1⟩)\\frac{1}{\\sqrt{2}}(\|0\\rangle+e(0.a\_{n}a\_{n-1})\|1\\rangle) | R2R\_{2} rotation conditioned on an−1a\_{n-1} |
| ⋮ | ⋮ |
| ⟶\\longrightarrow | 12(\|0⟩+e(0.anan−1…a1)\|1⟩)\\frac{1}{\\sqrt{2}}(\|0\\rangle+e(0.a\_{n}a\_{n-1}\\ldots a\_{1})\|1\\rangle) | RnR\_{n} rotation conditioned on a1a\_{1} |
| =\|ϕn​(a)⟩=\|\\phi\_{n}(a)\\rangle |  |

## 4 The Approximate QFT

As kk gets large, the conditional rotation associated with kk gets very small, and hence, the rotation matrix approaches the identity. It is natural to ask how good an approximation may be if we do not perform, or are unable to perform, gates below a certain tolerance. Barenco, et. al. proved that in the presence of decoherence, an approximate quantum Fourier transform (AQFT) may in fact be more accurate than a full QFT\[ [1](https://arxiv.org/html/quant-ph/0008033v1#bib.bib1 "")\]. Depending on the decoherence present, the optimal value for kk needed is around log2​n\\hbox{log}\_{2}n. This reduces the number of operations needed for a quantum Fourier transform from 12​n​(n+1)\\frac{1}{2}n(n+1) operations to 12​(2​n−log2​n)​(log2​n−1)≈n​log2​n\\frac{1}{2}(2n-\\hbox{log}\_{2}n)(\\hbox{log}\_{2}n-1)\\approx n\\hbox{log}\_{2}n operations.

## 5 Quantum Addition

The quantum addition is performed using a sequence of conditional rotations which are mutually commutative. The structure is very similar to the quantum Fourier transform, but the rotations are conditioned on nn external bits. This is helpful if we wish to add classical data to quantum data. Since all the control bits are known a priori, it is just a matter of programming to implement the resulting rotations. The addition is performed according to the following diagram.

|     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Transform Addition |
| \|bn⟩\|b\_{n}\\rangle |  |  |  |  |  |  |  |  |  |  |  |  |  | \|bn⟩\|b\_{n}\\rangle |
| \|bn​-​1⟩\|b\_{n\\hbox{-}1}\\rangle |  |  |  |  |  |  |  |  |  |  |  |  |  | \|bn​-​1⟩\|b\_{n\\hbox{-}1}\\rangle |
| ⋮\\vdots |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| \|b2⟩\|b\_{2}\\rangle |  |  | ⋯\\cdots |  |  |  | ⋯\\cdots |  |  | ⋯\\cdots |  |  |  | \|b2⟩\|b\_{2}\\rangle |
| \|b1⟩\|b\_{1}\\rangle |  |  | ⋯\\cdots |  |  |  | ⋯\\cdots |  |  | ⋯\\cdots |  |  |  | \|b1⟩\|b\_{1}\\rangle |
| \|ϕn​(a)⟩\|\\phi\_{n}(a)\\rangle | 1 | 2 | ⋯\\cdots | -1n | n |  | ⋯\\cdots |  |  | ⋯\\cdots |  |  |  | \|ϕn​(a+b)⟩\|\\phi\_{n}(a+b)\\rangle |
| \|ϕn​-​1​(a)⟩\|\\phi\_{n\\hbox{-}1}(a)\\rangle |  |  |  |  |  | 1 | ⋯\\cdots | -2n | -1n | ⋯\\cdots |  |  |  | \|ϕn​-​1​(a+b)⟩\|\\phi\_{n\\hbox{-}1}(a+b)\\rangle |
| ⋮\\vdots |  |  |  |  |  |  |  |  |  |  |  |  |  | ⋮\\vdots |
| \|ϕ2​(a)⟩\|\\phi\_{2}(a)\\rangle |  |  |  |  |  |  |  |  |  |  | 1 | 2 |  | \|ϕ2​(a+b)⟩\|\\phi\_{2}(a+b)\\rangle |
| \|ϕ1​(a)⟩\|\\phi\_{1}(a)\\rangle |  |  |  |  |  |  |  |  |  |  |  |  | 1 | \|ϕ1​(a+b)⟩\|\\phi\_{1}(a+b)\\rangle |

Once again it is helpful to trace the state of one qubit during the computation.

|     |     |     |
| --- | --- | --- |
| \|ϕn​(a)⟩\|\\phi\_{n}(a)\\rangle⟶\\longrightarrow | 12(\|0⟩+e(0.anan−1…a1+0.bn)\|1⟩)\\frac{1}{\\sqrt{2}}(\|0\\rangle+e(0.a\_{n}a\_{n-1}\\ldots a\_{1}+0.b\_{n})\|1\\rangle) | R1R\_{1} rotation from bnb\_{n} |
| ⟶\\longrightarrow | 12(\|0⟩+e(0.anan−1…a1+0.bnbn−1)\|1⟩)\\frac{1}{\\sqrt{2}}(\|0\\rangle+e(0.a\_{n}a\_{n-1}\\ldots a\_{1}+0.b\_{n}b\_{n-1})\|1\\rangle) | R2R\_{2} rotation from bn−1b\_{n-1} |
| ⋮ | ⋮ |
| ⟶\\longrightarrow | 12(\|0⟩+e(0.anan−1…a1+0.bnbn−1…b1)\|1⟩)\\frac{1}{\\sqrt{2}}(\|0\\rangle+e(0.a\_{n}a\_{n-1}\\ldots a\_{1}+0.b\_{n}b\_{n-1}\\ldots b\_{1})\|1\\rangle) | RnR\_{n} rotation from b1b\_{1} |
| =\|ϕn​(a+b)⟩=\|\\phi\_{n}(a+b)\\rangle |  |

Since the implementation of the quantum addition is very similar to the QFT, it is not surprising that there is a more efficient approximate implementation of quantum addition using the same technique as the AQFT. Using analogous reasoning, it is quite clear that the approximate quantum addition can be computed efficiently using only n​log2​nn\\hbox{log}\_{2}n operations as well.

The critical difference between quantum addition and the QFT is that all of the operations commute with each other in quantum addition, whereas the Hadamard transforms necessary to do the QFT require certain ordering. It follows that if a quantum computer can implement numerous independent gate operations simultaneously, the run time will decrease proportionally with its capabilities. Therefore, a quantum computer capable of computing n2\\frac{n}{2} independent 2-qubit gate operations simultaneously, can perform quantum addition in about n+1n+1 time slices. If we are using the AQFT technique of eliminating rotations below a certain threshold, the quantum addition may be performed in log2​n\\hbox{log}\_{2}n time slices. One possible parallel method would be to execute all depth 1 rotations simultaneously, and then all depth 2 rotations, etc. It is clear that each of these are operating on independent qubits. In \[ [10](https://arxiv.org/html/quant-ph/0008033v1#bib.bib10 "")\], Zalka discusses why we may expect this type of parallelism in a quantum computer.

|     |     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Parallel Transform Addition |
| \|bn⟩\|b\_{n}\\rangle |  |  |  |  |  |  |  |  |  |  |  | \|bn⟩\|b\_{n}\\rangle |
| \|bn​-​1⟩\|b\_{n\\hbox{-}1}\\rangle |  |  |  |  |  |  |  |  |  |  |  | \|bn​-​1⟩\|b\_{n\\hbox{-}1}\\rangle |
| ⋮\\vdots |  |  |  |  |  |  |  |  |  |  |  |  |
| \|b2⟩\|b\_{2}\\rangle |  |  | ⋯\\cdots |  |  |  | ⋯\\cdots |  |  | ⋯\\cdots |  | \|b2⟩\|b\_{2}\\rangle |
| \|b1⟩\|b\_{1}\\rangle |  |  | ⋯\\cdots |  |  |  | ⋯\\cdots |  |  | ⋯\\cdots |  | \|b1⟩\|b\_{1}\\rangle |
| \|ϕn​(a)⟩\|\\phi\_{n}(a)\\rangle | 1 |  | ⋯\\cdots |  |  | 2 | ⋯\\cdots |  |  | ⋯\\cdots |  | \|ϕn​(a+b)⟩\|\\phi\_{n}(a+b)\\rangle |
| \|ϕn​-​1​(a)⟩\|\\phi\_{n\\hbox{-}1}(a)\\rangle |  | 1 | ⋯\\cdots |  |  |  | ⋯\\cdots |  |  | ⋯\\cdots |  | \|ϕn​-​1​(a+b)⟩\|\\phi\_{n\\hbox{-}1}(a+b)\\rangle |
| ⋮\\vdots |  |  |  |  |  |  |  |  |  |  |  | ⋮\\vdots |
| \|ϕ2​(a)⟩\|\\phi\_{2}(a)\\rangle |  |  | ⋯\\cdots | 1 |  |  | ⋯\\cdots | 2 |  |  |  | \|ϕ2​(a+b)⟩\|\\phi\_{2}(a+b)\\rangle |
| \|ϕ1​(a)⟩\|\\phi\_{1}(a)\\rangle |  |  | ⋯\\cdots |  | 1 |  |  |  |  |  |  | \|ϕ1​(a+b)⟩\|\\phi\_{1}(a+b)\\rangle |
|  | ⏟\\underbrace{\\hbox to72.0pt{\\vbox to1.50009pt{}}} | ⏟\\underbrace{\\hbox to36.0pt{\\vbox to1.50009pt{}}} |  |  |  |  |
|  | 1st time slice | 2nd |  |  |  |  |
|  | ⏟\\underbrace{\\hbox to180.0pt{\\vbox to1.50009pt{}}} |  |
|  | log2​n\\hbox{log}\_{2}n time slices |  |

## 6 Implications

In Zalka’s paper\[ [10](https://arxiv.org/html/quant-ph/0008033v1#bib.bib10 "")\], he outlines a number of methods for computing Shor’s factorization algorithm on a quantum computer. The impact of the quantum addition algorithm has the greatest impact if we are trying to minimize the qubits necessary to perform a computation. Zalka shows that with a number of refinements, Shor’s algorithm may be computed using only 3​n3n qubits. Replacing the addition used by Zalka with quantum addition allows us to perform Shor’s algorithm using only 2​n2n qubits. It should be noted that these run times are both O⁡(n3)O(n^{3}) in the number of operations. There exist faster algorithms with a run time of O⁡(n2​log​n)O(n^{2}\\hbox{log}n), but these algorithms require substantially more qubits and the qubit reduction from the quantum addition is not nearly so dramatic.

## References

- \[1\] A. Barenco, A. Ekert, K. Suominen, P. Törmä, “Approximate quantum Fourier transform and decoherence”, quant-ph/9601018.

- \[2\] D. Beckman, A. N. Chari, S. Devabhaktuni, J. Preskill, “Efficient networks for quantum factoring”, Phys. Rev. A 54, 1034.

- \[3\] R. Cleve, A. Ekert, C. Macchiavello, M. Mosca, “Quantum algorithms revisited”, quant-ph/9708016.

- \[4\] D. Coppersmith, 1994, “An approximate Fourier transform useful in quantum factoring”, IBM Research Report No. RC19642.

- \[5\] P. Gossett, “Quantum carry-save arithmetic”, quant-ph/9808061.

- \[6\] C. Miquel, J. P. Paz, R. Perazzo, “Factoring in a dissipative quantum computer”, Phys. Rev. A 54, 2605.

- \[7\] A. Pittenger, “An introduction to quantum computing algorithms”, Birkhäuser: 2000.

- \[8\] A. Steane, “Quantum computing”, quant-ph/9709022.

- \[9\] V. Vedral, A. Barenco, A. Ekert, “Quantum networks for elementary arithmetic operations”, Phys. Rev. A 54, 147.

- \[10\] C. Zalka, “Fast Versions of Shor’s quantum factoring algorithm”, quant-ph/9806084.


Experimental support, please
[view the build logs](https://arxiv.org/html/quant-ph/quant-ph/0008033v1/__stdout.txt)
for errors. Generated by
[L\\
A\\
T\\
Exml![[LOGO]](<Base64-Image-Removed>)](https://math.nist.gov/~BMiller/LaTeXML/).


## Instructions for reporting errors

We are continuing to improve HTML versions of papers, and your feedback helps enhance accessibility and mobile
support. To report errors in the HTML that will help us improve conversion and rendering, choose any of the
methods listed below:

- Click the "Report Issue" () button, located in the page header.

**Tip:** You can select the relevant text first, to include it in your report.

Our team has already identified [the following issues](https://github.com/arXiv/html_feedback/issues). We appreciate your time reviewing and reporting rendering errors we
may not have found yet. Your efforts will help us improve the HTML versions for all readers, because disability
should not be a barrier to accessing research. Thank you for your continued support in championing open access for
all.

Have a free development cycle? Help support accessibility at arXiv! Our collaborators at LaTeXML maintain a [list of packages that need conversion](https://github.com/brucemiller/LaTeXML/wiki/Porting-LaTeX-packages-for-LaTeXML), and welcome [developer contributions](https://github.com/brucemiller/LaTeXML/issues).

We gratefully acknowledge support from
our **major funders**,
[**member institutions**](https://info.arxiv.org/about/ourmembers.html), ,
and all contributors.


[About](https://info.arxiv.org/about)· [Help](https://info.arxiv.org/help)· [Contact](https://info.arxiv.org/help/contact.html)· [Subscribe](https://info.arxiv.org/help/subscribe)· [Copyright](https://info.arxiv.org/help/license/index.html)· [Privacy](https://info.arxiv.org/help/policies/privacy_policy.html)· [Accessibility](https://info.arxiv.org/help/web_accessibility.html)· [Operational Status (opens in new tab)](https://status.arxiv.org/)

Major funding support from

[![Simons Foundation](https://arxiv.org/static/base/1.0.1/images/funders/simons-foundation.png)](https://www.simonsfoundation.org/)[![Simons Foundation International](https://arxiv.org/static/base/1.0.1/images/funders/simons-foundation-international.png)](https://www.sfi.org.bm/)[![Schmidt Sciences](https://arxiv.org/static/base/1.0.1/images/funders/schmidt-sciences.png)](https://www.schmidtsciences.org/)