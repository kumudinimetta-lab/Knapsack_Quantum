##### Report GitHub Issue

×

Title:

Content selection saved. Describe the issue below:

Description:

Submit without GitHubSubmit in GitHub

![](https://arxiv.org/static/base/1.0.1/images/icons/smileybones-small.svg)arXiv is now an independent nonprofit! [Learn more](https://info.arxiv.org/about) ×

[![arXiv logo](https://arxiv.org/static/base/1.0.1/images/arxiv-logo-primary-light.svg)Back to arXiv](https://arxiv.org/)

[Why HTML?](https://info.arxiv.org/about/accessible_HTML.html) [Report Issue](https://arxiv.org/html/2310.06623v2# "Report an Issue") [Back to Abstract](https://arxiv.org/abs/2310.06623v2 "Back to abstract page") [Download PDF](https://arxiv.org/pdf/2310.06623v2 "Download PDF")

1. [Abstract](https://arxiv.org/html/2310.06623v2#abstract1 "In A quantum algorithm for solving 0-1 Knapsack problems")
2. [I Introduction](https://arxiv.org/html/2310.06623v2#S1 "In A quantum algorithm for solving 0-1 Knapsack problems")
3. [II Previous Work](https://arxiv.org/html/2310.06623v2#S2 "In A quantum algorithm for solving 0-1 Knapsack problems")
4. [III Preliminaries](https://arxiv.org/html/2310.06623v2#S3 "In A quantum algorithm for solving 0-1 Knapsack problems")
5. [IV Methods](https://arxiv.org/html/2310.06623v2#S4 "In A quantum algorithm for solving 0-1 Knapsack problems")
6. [V Results](https://arxiv.org/html/2310.06623v2#S5 "In A quantum algorithm for solving 0-1 Knapsack problems")
7. [VI Discussion and Conclusions](https://arxiv.org/html/2310.06623v2#S6 "In A quantum algorithm for solving 0-1 Knapsack problems")
8. [References](https://arxiv.org/html/2310.06623v2#bib "In A quantum algorithm for solving 0-1 Knapsack problems")
9. [A Supplementary Information](https://arxiv.org/html/2310.06623v2#A1 "In A quantum algorithm for solving 0-1 Knapsack problems")
   1. [A.1 Classical Methods](https://arxiv.org/html/2310.06623v2#A1.SS1 "In Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
   2. [A.2 Branching strategy](https://arxiv.org/html/2310.06623v2#A1.SS2 "In Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      1. [A.2.1 Biased Hadamard Gates](https://arxiv.org/html/2310.06623v2#A1.SS2.SSS1 "In A.2 Branching strategy ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      2. [A.2.2 Construction of the layer unitaries](https://arxiv.org/html/2310.06623v2#A1.SS2.SSS2 "In A.2 Branching strategy ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
   3. [A.3 Quantum maximum finding](https://arxiv.org/html/2310.06623v2#A1.SS3 "In Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
   4. [A.4 Runtime calculator](https://arxiv.org/html/2310.06623v2#A1.SS4 "In Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      1. [A.4.1 QTG as a state sieve](https://arxiv.org/html/2310.06623v2#A1.SS4.SSS1 "In A.4 Runtime calculator ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      2. [A.4.2 Amplitude Amplification](https://arxiv.org/html/2310.06623v2#A1.SS4.SSS2 "In A.4 Runtime calculator ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
   5. [A.5 Resource estimation](https://arxiv.org/html/2310.06623v2#A1.SS5 "In Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      1. [A.5.1 Qubit count](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS1 "In A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      2. [A.5.2 QFT](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS2 "In A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      3. [A.5.3 QFT Adder](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS3 "In A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      4. [A.5.4 QFT Subtractor](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS4 "In A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      5. [A.5.5 Comparison](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS5 "In A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      6. [A.5.6 QTG](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS6 "In A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      7. [A.5.7 QMaxSearch](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS7 "In A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
   6. [A.6 Benchmarking of competitive quantum methods](https://arxiv.org/html/2310.06623v2#A1.SS6 "In Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      1. [A.6.1 Nested Quantum Search](https://arxiv.org/html/2310.06623v2#A1.SS6.SSS1 "In A.6 Benchmarking of competitive quantum methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")
      2. [A.6.2 Quantum branch-and-bound](https://arxiv.org/html/2310.06623v2#A1.SS6.SSS2 "In A.6 Benchmarking of competitive quantum methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")

[License: CC BY 4.0](https://info.arxiv.org/help/license/index.html#licenses-available)

arXiv:2310.06623v2 \[quant-ph\] 19 Nov 2024

# A quantum algorithm for solving 0-1 Knapsack problems

Sören Wilkening
Email: [soeren.wilkening@itp.uni-hannover.de](mailto:soeren.wilkening@itp.uni-hannover.de)Affiliation: Institut für Theoretische Physik, Leibniz Universität Hannover, Germany
Affiliation: Volkswagen AG, Berliner Ring 2, 38440 Wolfsburg
Andreea-Iulia Lefterovici
Affiliation: Institut für Theoretische Physik, Leibniz Universität Hannover, Germany
Lennart Binkowski
Affiliation: Institut für Theoretische Physik, Leibniz Universität Hannover, Germany
Michael Perk
Affiliation: Institut für Betriebssysteme und Rechnerverbund, Technische Universität Braunschweig, Germany
Sándor P. Fekete
Affiliation: Institut für Betriebssysteme und Rechnerverbund, Technische Universität Braunschweig, Germany
Tobias J. Osborne
Affiliation: Institut für Theoretische Physik, Leibniz Universität Hannover, Germany

###### Abstract

Here we present two novel contributions for achieving quantum advantage in solving difficult optimisation problems, both in theory and foreseeable practice.
(1) We introduce the “Quantum Tree Generator”, an approach to generate in superposition all feasible solutions of a given instance, yielding together with amplitude amplification the optimal solutions for 00-11 knapsack problems.
The QTG offers massive memory savings and enables competitive runtimes compared to the classical state-of-the-art knapsack solvers (such as COMBO, Gurobi, CP-SAT, Greedy) already for instances involving as few as 100 variables.
(2) By introducing a new runtime calculation technique that exploits logging data from the classical solver COMBO, we can predict the runtime of our method way beyond the range of existing quantum platforms and simulators, for various benchmark instances with up to 600 variables.
Combining both of these innovations, we demonstrate the QTG’s potential _practical_ quantum advantage for large-scale problems, indicating an effective approach for combinatorial optimisation problems.

## I Introduction

Box 1: Quantum Tree GeneratorInput:Knapsack instance KPn⁡(𝒑,𝒘,c)\\KP\_{n}(\\bm{p},\\bm{w};c), feasible assignment 𝒙\\bm{x}1\. Initialize:Initialize the three registers in the state \|𝟎⟩1​\|c⟩2​\|0⟩3\\ket{\\bm{0}}^{1}\\ket{c}^{2}\\ket{0}^{3}.2\. Tree traversing:For each item m=1,…,nm=1,\\ldots,n, perform the following steps:(a) Create a superposition. Apply biased Hadamard H′ on the mm-th qubit in register 1, controlled on whether wmw\_{m} does not exceed the remaining capacity stored in the register 2.(b) Update the remaining capacities. Subtract wmw\_{m} from the state of register 2, controlled on the mm-th qubit in register 1.(c) Update the total profit. Add pmp\_{m} to the state of register 3, controlled on the mm-th qubits in register 1.Example:Knapsack instance KP4⁡(𝒑,𝒘,7)\\KP\_{4}(\\bm{p},\\bm{w};7) with weights 𝒘\\bm{w} = (2, 2, 1, 5) and profits 𝒑\\bm{p} = (6, 2, 1, 2).
H’ is a biased Hadamard gate.

In recent years, the prospect of real-world quantum computing has raised hopes for solving hard combinatorial optimisation problems, leading to tremendous theoretical work on developing and analysing suitable quantum methods.
On the one hand, it is reasonable to expect in the next years that quantum information processing devices will comprise many thousands of physical qubits \[ [1](https://arxiv.org/html/2310.06623v2#bib.bib1 "")\].
On the other hand, this progress is inhibited by two major challenges.

At the lower level, one challenge emerges from the effects of decoherence \[ [2](https://arxiv.org/html/2310.06623v2#bib.bib2 ""), [3](https://arxiv.org/html/2310.06623v2#bib.bib3 "")\].
The current error rates experienced by all extant quantum devices place them well above the fault tolerance threshold \[ [4](https://arxiv.org/html/2310.06623v2#bib.bib4 "")\] required for the effective deployment of quantum error correction \[ [5](https://arxiv.org/html/2310.06623v2#bib.bib5 "")\].
Further critical roadblocks, depending on platform \[ [6](https://arxiv.org/html/2310.06623v2#bib.bib6 ""), [7](https://arxiv.org/html/2310.06623v2#bib.bib7 ""), [8](https://arxiv.org/html/2310.06623v2#bib.bib8 ""), [9](https://arxiv.org/html/2310.06623v2#bib.bib9 ""), [10](https://arxiv.org/html/2310.06623v2#bib.bib10 ""), [11](https://arxiv.org/html/2310.06623v2#bib.bib11 ""), [12](https://arxiv.org/html/2310.06623v2#bib.bib12 ""), [13](https://arxiv.org/html/2310.06623v2#bib.bib13 ""), [14](https://arxiv.org/html/2310.06623v2#bib.bib14 "")\], also include the difficulties of implementing mid-circuit measurements \[ [15](https://arxiv.org/html/2310.06623v2#bib.bib15 "")\] and entangling gates \[ [16](https://arxiv.org/html/2310.06623v2#bib.bib16 "")\].
That quantum computers deliver useful improved and accelerated solutions is expected in the long term when logical qubits are plentiful and cheap.
However, in the near- and mid-term, the situation is subtle and nuanced. Justifying the considerable effort for ensuing research and development hinges on the expected practical usefulness of quantum devices.

At a higher level, the challenge lies in demonstrating quantum advantage in practical applications.
In recent times, there has indeed been considerable optimism that combinatorial optimisation problems provide a rich class of application areas whose solutions quantum computers will improve \[ [17](https://arxiv.org/html/2310.06623v2#bib.bib17 "")\].
Although quantum devices have already demonstrated accelerated solutions for synthetic problems \[ [18](https://arxiv.org/html/2310.06623v2#bib.bib18 "")\], there has been, to date, no conclusive demonstration of a practical quantum advantage for realistic instances in comparison with the _best classical approach_.
Quantum heuristics \[ [19](https://arxiv.org/html/2310.06623v2#bib.bib19 "")\] currently do not provide competitive results when compared with classical solvers, such as CPLEX \[ [20](https://arxiv.org/html/2310.06623v2#bib.bib20 "")\], GUROBI \[ [21](https://arxiv.org/html/2310.06623v2#bib.bib21 "")\] and CP-SAT \[ [22](https://arxiv.org/html/2310.06623v2#bib.bib22 "")\] which routinely solve problems involving thousands of variables to _provable optimality_.

On the quantum side, the development of new algorithms has been almost exclusively driven by theoretical measures, in particular by worst-case, asymptotic runtime analysis.
In particular, Grover’s algorithm \[ [23](https://arxiv.org/html/2310.06623v2#bib.bib23 "")\] and its provable quadratic speedup over unstructured linear search have spawned a rich manifold of quantum routines
\[ [24](https://arxiv.org/html/2310.06623v2#bib.bib24 ""), [25](https://arxiv.org/html/2310.06623v2#bib.bib25 ""), [26](https://arxiv.org/html/2310.06623v2#bib.bib26 ""), [27](https://arxiv.org/html/2310.06623v2#bib.bib27 "")\].
However, these theoretical insights have to be taken with a grain of salt when it comes to their practical applicability:
A favourable asymptotic worst-case complexity does not necessarily imply a speedup for instance sizes that are relevant in practice.
This already holds true for the comparison of two purely classical algorithms.
The simplex method \[ [28](https://arxiv.org/html/2310.06623v2#bib.bib28 "")\] for solving linear programs has a worst-case runtime exponential in the input dimension, but remains the best-performing algorithm in practice.
In contrast, the ellipsoid method \[ [29](https://arxiv.org/html/2310.06623v2#bib.bib29 "")\] with worst-case runtime polynomial in the input dimension, performs poorly in practice in most cases, especially when compared to the simplex method \[ [30](https://arxiv.org/html/2310.06623v2#bib.bib30 "")\].
This immanent gap between asymptotic worst-case behaviour and practical performance does not necessarily shrink when the compared algorithms run on completely different architectures.

Thus, we are faced with a fundamental dilemma when exploring the possible real-world impact of quantum methods for practical optimisation: On the one hand, the justification for building and tuning quantum devices hinges on their practical impact; on the other hand, gauging their usefulness by running real-world benchmarks is impossible before these devices exist. A possible recourse for the latter is to perform classical simulations of quantum methods; however, possibilities for general gate-based simulations are saturated both in memory and runtime at around 5050 qubits \[ [31](https://arxiv.org/html/2310.06623v2#bib.bib31 "")\], which is far too few to evaluate the performance of a quantum heuristic against realistic benchmark instances (which typically would require between 100100-1000010000 qubits).

One recent approach \[ [32](https://arxiv.org/html/2310.06623v2#bib.bib32 "")\] for obtaining realistic estimates for runtimes of quantum algorithms beyond asymptotic scaling is to derive quantitative complexity bounds for quantum routines, rather than asymptotic worst-case 𝒪\\mathcal{O}-expressions.
These bounds are fed with data obtained by running classical versions of these routines.
In this light, a recent study \[ [33](https://arxiv.org/html/2310.06623v2#bib.bib33 "")\] was able to show that the quantum version of the simplex method \[ [34](https://arxiv.org/html/2310.06623v2#bib.bib34 "")\], despite its promising asymptotic runtime, cannot outperform the standard simplex method on any reasonable benchmark instance.
While this framework is powerful for benchmarking quantum routines when having formulas for the expected runtime, it does not provide enough tools for analysing quantum heuristics.

In this paper, we directly take on the twin challenges of (1) developing a quantum heuristic method to solve combinatorial optimisation problems and (2) evaluating the performance of this heuristic method against benchmark instances.
We target the knapsack problem – the hydrogen atom of combinatorial optimisation problems – which frequently appears in real-world applications such as portfolio optimisation and securitisation \[ [35](https://arxiv.org/html/2310.06623v2#bib.bib35 "")\], and often arises as a subproblem in more complex problems such as resource allocation and scheduling.
For this fundamental problem, we develop a quantum method we name Quantum Tree Generator (QTG) to generate all feasible solutions in superposition, which yields the optimal solution in concert with quantum amplitude amplification \[ [24](https://arxiv.org/html/2310.06623v2#bib.bib24 "")\].
In order to evaluate the performance of the QTG-based search on realistic benchmark instances, we also introduce a novel technique to compute the quantum algorithm’s runtime:
Extracting crucial logging data from the classical solution, obtained via the current champion COMBO \[ [36](https://arxiv.org/html/2310.06623v2#bib.bib36 "")\] method, we can infer the expected number of cycles required by the QTG-based method to solve the same instance (importantly, we cannot simulate the method, only infer the expected runtime in elementary gates using this side information).
Our benchmarking leads us to predict that the QTG-based method requires fewer cycles to solve realistic instances already at 100100 variables.
Most dramatic, however, are the memory requirements:
The COMBO method – based in part on dynamic programming – can make huge demands on memory, with 101010^{10} bits being routinely requested.
The QTG-based search, however, requires only a constant multiple of the variable number in logical qubits.
This leads to a possible quantum advantage in both time and space starting at as few as 100100 variables, offering a clear perspective of a _practical_ quantum advantage for instance sizes of real-world relevance.

## II Previous Work

In 1995, Pisinger developed the branch-and-bound approach called EXPKNAP \[ [37](https://arxiv.org/html/2310.06623v2#bib.bib37 "")\].
At the time, the algorithm stood out as one of the most efficient algorithms documented in literature for the 0-1 knapsack problem (0-1-KP\\KP).
In recent years, integer programming (IP) and constraint programming (CP) solvers emerged as the industry standard for various optimisation problems. The integer programming solver GUROBI (based on branch and cut methods) and CP-SAT \[ [22](https://arxiv.org/html/2310.06623v2#bib.bib22 "")\] (portfolio solver based on constraint programming) are popular solvers in their respective field.
In 1999, the COMBO algorithm emerged as a dynamic programming solver specifically designed for 0-1-KP\\KP.
Known for its stable behaviour due to its pseudo-polynomial time complexity bound \[ [36](https://arxiv.org/html/2310.06623v2#bib.bib36 "")\], it stands as the current leading solver for this problem.

Figure 1:
The action of the QTG on the KP4⁡(𝒑,𝒘,7)\\KP\_{4}(\\bm{p},\\bm{w};7) example.
The path register holds 16 computational basis states – here depicted as the corners of a hypercube – representing all feasible (green dots) and infeasible (orange dots) four-item paths.
The state \|1110⟩\\ket{1110} represents the optimal solution.
The initial state of the system is \|0000⟩\\ket{0000}, corresponding to an entirely empty knapsack.
After one application of the QTG, the optimal state’s sampling probability is increased to 29%29\\%.
After 12 applications of the QTG, the optimal state is reached.

Quantum methods to tackle constrained optimisation (and closely related satisfaction) problems have been previously studied in works such as nested quantum search \[ [25](https://arxiv.org/html/2310.06623v2#bib.bib25 "")\] and quantum branch-and-bound \[ [27](https://arxiv.org/html/2310.06623v2#bib.bib27 ""), [38](https://arxiv.org/html/2310.06623v2#bib.bib38 "")\].
Nested quantum search is an enhancement over Grover’s \[ [23](https://arxiv.org/html/2310.06623v2#bib.bib23 "")\] unstructured search algorithm for solving constrained satisfaction problems.
It consists of applying Grover’s search on a sub-problem to identify potential solutions, followed by another Grover’s search application on the remaining variables to extract the actual solutions from the set of potential solutions.
This prepares a uniform superposition over the set of feasible assignments.
The number of iterations for the nested quantum search to find the optimal solution is 𝒪⁡(dα)\\mathcal{O}(\\sqrt{d^{\\alpha}}), where dd is the dimension of the search space, and α<1\\alpha<1 is a constant depending on the nesting depth.
Quantum branch-and-bound (QBnB) uses quantum backtracking \[ [26](https://arxiv.org/html/2310.06623v2#bib.bib26 ""), [39](https://arxiv.org/html/2310.06623v2#bib.bib39 "")\] as a subroutine.
The algorithm improves upon nested quantum search by searching at each level of the tree only for partial assignments that satisfy the constraints and show promise to deliver optimal solutions based on unassigned variables.
The number of iterations for the quantum branch-and-bound methods to find the optimal solution is 𝒪⁡(T​p)\\mathcal{O}(\\sqrt{Tp}), where TT is the number of nodes and pp is the depth of the tree.
Both algorithms achieve a quadratic speedup over their respective classical counter parts.
We benchmark these methods in [Subsection A.6](https://arxiv.org/html/2310.06623v2#A1.SS6 "A.6 Benchmarking of competitive quantum methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems").

In contrast, our method prepares a superposition of all feasible states by sequentially imposing the constraints of an instance (as shown in [Figure 1](https://arxiv.org/html/2310.06623v2#S2.F1 "Figure 1 ‣ II Previous Work ‣ A quantum algorithm for solving 0-1 Knapsack problems")),
followed by an augmented version of amplitude amplification to get the optimal solution.

## III Preliminaries

Consider a set of nn items, each of which has some integer profit pm>0p\_{m}>0 and weight wm>0w\_{m}>0.
The objective is to select a subset of items of maximum cumulative profit, so that their cumulative weight do not exceed some threshold c>0c>0).
An instance of the 0-1-KP is completely defined by the number nn of items, a list 𝒑≔(p1,…,pn)\\bm{p}\\coloneqq(p\_{1},\\ldots,p\_{n}) of profit values, a list 𝒘≔(w1,…,wn)\\bm{w}\\coloneqq(w\_{1},\\ldots,w\_{n}) of weights, and the capacity cc;
we address a given instance in the following by KPn⁡(𝒑,𝒘,c)\\KP\_{n}(\\bm{p},\\bm{w};c).
It has the following formulation as an Integer Linear Program (ILP):

|     |     |     |     |
| --- | --- | --- | --- |
|  | maximise ∑m=1npm​xmsubject to ∑m=1nwm​xm≤cxm∈{0,1},m=1,…,n.\\displaystyle\\begin{split}\\text{maximise }&\\sum\_{m=1}^{n}p\_{m}x\_{m}\\\<br>\\text{subject to }&\\sum\_{m=1}^{n}w\_{m}x\_{m}\\leq c\\\<br>x\_{m}\\in\\{0,1\\},&\\quad m=1,\\ldots,n.\\end{split} |  | (1) |

For the 0-1-KP, the binary variable xmx\_{m} encodes the choice of either including item mm into the knapsack (xm=1x\_{m}=1) or omitting it (xm=0x\_{m}=0).
Therefore, a complete assignment of all items (also called _path_) constitutes a bit string of length nn.

The standard procedure to formulate the 0-1-KP for study via a quantum computer is to assign one qubit to each decision variable xmx\_{m}, thus representing the paths 𝒙=x1​…​xn\\bm{x}=x\_{1}\\ldots x\_{n} as computational basis states \|𝒙⟩1\\ket{\\bm{x}}^{1} in an nn-qubit _path register_ ℋ1=ℂ2n\\mathcal{H}\_{1}=\\mathbb{C}^{2^{n}}.
Additionally, for any feasible assignment 𝒙\\bm{x}, we store the binary representation of the remaining capacity c−∑m=1nwm​xmc-\\sum\_{m=1}^{n}w\_{m}x\_{m} as a quantum state \|c𝒙⟩2\\ket{c\_{\\bm{x}}}^{2} in a \|cbin\|\\absolutevalue{{c}\_{\\text{bin}}}-qubit _capacity register_ ℋ2\\mathcal{H}\_{2}.111



With \|abin\|=⌊log2​a⌋+1\\absolutevalue{{a}\_{\\text{bin}}}=\\lfloor\\log\_{2}a\\rfloor+1 we denote the length of the binary representation of aa.
The total profit is stored as a state \|P𝒙⟩3\\ket{P\_{\\bm{x}}}^{3} in a \|Pbin\|\\absolutevalue{{P}\_{\\text{bin}}}-qubit _profit register_ ℋ3\\mathcal{H}\_{3}, where PP is any upper bound on the optimal profit.
Furthermore, we optimise the depth of the circuit by using a max⁡(n,\|cbin\|,\|Pbin\|)\\max(n,\\absolutevalue{{c}\_{\\text{bin}}},\\absolutevalue{{P}\_{\\text{bin}}})-qubit ancilla register ℋa\\mathcal{H}\_{\\ancilla}.
The total number of used qubits in the composite register ℋ=ℋ1⊗ℋ2⊗ℋ3⊗ℋa\\mathcal{H}=\\mathcal{H}\_{1}\\otimes\\mathcal{H}\_{2}\\otimes\\mathcal{H}\_{3}\\otimes\\mathcal{H}\_{\\ancilla} is therefore given by

|     |     |     |     |
| --- | --- | --- | --- |
|  | n+\|cbin\|+\|Pbin\|+max⁡(n,\|cbin\|,\|Pbin\|).n+\\absolutevalue{{c}\_{\\text{bin}}}+\\absolutevalue{{P}\_{\\text{bin}}}+\\max(n,\\absolutevalue{{c}\_{\\text{bin}}},\\absolutevalue{{P}\_{\\text{bin}}}). |  | (2) |

Our quantum algorithm for solving 0-1-KP operates entirely on the aforementioned composite register.
The quantum routine is fundamentally based on two main ingredients:

- 1.


a state preparation circuit that creates a superposition of all valid paths along with their total profit and remaining capacity as composite quantum states.

- 2.


an augmented quantum amplitude amplification \[ [24](https://arxiv.org/html/2310.06623v2#bib.bib24 "")\] which increases the success probability of measuring the optimal solution while avoiding endless loops.


## IV Methods

Figure 2: Memory requirements for quantum methods (QBnB and QTG-based search) in comparison with standard classical solvers. IP (Gurobi) and CP-SAT were executed for the same time as it took COMBO to find OPT to have a fairer comparison of the used memory. As a result, these solvers were unable to find the optimal solution for all benchmark instances.

The entire state preparation circuit, the Quantum Tree Generator (QTG) 𝒢\\mathcal{G}, arises as a cascade of nn _layer unitaries_ UmU\_{m}, i.e., 𝒢=∏m=1nUm\\mathcal{G}=\\prod\_{m=1}^{n}U\_{m}.
Applying the QTG to the initial state \|𝟎⟩1​\|c⟩2​\|0⟩3\\ket{\\bm{0}}^{1}\\ket{c}^{2}\\ket{0}^{3} generates a (generally non-uniform) superposition of all valid paths.
The QTG iteratively includes/excludes all items in a weighted superposition while checking for feasibility and updating the capacity and profit registers.
First, for every path, it is checked whether the remaining capacity covers the weight of the current item mm.
Next, every path that can include the item will be branched using a biased Hadamard gate Hbxm{}^{x\_{m}}\_{b}222



For brevity, we also write H’ when the parameters are either clear from the context or not relevant.
defined as

|     |     |     |     |
| --- | --- | --- | --- |
|  | Hb0=Ry​(2​acos⁡1+b2+b)=12+b​(1+b−111+b),Hb1=Ry​(2​acos⁡12+b)=12+b​(1−1+b1+b1),\\begin{split}\\text{H}^{0}\_{b}\\hskip-2.84544pt&=\\hskip-2.84544pt\\text{Ry}\\bigg(2\\operatorname{acos}{\\sqrt{\\frac{1+b}{2+b}}}\\bigg)\\hskip-2.84544pt=\\hskip-2.84544pt\\frac{1}{\\sqrt{2+b}}\\begin{pmatrix}\\sqrt{1+b}&-1\\\<br>1&\\sqrt{1+b}\\end{pmatrix},\\\<br>\\text{H}^{1}\_{b}\\hskip-2.84544pt&=\\hskip-2.84544pt\\text{Ry}\\bigg(2\\operatorname{acos}{\\sqrt{\\frac{1}{2+b}}}\\bigg)\\hskip-2.84544pt=\\hskip-2.84544pt\\frac{1}{\\sqrt{2+b}}\\begin{pmatrix}1&-\\sqrt{1+b}\\\<br>\\sqrt{1+b}&1\\end{pmatrix},\\end{split} |  | (3) |

where xmx\_{m} is the mm-th bit of an intermediate solution 𝒙\\bm{x}.
Upon successful item inclusion, the item’s weight is subtracted from the capacity register’s state and its profit is added to the profit register’s state.
Both, subtraction and addition, are conducted using Quantum Fourier Transform (QFT) adders \[ [40](https://arxiv.org/html/2310.06623v2#bib.bib40 "")\].
In total, the unitaries UmU\_{m} are comprised of three components Um=Um3​Um2​Um1U^{\\vphantom{1}}\_{m}=U^{3}\_{m}\\,U^{2}\_{m}\\,U^{1}\_{m}:

|     |     |     |     |
| --- | --- | --- | --- |
|  | Um1=C≥wm2​(Hbxm)Um2=Cm1​(SUBwm)Um3=Cm1​(ADDpm).\\displaystyle\\begin{split}U^{1}\_{m}&=C^{2}\_{\\geq w\_{m}}\\left(\\text{H}^{x\_{m}}\_{b}\\right)\\\<br>U^{2}\_{m}&=C^{1}\_{m}\\left(\\text{SUB}\_{w\_{m}}\\right)\\\<br>U^{3}\_{m}&=C^{1}\_{m}\\left(\\text{ADD}\_{p\_{m}}\\right).\\end{split} |  | (4) |

We denote the control of the biased Hadamard gates with C≥wm2C\_{\\geq w\_{m}}^{2} because it asks whether the second register’s state is greater or equal to the integer wmw\_{m}.
Subtract and addition are controlled on the mm-th qubit in the first register: Cm1C^{1}\_{m}.
The bias bb in order to maximise the sampling probability of a path 𝒙\\bm{x} within the superposition created by the QTG is given by

|     |     |     |     |
| --- | --- | --- | --- |
|  | bopt=nΔ−2≈nΔ,\\displaystyle b\_{\\opt}=\\frac{n}{\\Delta}-2\\approx\\frac{n}{\\Delta}, |  | (5) |

where Δ≔Δ⁡(𝒙′,𝒙)\\Delta\\coloneqq\\Delta(\\bm{x}^{\\prime},\\bm{x}) is the Hamming distance of 𝒙\\bm{x} to a given intermediate solution 𝒙′\\bm{x}^{\\prime}.
More details on the construction of the biased Hadamard gates Hbxm{}^{x\_{m}}\_{b} and unitaries UmU\_{m} can be found in [Subsection A.2](https://arxiv.org/html/2310.06623v2#A1.SS2 "A.2 Branching strategy ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems").
The concept of the QTG is summarised in [Box 1](https://arxiv.org/html/2310.06623v2#S1 "I Introduction ‣ A quantum algorithm for solving 0-1 Knapsack problems"), along with the KP4⁡(𝒑,𝒘,7)\\KP\_{4}(\\bm{p},\\bm{w};7) circuit example.

Figure 3: Comparison of quantum methods (QBnB and QTG-based search) with the classical methods COMBO and CTG, for different group numbers gg. Note that the values for QTG are realistic estimates, based on simulation (for g=2g=2) and calibrated estimates (for g≥2g\\geq 2); on the other hand, values for QBnB are lower bounds, based on several benevolent assumptions, so a realistic runtime can be expected to be higher; see [subsubsection A.6.2](https://arxiv.org/html/2310.06623v2#A1.SS6.SSS2 "A.6.2 Quantum branch-and-bound ‣ A.6 Benchmarking of competitive quantum methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems"). For larger values of gg, computational effort for full QTG simulation is excessive, so we provide estimates for QTG derived from CTG and justified in [subsubsection A.2.1](https://arxiv.org/html/2310.06623v2#A1.SS2.SSS1 "A.2.1 Biased Hadamard Gates ‣ A.2 Branching strategy ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems").

The superposition created by the QTG is further manipulated in order to increase the probability of measuring the optimal solution states.
For this, we employ quantum maximum finding (QMaxSearch) \[ [41](https://arxiv.org/html/2310.06623v2#bib.bib41 "")\], which iteratively calls an amplitude amplification (QSearch) \[ [24](https://arxiv.org/html/2310.06623v2#bib.bib24 "")\] routine.
The intermediate best solution’s total profit provides the current threshold and is therefore entirely evaluated on the third register.
More details can be found in [Subsection A.3](https://arxiv.org/html/2310.06623v2#A1.SS3 "A.3 Quantum maximum finding ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems").

We further choose a bias of b=n/4b=n/4, based on the calculations in [Subsection A.2](https://arxiv.org/html/2310.06623v2#A1.SS2 "A.2 Branching strategy ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems"), and a maximum number of M=700+n2/16M=700+n^{2}/16 Grover iterations within QSearch.
In a classical preprocessing step, we sort the list of items by decreasing density (profit versus cost), and obtain an initial threshold for QMaxSearch by greedily packing as many items into the knapsack as possible (this approach is also called Greedy).

By combining the application of the QTG (see [Figure 1](https://arxiv.org/html/2310.06623v2#S2.F1 "Figure 1 ‣ II Previous Work ‣ A quantum algorithm for solving 0-1 Knapsack problems") for the KP4⁡(𝒑,𝒘,7)\\KP\_{4}(\\bm{p},\\bm{w};7) example), the phase flip operator within QSearch, and quantum measurements with a detailed analysis of the resource requirements of every subcircuit, we calculate the number of necessary quantum cycles for obtaining the optimal solution with a certain success probability.
More details can be found in [Subsection A.4](https://arxiv.org/html/2310.06623v2#A1.SS4 "A.4 Runtime calculator ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") and [Subsection A.5](https://arxiv.org/html/2310.06623v2#A1.SS5 "A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems").
Our analysis makes the following crucial assumptions:

- 1.


all qubits and gates are noiseless, logical components.

- 2.


all single-qubit gates, single-controlled single-qubit rotations, and Toffoli gates together constitute a universal set of elementary gates of equal implementation cost.

- 3.


disjoint gates can be executed in parallel, constituting a single cycle on the QPU.


Lastly, the QTG can be dequantised in order to yield a probabilistic classical algorithm:
Starting from the all-zero string 𝟎\\bm{0}, iterate through all items/bits xmx\_{m} and apply conditioned bit flips with probability \|(Hbxm)12\|2\\absolutevalue{(\\text{H}\_{b}^{x\_{m}})\_{1 2}}^{2}.
The condition C≥wm2C\_{\\geq w\_{m}}^{2} can be realised classically.
The entire algorithm then consists of sampling multiple times from the generated distribution of bit strings and updating the current solution whenever a better candidate was sampled.
More details can be found in [subsubsection A.2.1](https://arxiv.org/html/2310.06623v2#A1.SS2.SSS1 "A.2.1 Biased Hadamard Gates ‣ A.2 Branching strategy ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems").
We name this quantum-inspired method the _Classical Tree Generator_ (CTG).
Similar (although not quantum-inspired) constructions already exist in the literature \[ [42](https://arxiv.org/html/2310.06623v2#bib.bib42 "")\].

## V Results

We demonstrate the capabilities of our QTG-based search on a diverse set of benchmark instances.
All experiments were carried out on a regular desktop workstation with an
AMD Ryzen 7 5800X (8×3.8​GHz8\\times 3.8\\GHz) CPU and 128​GB128\\GB of RAM.
Instances were produced using a state-of-the-art instance generator from [Jooken et al. \[43\]](https://arxiv.org/html/2310.06623v2#bib.bib43 "") that was made available in \[ [44](https://arxiv.org/html/2310.06623v2#bib.bib44 "")\].
The problem instances involve items partitioned into groups with exponentially decreasing profits and weights.
Items within the same group have similar, slightly perturbed profits and weights. The last group differs by having uncorrelated small profits and weights, introducing a variety of profit-weight ratios.
The generator created six instances for every value 2≤g≤102\\leq g\\leq 10 (number of groups) and size n=50,100,…,600n=50,100,\\ldots,600. All instances were generated with capacity c=10 000 000 000c=10\\,000\\,000\\,000. This yielded a total of 648648 benchmark instances with various difficulties.

We compare COMBO’s and CTG’s classical runtime as well as runtime calculations for the QTG-bases search and the quantum branch-and-bound method proposed by [Chakrabarti et al. \[38\]](https://arxiv.org/html/2310.06623v2#bib.bib38 "").
To justify the use of COMBO, in [Subsection A.1](https://arxiv.org/html/2310.06623v2#A1.SS1 "A.1 Classical Methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") we compare the capabilities of different classical knapsack solvers.
The code and data are publicly available333



Source code and data: [https://github.com/SoerenWilkening/QTG\_0-1Knapsack](https://github.com/SoerenWilkening/QTG_0-1Knapsack "").

COMBO is a single-core algorithm, making comparing elapsed cycles and memory usage a fair unit of measurement.
To measure the elapsed cycles of COMBO and CTG, we read the time stamp counter (TSC) values, that are present on x86 processors.
The required memory (resident set size) was measured with GNU time utility.
In contrast to quantum systems, classical computers use a certain amount memory for storing the code of the program.
To calculate the data memory usage, all solvers were executed on tiny instances (1010 items).
This makes sure that all relevant code memory pages were loaded by the solvers at some point and therefore detected by the GNU time utility.
The data memory usage is now calculated by subtracting the minimum memory usage of that solver in the preliminary experiment.

Because QTG-based search is a non-deterministic algorithm, the optimal solution is only sampled with a certain success probability recorded for every instance.
For the easier instances with g=2g=2, we employ both the exact simulation for QTG, as well as a hybrid version (QTG estimate), for which we execute the CTG with the square of the prescribed number of Grover iterations to determine the success probability.
For harder instances, we omit the exact simulation due to long processing times, but keep the QTG estimate (see [subsubsection A.2.1](https://arxiv.org/html/2310.06623v2#A1.SS2.SSS1 "A.2.1 Biased Hadamard Gates ‣ A.2 Branching strategy ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")), which shows the same scaling behaviour as the exact calculator but with a positive offset, making it a heuristic upper bound. All this provides realistic evaluations for QTG, based on exact simulations (for easier instances up to 600 items) and calibrated pessimistic estimates (for harder instances up to 600 items).

This differs from the runtime estimates for QBnB, which are generous lower bounds for any practical runtime, based on several benevolent assumptions; a realistic runtime of QBnB can be expected to be considerably higher. These assumptions for QBnB (which are _not_ granted to QTG) include a success probability of 11 for all quantum subroutines; see [subsubsection A.6.2](https://arxiv.org/html/2310.06623v2#A1.SS6.SSS2 "A.6.2 Quantum branch-and-bound ‣ A.6 Benchmarking of competitive quantum methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") for details. As the size of the tree grows exponentially, we limit the maximum number of tree nodes to 101010^{10} giving us an even more optimistic lower bound on the actual number of cycles.

We carry out 100100 applications of the QTG-based QMaxSearch with a bias b=n/4b=n/4 and M=700+n2/16M=700+n^{2}/16 Grover iterations.
As shown in [Figure 4](https://arxiv.org/html/2310.06623v2#S5.F4 "Figure 4 ‣ V Results ‣ A quantum algorithm for solving 0-1 Knapsack problems"), the success probabilities of finding the optimal solution for instances with difficulty 2≤g≤62\\leq g\\leq 6 are above 80%80\\%, while for hard instances with 7≤g≤107\\leq g\\leq 10 are above 40%40\\%.
The quantum cycles and number of qubits required to run QTG were calculated as described in [Section IV](https://arxiv.org/html/2310.06623v2#S4 "IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems") and averaged over all runs, see [Figure 2](https://arxiv.org/html/2310.06623v2#S4.F2 "Figure 2 ‣ IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems") and [Figure 3](https://arxiv.org/html/2310.06623v2#S4.F3 "Figure 3 ‣ IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems").
We numerically observe that, for hard instances (g≥7g\\geq 7), COMBO’s cycle demand overtakes the quantum method’s elapsed cycles already at instances with 100100 variables and indicates a steeper slope overall.

Additionally, we observe that the QTG-based method requires far less memory than COMBO (assuming the comparability of bits and qubits) and any other tested method.
While the number of involved qubits stays constant for instances of the same size, COMBO’s memory requirements increase exponentially for harder instances.

Figure 4: Success probabilities of the QTG-based search for instances of difficulties ranging from g=2g=2 to g=10g=10.

## VI Discussion and Conclusions

In this paper, we have proposed and investigated the Quantum Tree Generator (QTG), a quantum method for solving instances of the 0-1 knapsack problem.
The QTG-based search emerges as a highly problem-specific version of quantum amplitude amplification with improved incorporation of the underlying classical structure at hand.
Due to our novel runtime calculator, we were able to collect numerical data, rather than mere extrapolation, for benchmark instances of various difficulty with up to 600 variables.

On the evaluated benchmarks, the quantum method admitted favourable runtimes for hard instances with at least 100 variables while requiring a significantly smaller amount of memory.
Both results together – runtime and (enormous) memory savings – hint at a possible _practical_ quantum advantage for solving 0-1-KP\\KP instances.

It is essential to acknowledge that there exist several other potential ways for improvement.
These areas of potential enhancement encompass the utilisation of upper bound heuristics within the QTG to reduce branching, or the utilisation of a preprocessing branch-and-bound procedure, such that the QTG-based search is executed only on the remaining subsequent problem, or to use a different bias function based on the weight of the items.

## Acknowledgments

This work was supported by the DFG through SFB 1227 (DQ-mat), Quantum Frontiers, the Quantum Valley Lower Saxony, the BMBF projects ATIQ and QuBRA, and the BMWK project ProvideQ.
Helpful correspondence and discussions with Arne-Christian Voigt, Mark Bennemann, and Timo Ziegler are gratefully acknowledged.

## Author Contributions

This project was conceived of, and initiated in, discussions of S.W. and T.J.O. The quantum implementation along with the resource estimation procedures were developed by S.W, L.B and A.I.L. The classical expertise was provided by S.F. and M.P. All authors contributed to writing the paper.

## References

- \[1\]J. Gambetta and M. Steffen, [Charting the course to 100,000 qubits](https://research.ibm.com/blog/100k-qubit-supercomputer "") (2023).

- \[2\]H. E. Brandt, [Prog. Quant. Electron 22, 257 (1999)](https://doi.org/https://doi.org/10.1016/S0079-6727(99)00003-8 "").

- \[3\]M. Schlosshauer, [Phys. Rep. 831, 1 (2019)](https://doi.org/10.1016/j.physrep.2019.10.001 "").

- \[4\]J. Preskill, [Quantum 2, 79 (2018)](https://doi.org/10.22331/q-2018-08-06-79 "").

- \[5\]D. A. Lidar and T. A. Brun, [_Quantum error correction_](https://www.cambridge.org/core/books/quantum-error-correction/B51E8333050A0F9A67363254DC1EA15A "") (Cambridge university press, 2013).

- \[6\]M. Kjaergaard, M. E. Schwartz, J. Braumüller, P. Krantz, J. I.-J. Wang,
S. Gustavsson, and W. D. Oliver, [Annu. Rev. Condens. Matter Phys. 11, 369 (2020)](https://doi.org/10.1146/annurev-conmatphys-031119-050605 "").

- \[7\]I. Siddiqi, [Nat. Rev. Mater. 6, 875 (2021)](https://www.nature.com/articles/s41578-021-00370-4 "").

- \[8\]R. Blatt and C. F. Roos, [Nat. Phys. 8, 277 (2012)](https://doi.org/10.1038/nphys2252 "").

- \[9\]J. I. Cirac and P. Zoller, [Phys. Rev. Lett. 74, 4091 (1995)](https://doi.org/10.1103/PhysRevLett.74.4091 "").

- \[10\]H. Häffner, C. F. Roos, and R. Blatt, [Phys. Rep. 469, 155 (2008)](https://doi.org/10.1016/j.physrep.2008.09.003 "").

- \[11\]D. Leibfried, R. Blatt,
C. Monroe, and D. Wineland, [Rev. Mod. Phys. 75, 281 (2003)](https://doi.org/10.1103/RevModPhys.75.281 "").

- \[12\]L. S. Madsen, F. Laudenbach,
M. F. Askarani, F. Rortais, T. Vincent, J. F. Bulmer, F. M. Miatto, L. Neuhaus, L. G. Helt,
M. J. Collins, _et al._, [Nature 606, 75 (2022)](https://doi.org/0.1038/s41586-022-04725-x "").

- \[13\]S. Slussarenko and G. J. Pryde, Appl. Phys. Rev. 6, [10.1063/1.5115814](https://doi.org/10.1063/1.5115814 "") (2019).

- \[14\]B.-H. Wu, R. N. Alexander,
S. Liu, and Z. Zhang, [Phys. Rev. Res. 2, 023138 (2020)](https://journals.aps.org/prresearch/pdf/10.1103/PhysRevResearch.2.023138 "").

- \[15\]K. Rudinger, G. J. Ribeill, L. C. Govia,
M. Ware, E. Nielsen, K. Young, T. A. Ohki, R. Blume-Kohout, and T. Proctor, [Phys. Rev. Appl. 17, 014014 (2022)](https://doi.org/10.1103/PhysRevApplied.17.014014 "").

- \[16\]M. Reagor, C. B. Osborn,
N. Tezak, A. Staley, G. Prawiroatmodjo, M. Scheer, N. Alidoust, E. A. Sete, N. Didier, M. P. da Silva, _et al._, [Sci. Adv. 4, eaao3603 (2018)](https://www.science.org/doi/pdf/10.1126/sciadv.aao3603 "").

- \[17\]A. Ajagekar, T. Humble, and F. You, [Comput. Chem. Eng. 132, 106630 (2020)](https://doi.org/https://doi.org/10.1016/j.compchemeng.2019.106630 "").

- \[18\]F. Arute, K. Arya,
R. Babbush, D. Bacon, J. C. Bardin, R. Barends, R. Biswas, S. Boixo, F. G. S. L. Brandao, D. A. Buell, _et al._, [Nature 574, 505 (2019)](https://doi.org/10.1038/s41586-019-1666-5 "").

- \[19\]W. van
Dam, K. Eldefrawy,
N. Genise, and N. Parham, in [_2021 IEEE International Conference on Quantum Computing and Engineering_\\
_(QCE)_](https://doi.org/10.1109/QCE52317.2021.00033 "") (IEEE, 2021) pp. 160–170.

- \[20\]IBM, [IBM ILOG CPLEX Optimization Studio](https://www.ibm.com/products/ilog-cplex-optimization-studio "") (2022).

- \[21\]Gurobi Optimization,
LLC, [Gurobi Optimizer\\
Reference Manual](https://www.gurobi.com/ "") (2023).

- \[22\]Google OR-Tools, [Google OR-Tools Documentation](https://developers.google.com/optimization/cp "") (2024).

- \[23\]L. K. Grover, A fast quantum mechanical
algorithm for database search (1996), [quant-ph/9605043](https://arxiv.org/abs/quant-ph/9605043 "") .

- \[24\]G. Brassard, P. Høyer,
M. Mosca, and A. Tapp, [Commun. Contemp. Math. , 53 (2002)](https://doi.org/10.1090/conm/305/05215 "").

- \[25\]N. J. Cerf, L. K. Grover, and C. P. Williams, [Phys. Rev. A 61, 032303 (2000)](https://doi.org/10.1103/PhysRevA.61.032303 "").

- \[26\]A. Montanaro, [Theory Comput. 14, 1 (2018)](https://doi.org/10.4086/toc.2018.v014a015 "").

- \[27\]A. Montanaro, [Phys. Rev. Res. 2, 013056 (2020)](https://doi.org/10.1103/PhysRevResearch.2.013056 "").

- \[28\]G. B. Dantzig, in _Proceedings of_
_the Symposium on Modern Calculating Machinery and Numerical Methods, UCLA,_
_July_ (1948) pp. 29–31.

- \[29\]L. G. Khachiyan, in _Doklady_
_Akademii Nauk_, Vol. 244 (Russian Academy of Sciences, 1979) pp. 1093–1096.

- \[30\]Y. Ye, Wiley-interscience series in discrete mathematics
and optimization, in [_Interior Point Algorithms_](https://doi.org/https://doi.org/10.1002/9781118032701.scard "") (John Wiley and Sons, Ltd, 1997) pp. 419–419.

- \[31\]D. Lykov, R. Shaydulin,
Y. Sun, Y. Alexeev, and M. Pistoia, in [_Proceedings of the SC ’23 Workshops of The International Conference on High_\\
_Performance Computing, Network, Storage, and Analysis_](https://doi.org/10.1145/3624062.3624216 "") (Association for Computing Machinery, New
York, NY, USA, 2023) p. 1443–1451.

- \[32\]C. Cade, M. Folkertsma,
I. Niesen, and J. Weggemans, [Quantum 7, 1133 (2023)](https://doi.org/10.22331/q-2023-10-10-1133 "").

- \[33\]S. Ammann, M. Hess,
D. Ramacciotti, S. P. Fekete, P. L. A. Goedicke, D. Gross, A. Lefterovici, T. J. Osborne, M. Perk, A. Rotundo,
S. E. Skelton, S. Stiller, and T. de Wolff, Realistic Runtime Analysis for Quantum Simplex Computation
(2023), [arXiv:2311.09995 \[quant-ph\]](https://arxiv.org/abs/2311.09995 "") .

- \[34\]G. Nannicini, [Oper. Res. 72, 763 (2024)](https://doi.org/10.1287/opre.2022.2341 "").

- \[35\]H. Kellerer, U. Pferschy, and D. Pisinger, [_Knapsack Problems_](https://doi.org/10.1007/978-3-540-24777-7 "") (Springer, 2004).

- \[36\]S. Martello, D. Pisinger, and P. Toth, [Manage. Sci. 45, 414 (1999)](https://doi.org/10.1287/mnsc.45.3.414 "").

- \[37\]D. Pisinger, [Eur. J. Oper. Res. 87, 175 (1995)](https://doi.org/https://doi.org/10.1016/0377-2217(94)00013-3 "").

- \[38\]S. Chakrabarti, P. Minssen, R. Yalovetzky, and M. Pistoia, Universal Quantum Speedup for
Branch-and-Bound, Branch-and-Cut, and Tree-Search Algorithms (2022), [2210.03210\\
\[quant-ph\]](https://arxiv.org/abs/2210.03210 "") .

- \[39\]S. Martiel and M. Remaud, Practical implementation of a quantum
backtracking algorithm, in [_SOFSEM 2020: Theory and Practice of Computer_\\
_Science_](https://link.springer.com/chapter/10.1007/978-3-030-38919-2_49#citeas "") (Springer International Publishing, Cham, 2020) pp. 597–606.

- \[40\]T. G. Draper, Addition on a Quantum
Computer (2000), [arXiv:quant-ph/0008033 \[quant-ph\]](https://arxiv.org/abs/quant-ph/0008033 "")
.

- \[41\]C. Durr and P. Høyer, A Quantum Algorithm for
Finding the Minimum (1996), [quant-ph/9607014](https://arxiv.org/abs/quant-ph/9607014 "") .

- \[42\]J. Jooken, P. De Causmaecker, P. Leyman, J. Goedgebeur, and T. Wauters, _Monte Carlo Tree Search and Instance Space Analysis for_
_the 0-1 Knapsack Problem_, Phd thesis, Katholieke Universiteit Leuven (2023).

- \[43\]J. Jooken, P. Leyman, and P. De Causmaecker, [Eur. J. Oper. Res. 301, 841 (2022a)](https://doi.org/10.1016/j.ejor.2021.12.009 "").

- \[44\]J. Jooken, P. Leyman, and P. De Causmaecker, [Knapsack problem instances](https://github.com/JorikJooken/knapsackProblemInstances "") (2022b).

- \[45\]M. Boyer, G. Brassard,
P. Høyer, and A. Tapp, [Fortschr. Phys. 46, 493 (1998)](https://doi.org/10.1002/(sici)1521-3978(199806)46:4/5%3C493::aid-prop493%3E3.0.co;2-p "").

- \[46\]M. Smelyanskiy, N. P. D. Sawaya, and A. Aspuru-Guzik, qHiPSTER: The Quantum
High Performance Software Testing Environment (2016), [1601.07195 \[quant-ph\]](https://arxiv.org/abs/1601.07195 "")
.

- \[47\]M. Matsumoto and T. Nishimura, [ACM Trans. Model. Comput. Simul. 8, 3–30 (1998)](https://doi.org/10.1145/272991.272995 "").

- \[48\]D. Coppersmith, An approximate Fourier
transform useful in quantum factoring (2002), [arXiv:quant-ph/0201067 \[quant-ph\]](https://arxiv.org/abs/quant-ph/0201067 "")
.

- \[49\]M. A. Nielsen and I. L. Chuang, [_Quantum Computation and Quantum Information: 10th_\\
_Anniversary Edition_](https://www.cambridge.org/highereducation/books/quantum-computation-and-quantum-information/01E10196D0A682A6AEFFEA52D53BE9AE#overview ""), 10th ed. (Cambridge University Press, USA, 2011).

- \[50\]M. D. Ercegovac and T. Lang, [_Digital Arithmetic_](https://doi.org/10.1016/B978-1-55860-798-9.X5000-3 "") (Elsevier, 2004).

- \[51\]D. Pisinger, [Comput. Oper. Res. 32, 2271 (2005)](https://doi.org/https://doi.org/10.1016/j.cor.2004.03.002 "").

- \[52\]S. Apers, A. Gilyén, and S. Jeffery, A Unified Framework of Quantum Walk
Search (2019), [arXiv:1912.04233 \[quant-ph\]](https://arxiv.org/abs/1912.04233 "") .

- \[53\]A. Ambainis and M. Kokainis, in [_Proceedings of the 49th Annual ACM SIGACT Symposium on_\\
_Theory of Computing_](https://doi.org/10.1145/3055399.3055444 ""), STOC ’17 (ACM, 2017).


## Appendix A Supplementary Information

### A.1 Classical Methods

Figure 5: Comparison of several classical solvers on the _jooken-large_ instance set.
We observe that despite COMBO being a single-threaded algorithm, it still outperforms the exact solvers Gurobi and CP-SAT in terms of runtime. Note that GUROBI and CP-SAT were not able to prove optimality for all instances within 300​s300\\second despite finding an optimal solution for all of them.

To compare the QTG-based search with classical methods, we evaluated the capabilities of classical knapsack solvers on a wide range of benchmark instances.
We use three exact solvers: GUROBI (based on IP), CP-SAT, and COMBO.
EXPKNAP was also tested, but did not produce results within the given time frame and was therefore excluded from this evaluation.
Moreover, we also evaluated the performance of Greedy.
The instance set consisted of 336336 instances with 200−2800200-2800 items that were generated with the algorithm proposed by [Jooken et al. \[43\]](https://arxiv.org/html/2310.06623v2#bib.bib43 "").
The experiment was carried out with a time limit of 300​s300\\second.

[Figure 5](https://arxiv.org/html/2310.06623v2#A1.F5 "Figure 5 ‣ A.1 Classical Methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") presents a comparison between all classical algorithms.
Note that although the simplicity of the Greedy algorithm allows for a short runtime, it produces suboptimal solutions in most cases.
On the other hand, IP and CP-SAT were able to find optimal solutions (within a gap of 10−510^{-5}) for all instances.
In some cases, however, both solvers were unable to prove optimality for found solutions resulting in exceeding the given time limit.
It is clear that COMBO being provably optimal and several orders faster than its exact counterparts, while only utilising a single core instead of the available 88 cores serves as the basis for our comparison to QTG.

### A.2 Branching strategy

#### A.2.1 Biased Hadamard Gates

First we consider the biased Hadamard gates ( [3](https://arxiv.org/html/2310.06623v2#S4.E3 "In IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems")) and note that, for b=0b=0, both variants yield the usual (unbiased) Hadamard gate H.
This would correspond to including or excluding the items with equal probability.
Accordingly, we numerically observed that the number of elapsed quantum cycles for obtaining a reasonable success probability would generally not be competitive when using the usual Hadamard gates.

In comparison, allowing for biased Hadamard gates and fine-tuning the bias bb can lead to an enormous speed-up during the phase of amplitude amplification:
Given an intermediate solution 𝒙′\\bm{x}^{\\prime}, whose profit also constitutes the current threshold for the QMaxSearch, we can actively favour feasible paths 𝒙\\bm{x} that have a certain Hamming distance Δ≔Δ⁡(𝒙′,𝒙)\\Delta\\coloneqq\\Delta(\\bm{x}^{\\prime},\\bm{x}) to 𝒙\\bm{x}.
Namely, applying the QTG and its biased Hadamard gates with arbitrary but fixed bias bb, we can give the following lower bound on the sampling probability of 𝒙\\bm{x}:

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|a𝒙\|2=(b+1b+2)n−Δ​(1b+2)Δ.\\displaystyle\\lvert a\_{\\bm{x}}\\rvert^{2}=\\left(\\frac{b+1}{b+2}\\right)^{n-\\Delta}\\left(\\frac{1}{b+2}\\right)^{\\Delta}. |  | (6) |

This bound is tight if all possible branchings occur when constructing the path 𝒙\\bm{x}.
For each bit in which 𝒙\\bm{x} and 𝒙′\\bm{x}^{\\prime} differ, the application of a biased Hadamard gate introduces the prefactor 1/(b+2)1/(b+2). For each of the remaining bits, it establishes the prefactor (b+1)/(b+2)(b+1)/(b+2).

Now, we can determine bb in order to maximise the sampling probability of 𝒙\\bm{x} within the superposition created by the QTG.
Differentiating ( [6](https://arxiv.org/html/2310.06623v2#A1.E6 "In A.2.1 Biased Hadamard Gates ‣ A.2 Branching strategy ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")) with respect to bb and checking for zeros yield the optimal bias

|     |     |     |
| --- | --- | --- |
|  | bopt=nΔ−2≈nΔ.\\displaystyle b\_{\\opt}=\\frac{n}{\\Delta}-2\\approx\\frac{n}{\\Delta}. |  |

Fine-tuning the bias in order to sample paths with a certain hamming distance more frequently helps searching the neighbourhood of good intermediate solutions for even better solutions.
We observe that for many Knapsack instances the optimal solution and the Greedy result do have a lot of common bit values, corresponding to items whose efficiency is just too good to not be included in any optimal assignment.
Because we employ Greedy for obtaining an initial solution in our QMaxSearch routine, the biased Hadamard approach typically results in highly improved performance.

The time required by QSearch algorithm to find a state with hamming distance Δ\\Delta to a known solution is 𝒪⁡(1/ax)\\mathcal{O}(1/a\_{x}), where

|     |     |     |     |
| --- | --- | --- | --- |
|  | 1/ax=(bopt+2bopt+1)(n−Δ)/2​(bopt+2)Δ/2=(nn−Δ)(n−Δ)/2​(nΔ)Δ/2≈(nΔ)Δ/2.\\displaystyle\\begin{aligned} 1/a\_{x}&=\\left(\\frac{b\_{\\opt}+2}{b\_{\\opt}+1}\\right)^{(n-\\Delta)/2}\\left(b\_{\\opt}+2\\right)^{\\Delta/2}\\\<br>&=\\left(\\frac{n}{n-\\Delta}\\right)^{(n-\\Delta)/2}\\left(\\frac{n}{\\Delta}\\right)^{\\Delta/2}\\approx\\left(\\frac{n}{\\Delta}\\right)^{\\Delta/2}.\\end{aligned} |  | (7) |

More explicitly, we get a runtime 𝒪⁡((nΔ)Δ/2)\\mathcal{O}\\left(\\left(\\frac{n}{\\Delta}\\right)^{\\Delta/2}\\right).
As the neighbourhood of distance Δ\\Delta to a known solution contains (nΔ)≈nΔ\\binom{n}{\\Delta}\\approx n^{\\Delta} assignments, this runtime can be seen as a quadratic improvement over local search algorithms.

#### A.2.2 Construction of the layer unitaries

As described in [Section IV](https://arxiv.org/html/2310.06623v2#S4 "IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems"), the QTG is composed of the layer unitaries UmU\_{m}: 𝒢=∏m=1nUm\\mathcal{G}=\\prod\_{m=1}^{n}U\_{m}.
That is, each UmU\_{m} manages the inclusion/exclusion of an item mm.
The unitaries UmU\_{m} are themselves comprised of three components:

- 1.


Create a biased superposition of including or excluding item mm if and only if including the item does not exceeds the capacity cc, otherwise do nothing.
We achieve this step by applying a multi-controlled biased Hadamard gate to the mm-th qubit.
The Hadamard gate itself acts on the mm-th qubit in the register ℋ1\\mathcal{H}\_{1}.
The control runs over the qubits of the second register ℋ2\\mathcal{H}\_{2} and checks whether the remaining capacities cover the weight wmw\_{m} of including item mm.
Accordingly, we denote the control with C≥wm2C\_{\\geq w\_{m}}^{2}, because it asks whether the second register’s state, interpreted as the binary representation of an integer, is greater or equal to the integer wmw\_{m}.
It then highly depends on the actual value of wmw\_{m} which qubits in ℋ2\\mathcal{H}\_{2} have to be involved into the control (see [subsubsection A.5.5](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS5 "A.5.5 Comparison ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")).
In summary, this subgate is given by Um1≔C≥wm2​(Hbxm)U^{1}\_{m}\\coloneqq C^{2}\_{\\geq w\_{m}}(\\text{H}^{x\_{m}}\_{b}).

- 2.


Update the remaining capacity.
For this, we have to perform an integer subtraction by wmw\_{m} in the second register ℋ2\\mathcal{H}\_{2} – denoted by SUBwm\\text{SUB}\_{w\_{m}} – which is, however, only executed if the main register ℋ1\\mathcal{H}\_{1} represents a path for which the mm-th item is included.
That is, the integer subtraction by wmw\_{m} is controlled by the mm-th qubit in the main register.
The entire update step therefore reads Um2≔Cm1​SUBwmU^{2}\_{m}\\coloneqq C^{1}\_{m}\\text{SUB}\_{w\_{m}}.

- 3.


Update the total profit.
Here, we perform an integer addition by pmp\_{m} in the third register ℋ3\\mathcal{H}\_{3} – denoted by ADDpm\\text{ADD}\_{p\_{m}} – which is, analogously to step 2, controlled by the mm-th qubit in the main register.
This last update step thus reads Um3≔Cm1​ADDpmU^{3}\_{m}\\coloneqq C^{1}\_{m}\\text{ADD}\_{p\_{m}}.


To give an explicit example:
Let 𝒙\\bm{x} be a feasible path whose mm-th bit is set to zero and let 𝒙~\\tilde{\\bm{x}} be the same bit string, but with its mm-th bit set to one.
Further assume that the mm-th bit of the intermediate solution 𝒙′\\bm{x}^{\\prime} has the value one.
The action of UmU\_{m} on a the feasible product state \|𝒙⟩1​\|c𝒙⟩2​\|P𝒙⟩3\\ket{\\bm{x}}^{1}\\ket{c\_{\\bm{x}}}^{2}\\ket{P\_{\\bm{x}}}^{3} then reads

|     |     |     |     |
| --- | --- | --- | --- |
|  | Um​\|𝒙⟩1​\|c𝒙⟩2​\|P𝒙⟩3={\|𝒙⟩1​\|c𝒙⟩2​\|P𝒙⟩3,if ​c𝒙<wm1b+2​\|𝒙⟩1​\|c𝒙⟩2​\|P𝒙⟩3+b+1b+2​\|𝒙~⟩1​\|c𝒙−wm⟩2​\|P𝒙+pm⟩3,else.U\_{m}\\ket{\\bm{x}}^{1}\\ket{c\_{\\bm{x}}}^{2}\\ket{P\_{\\bm{x}}}^{3}=\\begin{cases}\\ket{\\bm{x}}^{1}\\ket{c\_{\\bm{x}}}^{2}\\ket{P\_{\\bm{x}}}^{3},&\\text{if }c\_{\\bm{x}}<w\_{m}\\\<br>\\\<br>\\sqrt{\\frac{1}{b+2}}\\ket{\\bm{x}}^{1}\\ket{c\_{\\bm{x}}}^{2}\\ket{P\_{\\bm{x}}}^{3}+\\sqrt{\\frac{b+1}{b+2}}\\ket{\\tilde{\\bm{x}}}^{1}\\ket{c\_{\\bm{x}}-w\_{m}}^{2}\\ket{P\_{\\bm{x}}+p\_{m}}^{3},&\\text{else.}\\end{cases} |  | (8) |

### A.3 Quantum maximum finding

Here, we recap the known quantum algorithms Amplitude Amplification/QSearch and QMaxSearch and detail our adjustments for application to the 0-1-KP.

QSearch is a direct generalisation of Grover’s famous algorithm \[ [23](https://arxiv.org/html/2310.06623v2#bib.bib23 "")\].
More precisely, Grover’s algorithm was initially proposed for finding a unique marked state within a uniform superposition.
It was then generalised to instances with multiple marked states in the form of the _quantum exponential searching algorithm_\[ [45](https://arxiv.org/html/2310.06623v2#bib.bib45 "")\].
The two central building blocks of these algorithms are the _phase oracle_

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝒮f​\|𝒙⟩≔(−1)f⁡(𝒙)​\|𝒙⟩,\\displaystyle\\mathcal{S}\_{f}\\ket{\\bm{x}}\\coloneqq(-1)^{f(\\bm{x})}\\ket{\\bm{x}}, |  | (9) |

which flips the phase of all states corresponding to bit strings 𝒙\\bm{x} that fulfil the Boolean trait f⁡(𝒙)=1f(\\bm{x})=1, and the _diffusion operator_

|     |     |     |     |
| --- | --- | --- | --- |
|  | D=H⊗n​𝒮0​H⊗n.\\displaystyle D=\\text{H}^{\\otimes n}\\mathcal{S}\_{0}\\text{H}^{\\otimes n}. |  | (10) |

In the more general QSearch routine, H⊗n\\text{H}^{\\otimes n} – which creates a uniform superposition of all computational basis states – is replaced by any other superposition-creating unitary 𝒜\\mathcal{A}, in our case by the QTG 𝒢\\mathcal{G}.
Fixing the Boolean function ff and the state preparation unitary 𝒜\\mathcal{A}, the Amplitude Amplification operator is given by

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝒬≔𝒜​𝒮0​𝒜†​𝒮f.\\displaystyle\\mathcal{Q}\\coloneqq\\mathcal{A}\\mathcal{S}\_{0}\\mathcal{A}^{\\dagger}\\mathcal{S}\_{f}. |  | (11) |

In the original proposal \[ [24](https://arxiv.org/html/2310.06623v2#bib.bib24 "")\],
the QSearch algorithm runs forever if there is no state 𝒙\\bm{x} fulfilling f⁡(𝒙)f(\\bm{x}).
In our case, however, this situation naturally occurs at the end of an entire QMaxSearch routine (see remainder of this section) which is why we additionally introduce a cutoff to prevent an endless loop.
With this extension, our version of QSearch reads

Algorithm 1QSearch (𝒢\\mathcal{G}, ff, MM)

Set l=0l=0, mtot=0m\_{\\total}=0, and let dd be any constant such that 1<d<21<d<2;

1
Increase ll by 11 and set m=⌈dl⌉m=\\lceil d^{l}\\rceil;

2
Apply 𝒢\\mathcal{G} to the initial state \|𝟎⟩1​\|c⟩2​\|0⟩3\\ket{\\bm{0}}^{1}\\ket{c}^{2}\\ket{0}^{3};

3
Choose j∈\[1,m\]j\\in\[1,m\] uniformly at random and increase mtotm\_{\\total} by 2​j+12j+1;

4
Apply 𝒬j\\mathcal{Q}^{j} to the superposition \|s⟩123=𝒢​\|𝟎⟩1​\|c⟩2​\|0⟩3\\ket{s}^{123}=\\mathcal{G}\\ket{\\bm{0}}^{1}\\ket{c}^{2}\\ket{0}^{3};

5
Measure the register A and C, and get the outcome \|𝒙⟩1​\|P𝒙⟩3\\ket{\\bm{x}}^{1}\\ket{P\_{\\bm{x}}}^{3};

6iff⁡(P𝒙)=1f(P\_{\\bm{x}})=1 or mtot≥Mm\_{\\total}\\geq Mthen

7
return 𝒙\\bm{x}, P𝒙P\_{\\bm{x}};

8else

9
go to step 2;

10
end if

Because we are interested in maximising the total profit among all feasible paths, we have to choose the Boolean function ff accordingly.
The apt method in question is provided by Quantum Maximum Finding.
While initially proposed as an extension to Grover’s algorithm, its principle is directly transferable to QSearch.

The key idea is to introduce the comparison “P𝒙>TP\_{\\bm{x}}>T” as Boolean function which marks all paths 𝒙\\bm{x} whose total profit P𝒙P\_{\\bm{x}} exceeds a given threshold TT.
Starting with an initial threshold T0T\_{0}, QSearch(𝒢,Px>T0,M)(\\mathcal{G},P\_{\\bm{x}}>T\_{0},M) yields an intermediate solution (𝒙1,P𝒙1)(\\bm{x}\_{1},P\_{\\bm{x}\_{1}}).
If P𝒙1>T0P\_{\\bm{x}\_{1}}>T\_{0}, we can call QSearch again with the updated threshold T1≔P𝒙1T\_{1}\\coloneqq P\_{\\bm{x}\_{1}} and so on.
However, if we obtain an output (𝒙i,P𝒙i)(\\bm{x}\_{i},P\_{\\bm{x}\_{i}}) with P𝒙i≤Ti−1P\_{\\bm{x}\_{i}}\\leq T\_{i-1} throughout this routine, we can conclude – within a certain probability – that no valid path exists with a higher total profit than Ti−1T\_{i-1};
hence we declare the previous intermediate solution (𝒙i−1,Ti−1)(\\bm{x}\_{i-1},T\_{i-1}) the optimal solution.
Because this case eventually occurs for every instance, we have introduced the additional termination condition in QSearch.
Finally, for the initial threshold we employ the very efficient Integer Greedy method.

Algorithm 2QMaxSearch(𝒢\\mathcal{G}, MM, 𝒑\\bm{p}, 𝒘\\bm{w}, cc)

Calculate initial threshold TT using Greedy:
𝒙out\\bm{x}\_{\\out}, T=intGr​(𝒑,𝒘,c)T=\\textbf{intGr}(\\bm{p},\\bm{w},c) ;

1while True do

2𝒙\\bm{x}, P𝒙P\_{\\bm{x}} = QSearch(𝒢\\mathcal{G}, P𝒙>TP\_{\\bm{x}}>T, MM);

3ifP𝒙>TP\_{\\bm{x}}>Tthen

4
set T=P𝒙T=P\_{\\bm{x}} and 𝒙out=𝒙\\bm{x}\_{\\out}=\\bm{x};

5else

6
return 𝒙out\\bm{x}\_{\\out}, TT;

7
end if

8
end while

### A.4 Runtime calculator

The instance sizes considered in [Figure 2](https://arxiv.org/html/2310.06623v2#S4.F2 "Figure 2 ‣ IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems") and [Figure 3](https://arxiv.org/html/2310.06623v2#S4.F3 "Figure 3 ‣ IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems") are way too large for any conventional simulator which is based on evaluating the action of general quantum gates on general quantum states.
Even with the most sophisticated simulation technique and with the aid of the largest available super computer, these approaches could only tackle up to 49 qubits\[ [46](https://arxiv.org/html/2310.06623v2#bib.bib46 "")\].
Instead, we developed a completely different runtime calculator tailored explicitly to the application of the QTG and QMaxSearch.
The calculator consists of two main parts:

1. 1.


calculate the QTG’s action only on computational basis states whose objective value surpasses the current threshold imposed by QMaxSearch.

2. 2.


calculate the effect of Amplitude Amplification operator via analytical formulas.


#### A.4.1 QTG as a state sieve

We classically mimic the QTG by exploring the classical binary decision tree for a given knapsack instance using breadth-first search (BFS) and, in doing so, keep track of the remaining capacities, the total profit, and the sampling probabilities of the computational basis states after each application of one layer operator UmU\_{m}.
The sampling probabilities are propagated as follows:
Assume a node in the mm-th layer carries a remaining capacity of c~\\tilde{c}, a total profit of pp, and a sampling probability of qq.
If wm+1>c~w\_{m+1}>\\tilde{c}, no branching occurs and the only child node inherits its data from its parent node.
If instead wm+1≤c~w\_{m+1}\\leq\\tilde{c}, a branching produces two child nodes corresponding to either excluding (left) or including (right) the (m+1)(m+1)-th item.
The child nodes’ metadata are:

|     |     |     |     |
| --- | --- | --- | --- |
|  | (c~left,c~right)\\displaystyle(\\tilde{c}\_{\\text{left}},\\tilde{c}\_{\\text{right}}) | =(c~,c~−wm+1)\\displaystyle=(\\tilde{c},\\tilde{c}-w\_{m+1}) |  |
|  | (pleft,pright)\\displaystyle(p\_{\\text{left}},p\_{\\text{right}}) | =(p,p+pm+1)\\displaystyle=(p,p+p\_{m+1}) |  |
|  | (qleft,qright)\\displaystyle(q\_{\\text{left}},q\_{\\text{right}}) | ={(q⁡(b+1)b+2,qb+2),if ​xm+1=0(qb+2,q⁡(b+1)b+2),else.\\displaystyle=\\begin{cases}\\big(\\frac{q(b+1)}{b+2},\\frac{q}{b+2}\\big),&\\text{if }x\_{m+1}=0\\\<br>\\big(\\frac{q}{b+2},\\frac{q(b+1)}{b+2}\\big),&\\text{else.}\\end{cases} |  |

The update rule for the child nodes’ sampling probability directly results from the definition of the biased Hadamard gate ( [3](https://arxiv.org/html/2310.06623v2#S4.E3 "In IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems")).

During the BFS, we prune infeasible subtrees as the QTG would do anyway on a real quantum device, thereby massively reducing the final number of states.
Furthermore, we also discard subtrees which do not admit any path with an objective value surpassing the current threshold.
For this, we execute COMBO on the Knapsack subinstance that remains when fixing the first mm decision variables x1,…,xmx\_{1},\\ldots,x\_{m} with the values corresponding to the current node in the decision tree.
This yields a tight upper bound for the optimal profit achievable within the respective subtree.
This second pruning step, although computationally sumptuous, reduces the final number of states in such a drastic way that even for large instances up to 600 variables, only a few million – instead of 26002^{600} – states remain.

The result of this runtime calculator, given a threshold TT, is an array of paths (bit strings) together with their remaining capacity, total profit, and the theoretical sampling probability of the associated computational basis state.
All these paths are feasible and admit, by construction, a respective total profit above the threshold TT.
This final array of states now serves as the input for Amplitude Amplification.

We denote this set of paths by ℱT\\mathcal{F}^{T} and have therefore gained a representation of the superposition

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | \|s⟩123\\displaystyle\\ket{s}^{123} | =𝒢​\|𝟎⟩1​\|c⟩2​\|0⟩3\\displaystyle=\\mathcal{G}\\ket{\\bm{0}}^{1}\\ket{c}^{2}\\ket{0}^{3} |  | (12) |
|  |  | =∑𝒙∈ℱTa𝒙​\|𝒙⟩1​\|c𝒙⟩2​\|P𝒙⟩3+aR​\|R⟩\\displaystyle=\\sum\_{\\bm{x}\\raisebox{0.45206pt}{$\\scriptscriptstyle\\in$}\\mathcal{F}^{T}}a\_{\\bm{x}}\\ket{\\bm{x}}^{1}\\ket{c\_{\\bm{x}}}^{2}\\ket{P\_{\\bm{x}}}^{3}+a\_{R}\\ket{R} |  |
|  |  | =aT​\|ℱT⟩+aR​\|R⟩,\\displaystyle=a\_{T}\\ket{\\mathcal{F}^{T}}+a\_{R}\\ket{R}, |  |

where

|     |     |     |
| --- | --- | --- |
|  | \|aT\|2≔∑𝒙∈ℱT\|a𝒙\|2​ and ​\|aR\|2=1−\|aT\|2.\\displaystyle\\absolutevalue{a\_{T}}^{2}\\coloneqq\\sum\_{\\bm{x}\\raisebox{0.45206pt}{$\\scriptscriptstyle\\in$}\\mathcal{F}^{T}}\\absolutevalue{a\_{\\bm{x}}}^{2}\\text{ and }\\absolutevalue{a\_{R}}^{2}=1-\\absolutevalue{a\_{T}}^{2}. |  |

All other feasible paths, but with a total profit below or equal to TT, are thus collectively represented by the remainder state \|R⟩\\ket{R}.
In most cases, the remainder state’s amplitude is nonzero, such that the cumulative sampling probability qT≔\|aT\|2q\_{T}\\coloneqq\\absolutevalue{a\_{T}}^{2} of all the paths in ℱT\\mathcal{F}^{T} is not given by one.

Figure 6: a) The standard, non-parallelised QFT circuit.
b) The optimally parallelised QFT circuit.
For all i=3,…,ni=3,\\ldots,n, the gates in the \|qi−1⟩\\ket{q\_{i-1}}-level are shifted to the left until the leftmost gate, the Hadamard gate, is executed in parallel with the R3 gate in the \|qi⟩\\ket{q\_{i}}-level.
As the \|q2⟩\\ket{q\_{2}}-level does not admit an R3 gate, the Hadamard gate in the \|q1⟩\\ket{q\_{1}}-level is executed alone.
Therefore, for all i=2,…,ni=2,\\ldots,n, the \|qi−1⟩\\ket{q\_{i-1}}-level gate sequence with its i−1i-1 gates starts two layers after the \|qi⟩\\ket{q\_{i}}-level’s sequence which is comprised of ii gates.
Starting from the \|qn⟩\\ket{q\_{n}}-level, each additional level thus introduces only one additional layer to the circuit.

#### A.4.2 Amplitude Amplification

Beside the QTG, we also have to account for the action of the Amplitude Amplification operator 𝒬\\mathcal{Q} (step 5 in QSearch) and quantum measurements (step 6 in QSearch).
Choosing some power j∈ℕj\\in\\mathbb{N}, the action of 𝒬j\\mathcal{Q}^{j} on \|s⟩123\\ket{s}^{123} is explicitly given\[ [24](https://arxiv.org/html/2310.06623v2#bib.bib24 "")\] by

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝒬j​\|s⟩123=sin⁡((2​j+1)​arcsin⁡(qT))qT​\|ℱT⟩+cos⁡((2​j+1)​arcsin⁡(qT))1−qT​\|R⟩.\\displaystyle\\begin{split}\\mathcal{Q}^{j}\\ket{s}^{123}=\ &\\frac{\\sin\\left((2j+1)\\arcsin\\left(\\sqrt{q\_{T}}\\right)\\right)}{\\sqrt{q\_{T}}}\\ket{\\mathcal{F}^{T}}\\\<br>&+\\frac{\\cos\\left((2j+1)\\arcsin\\left(\\sqrt{q\_{T}}\\right)\\right)}{\\sqrt{1-q\_{T}}}\\ket{R}.\\end{split} |  | (13) |

The crucial aspect lies in the amplification of the amplitudes of the all the states contributing to the superposition \|ℱT⟩\\ket{\\mathcal{F}^{T}} – although being nonuniformly distributed – by the same factor.
Therefore, the entire the action of 𝒬j\\mathcal{Q}^{j} consists of merely multiplying each probability handed over by the QTG sieve with the common amplification factor

|     |     |     |     |
| --- | --- | --- | --- |
|  | sin2⁡((2​j+1)​arcsin⁡(qT))qT.\\displaystyle\\frac{\\sin^{2}\\left((2j+1)\\arcsin\\left(\\sqrt{q\_{T}}\\right)\\right)}{q\_{T}}. |  | (14) |

Finally, simulating a quantum measurement in this framework is straightforward:
Uniformly draw a random number from the interval \[0,1\]\[0,1\] (we use GNU Scientific Library’s implementation of the MT19937 algorithm \[ [47](https://arxiv.org/html/2310.06623v2#bib.bib47 "")\]).
Then iteratively sum up the sampling probabilities of all the paths in ℱT\\mathcal{F}^{T} until the cumulative probability surpasses the random number.
If this occurs before the loop ends, the last added path is considered to have been measured and is returned (lines 7 and 8 in QSearch).
Otherwise, that is if the random number exceeds qTq\_{T}, we consider the remainder state being sampled (lines 9 and 10 in QSearch).
Because in the latter case, we simply omit the result and restart the entire procedure with a new value for jj, no further information is necessary.
This completely justifies our approach of neglecting all the information about feasible states that admit a total profit below the given threshold.

### A.5 Resource estimation

This section contains detailed resource estimations for the subcircuits required for implementing the QTG-based search, specifically, the costs associated with implementing the exploration unitaries Um=Um3​Um2​Um1U\_{m}=U^{3}\_{m}U^{2}\_{m}U^{1}\_{m}, m=1,…,nm=1,\\ldots,n.
A crucial aspect of evaluating the efficiency of our quantum algorithm is to determine the total number of qubits 𝐐\\mathbf{Q}, gates 𝐆\\mathbf{G}, and cycles 𝐂\\mathbf{C} required for its implementation.
Here, a cycle refers to a collection of gates that can be executed in parallel.
In the context of resource estimation, we make the following assumptions:

1. (i)


Any nn-controlled single-qubit gate can be decomposed into 2​(n−1)2(n-1) Toffoli gates and a single-controlled single-qubit gate.
This decomposition utilises n−1n-1 ancilla qubits.

2. (ii)


All multi-controlled single-qubit gates have access to the same ancilla qubits arising from (i).
This corresponds to taking the maximum instead of the sum of all additionally introduced ancilla qubits.

3. (iii)


It is equally expensive to have a controlled gate on the logical state 0 or 1.


Figure 7:
Addition of the item profit pm=5p\_{m}=5 to the QFT-ed profit register, controlled on the mm-th qubit in the path register.
a) Draper method.
The binary representation of the integer 55 is encoded into the three-qubit ancilla state \|101⟩a\\ket{101}\_{\\ancilla} whose qubits control the application of the rotations Rk on the profit register.
b) Direct method.
The rotations for which the controlling ancilla qubit in Draper’s method would be in the \|1⟩a\\ket{1}\_{\\ancilla} state are directly implemented, the remaining ones simply omitted.
In comparison to Draper’s method, this saves several gates and the overall ancilla state preparation.

#### A.5.1 Qubit count

The total number of qubits is given by the sum of the main registers’ sizes ( [2](https://arxiv.org/html/2310.06623v2#S3.E2 "In III Preliminaries ‣ A quantum algorithm for solving 0-1 Knapsack problems")) and the number of ancilla qubits for decomposing multi-controlled gates according to (i).
Specifically, the size of the path register corresponds to the number of items involved in the Knapsack problem

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐐PATH=n.\\mathbf{Q}\_{\\text{PATH}}=n. |  | (15) |

The size of the capacity register is determined by the length of the capacity’s binary representation, i.e.,

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐐CAPACITY=\|cbin\|.\\mathbf{Q}\_{\\text{CAPACITY}}=\\absolutevalue{{c}\_{\\text{bin}}}. |  | (16) |

Analogously, given an upper bound PP for the optimal profit, the size of the profit register is given by the length of PP’s binary representation, that is

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐐PROFIT=\|Pbin\|.\\mathbf{Q}\_{\\text{PROFIT}}=\\absolutevalue{{P}\_{\\text{bin}}}. |  | (17) |

Additionally, the QTG contains the comparisons “c~≥wm\\tilde{c}\\geq w\_{m}” for all the item weights wmw\_{m}, m=1,…,nm=1,\\ldots,n, which constitute multi-controlled single-qubit gates (see [subsubsection A.5.5](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS5 "A.5.5 Comparison ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")).
Applying (i), the decomposition of those gates introduces up to \|cbin\|−1\\absolutevalue{{c}\_{\\text{bin}}}-1 ancilla qubits.
For simplicity, we assume that this upper bound is actually achieved by at least one of the comparisons.
Due to assumption (ii), this number of ancilla qubits then suffices to implement all the comparisons.
Analogously, the Amplitude Amplification operator 𝒬\\mathcal{Q} contains the phase oracles 𝒮0\\mathcal{S}\_{0} and 𝒮P𝒙>T\\mathcal{S}\_{P\_{\\bm{x}>T}} which we realise using nn-controlled and \|Pbin\|\\absolutevalue{{P}\_{\\text{bin}}}-controlled single-qubit gates, respectively (see [subsubsection A.5.5](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS5 "A.5.5 Comparison ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")).
Hence, following (i) and (ii), max⁡(n,\|cbin\|,\|Pbin\|)−1\\max(n,\\absolutevalue{{c}\_{\\text{bin}}},\\absolutevalue{{P}\_{\\text{bin}}})-1 additional ancilla qubits have to be introduced.
Utilising (ii) again, these ancilla qubits then even suffice to execute 𝒬\\mathcal{Q} several times with different thresholds TT.
Lastly, we use one additional qubit to store the potential phase flip applied by 𝒬\\mathcal{Q}.
In total, we obtain an amount of

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐐ANC\\displaystyle\\mathbf{Q}\_{\\text{ANC}} | =max⁡(n,\|cbin\|,\|Pbin\|)\\displaystyle=\\max(n,\\absolutevalue{{c}\_{\\text{bin}}},\\absolutevalue{{P}\_{\\text{bin}}}) |  | (18) |

ancilla qubits.
In summary, our methods requires the following number of qubits:

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐐TOTAL\\displaystyle\\mathbf{Q}\_{\\text{TOTAL}} | =𝐐PATH+𝐐CAPACITY+𝐐PROFIT+𝐐ANC\\displaystyle=\\mathbf{Q}\_{\\text{PATH}}+\\mathbf{Q}\_{\\text{CAPACITY}}+\\mathbf{Q}\_{\\text{PROFIT}}+\\mathbf{Q}\_{\\text{ANC}} |  |
|  |  | =n+\|cbin\|+\|Pbin\|\\displaystyle=n+\\absolutevalue{{c}\_{\\text{bin}}}+\\absolutevalue{{P}\_{\\text{bin}}} |  |
|  |  | +max⁡(n,\|cbin\|,\|Pbin\|).\\displaystyle\\quad+\\max(n,\\absolutevalue{{c}\_{\\text{bin}}},\\absolutevalue{{P}\_{\\text{bin}}}). |  | (19) |

Figure 8: Optimised parallelisation of addition.
The consecutive rotations gates, controlled by the same qubits, can be further merged into a single rotation gate. By introducing 3 ancilla qubits, we can further execute the addition gates within a single cycle. This comes at the expense of requiring four additional cycles that are given by duplicating the path register.

#### A.5.2 QFT

Figure 9: a) The subcircuit performing all the profit additions.
The profit register is QFT-ed in the beginning.
Subsequently, the respective item profits are added via the direct method.
The controlled Hadamard gates and the weight subtraction between the single additions are not depicted.
After all item profits are added, the register is transformed back.
b) The subtraction circuit including the comparison part.
The biased Hadamard gates on the path register are controlled on the capacity register by integer comparisons.
After the comparison the item weights are subtracted from the capacity register, controlled on the qubit just affected by the biased Hadamard gate.
Because of this alternating involvement of the capacity register, the intermediate QFTs and their inverses do not cancel each other.

Crucial for the efficient implementation of quantum adders (see [subsubsection A.5.3](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS3 "A.5.3 QFT Adder ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") and [subsubsection A.5.4](https://arxiv.org/html/2310.06623v2#A1.SS5.SSS4 "A.5.4 QFT Subtractor ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")) is the well-known Quantum Fourier Transform \[ [48](https://arxiv.org/html/2310.06623v2#bib.bib48 "")\] (QFT).
[Figure 6](https://arxiv.org/html/2310.06623v2#A1.F6 "Figure 6 ‣ A.4.1 QTG as a state sieve ‣ A.4 Runtime calculator ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") shows the general circuit representation of the QFT – unparallelised and parallelised – with shorthand notation

|     |     |     |
| --- | --- | --- |
|  | Rk≔\[100e2​π​i/2k\].\\displaystyle\\text{R}\_{k}\\coloneqq\\begin{bmatrix}1&0\\\<br>0&e^{2\\pi i/2^{k}}\\\<br>\\end{bmatrix}. |  |

##### Gate count.

The number of gates involved in the QFT is fully determined by the underlying register’s size.
Namely, to perform the QFT on the capacity register, the total number of gates required is given by

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆QFT-CAPACITY=\|cbin\|⁡(\|cbin\|+1)2.\\mathbf{G}\_{\\text{QFT-CAPACITY}}=\\dfrac{\\absolutevalue{{c}\_{\\text{bin}}}(\\absolutevalue{{c}\_{\\text{bin}}}+1)}{2}. |  | (20) |

Similarly, for the profit register, the total number of gates needed for the QFT is

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆QFT-PROFIT=\|Pbin\|⁡(\|Pbin\|+1)2.\\mathbf{G}\_{\\text{QFT-PROFIT}}=\\dfrac{\\absolutevalue{{P}\_{\\text{bin}}}(\\absolutevalue{{P}\_{\\text{bin}}}+1)}{2}. |  | (21) |

##### Cycle count.

Following the parallelisation strategy depicted in [Figure 6](https://arxiv.org/html/2310.06623v2#A1.F6 "Figure 6 ‣ A.4.1 QTG as a state sieve ‣ A.4 Runtime calculator ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems"), the number of cycles can be significantly reduced:
The level-specific gate sequences can be shifted such that each level merely introduces one additional cycle to the nonparallelisable gate sequence in the highest level.
As the length of the latter is given by the underlying register’s size, we derive the following formulas for the optimised QFT cycle count:

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐂QFT-CAPACITY\\displaystyle\\mathbf{C}\_{\\text{QFT-CAPACITY}} | =2​\|cbin\|−1,\\displaystyle=2\\absolutevalue{{c}\_{\\text{bin}}}-1, |  | (22) |
|  | 𝐂QFT-PROFIT\\displaystyle\\mathbf{C}\_{\\text{QFT-PROFIT}} | =2​\|Pbin\|−1.\\displaystyle=2\\absolutevalue{{P}\_{\\text{bin}}}-1. |  | (23) |

#### A.5.3 QFT Adder

Our version of the QFT adder is derived from the original proposal by Draper \[ [40](https://arxiv.org/html/2310.06623v2#bib.bib40 "")\].
The latter is designed to add together two integers n1n\_{1} and n2n\_{2} which are encoded into quantum states \|n1⟩\\ket{n\_{1}} and \|n2⟩\\ket{n\_{2}} on two different registers.
The result \|n1+n2⟩\\ket{n\_{1}+n\_{2}} is then stored in, say, the first register.
The entire QFT adder circuit consists of applying the QFT to the first register, then performing a cascade of rotations on the first register, controlled on the qubits of the second register, and finally applying the inverse QFT to the first register (see [Figure 7](https://arxiv.org/html/2310.06623v2#A1.F7 "Figure 7 ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") for an example on the profit register with additional control on some qubit in the path register).
Because the items’ profits that we wish to add are known in advance, we can instead remove the controls and implement all the rotations, controlled on qubits which would have been initialised in the \|1⟩\\ket{1}, directly.
In a second optimisation step, we merge all the rotations acting on the same qubits, thus reducing the overall gate count.
Furthermore, by copying the control qubit’s state multiple times on ancilla qubits, we substitute the shared control with controls on distinct qubits.
This allows us to entirely parallelise the the actual addition while introducing only logarithmically many additional copying cycles.
[Figure 8](https://arxiv.org/html/2310.06623v2#A1.F8 "Figure 8 ‣ A.5.1 Qubit count ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") shows an example of the direct addition method and its parallelised version which, in comparison to Draper’s method, requires fewer gates and cycles.

##### Gate count.

The number of actually implemented gates in the addition step depends on the main register’s size and the number we wish to add, more precisely, on the position of the least significant one in its binary representation:
In the original proposal of Draper, the ii-th qubit in the summand’s register controls S−i+1S-i+1 rotations in the main register, where SS is the size of the main register.
In the direct method, those S−i+1S-i+1 gates are implemented if and only if the ii-th qubit is in the \|1⟩\\ket{1} state, that is if and only if the classical ii-th bit is one.
We can see that the least significant one in the bit string introduces the most rotation gates.
As all rotations arising from higher bit positions are merged with the rotations stemming from this least significant one, already giving the number of rotations in the pure addition step.
The number of states copied beforehand requires one less qubit than the number of qubits acted on in the addition step;
the same amount of gates have to be applied after the addition in order to uncompute the ancilla qubits.

For a given profit pmp\_{m}, let LSO(pm)(p\_{m}) denote the index/position of its least significant one;
the gate count for adding pmp\_{m} to the QFT-ed profit register is then given by

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆DIRECTpm=3​(\|Pbin\|−LSO​(pm))+1.\\mathbf{G}\_{\\text{DIRECT}\_{p\_{m}}}=3(\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{m}))+1. |  | (24) |

Including the QFT and its inverse in the overall gate count for the additions, we obtain the following gate count for the QFT adder which adds the number pmp\_{m} to the profit register:

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐆ADDpm\\displaystyle\\mathbf{G}\_{\\text{ADD}\_{p\_{m}}} | =2​𝐆QFT-PROFIT+𝐆DIRECTpm\\displaystyle=2\\mathbf{G}\_{\\text{QFT-PROFIT}}+\\mathbf{G}\_{\\text{DIRECT}\_{p\_{m}}} |  |
|  |  | =\|Pbin\|⁡(\|Pbin\|+1)\\displaystyle=\\absolutevalue{{P}\_{\\text{bin}}}(\\absolutevalue{{P}\_{\\text{bin}}}+1) |  |
|  |  | +3​(\|Pbin\|−LSO​(pm))+1.\\displaystyle\\quad+3(\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{m}))+1. |  | (25) |

In the QTG circuit, all the additions on the profit registers are consecutive (see [Figure 9](https://arxiv.org/html/2310.06623v2#A1.F9 "Figure 9 ‣ A.5.2 QFT ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")) which allows for cancelling the inverse QFT within ADDpm{}\_{p\_{m}} and the QFT in ADDpm+1{}\_{p\_{m+1}} for all m=1,…,n−1m=1,\\ldots,n-1.
As a result, only one QFT and one inverse QFT are applied to the profit register in total.
The overall gate count for the addition of all item profits therefore reads

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐆ADD𝒑\\displaystyle\\mathbf{G}\_{\\text{ADD}\_{\\bm{p}}} | =2​𝐆QFT-PROFIT+∑m=1n𝐆DIRECTpm\\displaystyle=2\\mathbf{G}\_{\\text{QFT-PROFIT}}+\\sum\_{m=1}^{n}\\mathbf{G}\_{\\text{DIRECT}\_{p\_{m}}} |  |
|  |  | =\|Pbin\|⁡(\|Pbin\|+1)\\displaystyle=\\absolutevalue{{P}\_{\\text{bin}}}(\\absolutevalue{{P}\_{\\text{bin}}}+1) |  |
|  |  | +∑m=1n(3(\|Pbin\|−LSO(pm))+1).\\displaystyle\\quad+\\sum\_{m=1}^{n}(3(\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{m}))+1). |  | (26) |

##### Cycle count.

Due to the distributed control onto several ancilla qubits all rotational gates can be executed in parallel.
The control on the QFT and inverse QFT can be dropped completely.
The update of the ancilla qubits as well as the reverse operation can be parallelised into logarithmically many cycles, respectively.
In summary, we obtain here

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐂ADD𝒑\\displaystyle\\mathbf{C}\_{\\text{ADD}\_{\\bm{p}}} | =2​𝐂QFT-PROFIT\\displaystyle=2\\mathbf{C}\_{\\text{QFT-PROFIT}} |  |
|  |  | +∑m=1n(2⌈log2(\|Pbin\|−LSO(pm))⌉+1)\\displaystyle\\quad+\\sum\_{m=1}^{n}\\big(2\\lceil\\log\_{2}(\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{m}))\\rceil+1\\big) |  |
|  |  | =4​\|Pbin\|−2\\displaystyle=4\\absolutevalue{{P}\_{\\text{bin}}}-2 |  |
|  |  | +∑m=1n(2⌈log2(\|Pbin\|−LSO(pm))⌉+1).\\displaystyle\\quad+\\sum\_{m=1}^{n}\\big(2\\lceil\\log\_{2}(\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{m}))\\rceil+1\\big). |  | (27) |

#### A.5.4 QFT Subtractor

By flipping all the rotations’ signs, the QFT adder circuit can be used to subtract a given integer.
Therefore, adding and subtracting both yield the same gate count.

##### Gate count.

For a given profit wmw\_{m}, let LSO(wm)(w\_{m}) denote its least significant one’s position;
the gate count for subtracting wmw\_{m} from the QFT-ed capacity register is then given by

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆DIRECTwm=3​(\|cbin\|−LSO​(wm))+1.\\mathbf{G}\_{\\text{DIRECT}\_{w\_{m}}}=3(\\absolutevalue{{c}\_{\\text{bin}}}-\\text{LSO}(w\_{m}))+1. |  | (28) |

Analogous to the QFT adder, including the QFT and its inverse in the overall gate count for the subtractions, we obtain the following gate count for the QFT subtractor which subtracts the number wmw\_{m} from the capacity register

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐆SUBwm\\displaystyle\\mathbf{G}\_{\\text{SUB}\_{w\_{m}}} | =2​𝐆QFT-CAPACITY+𝐆DIRECTwm\\displaystyle=2\\mathbf{G}\_{\\text{QFT-CAPACITY}}+\\mathbf{G}\_{\\text{DIRECT}\_{w\_{m}}} |  |
|  |  | =\|cbin\|⁡(\|cbin\|+1)\\displaystyle=\\absolutevalue{{c}\_{\\text{bin}}}(\\absolutevalue{{c}\_{\\text{bin}}}+1) |  |
|  |  | +3​(\|cbin\|−LSO​(wm))+1.\\displaystyle\\quad+3(\\absolutevalue{{c}\_{\\text{bin}}}-\\text{LSO}(w\_{m}))+1. |  | (29) |

Unlike the profit additions, the weight subtractions in the QTG circuit are followed by a comparison procedure, respectively, hence the intermediate QFT and inverse QFT do not cancel each other (see [Figure 9](https://arxiv.org/html/2310.06623v2#A1.F9 "Figure 9 ‣ A.5.2 QFT ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")).
To reduce the number of gates, however, we omit the last subtraction SUBwn{}\_{w\_{n}}, because the capacity register is not checked again after the last item inclusion.
All together, this leads to a total gate count of

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐆SUB𝒘\\displaystyle\\mathbf{G}\_{\\text{SUB}\_{\\bm{w}}} | =2​(n−1)​𝐆QFT-CAPACITY+∑m=1n−1𝐆DIRECTwm\\displaystyle=2(n-1)\\mathbf{G}\_{\\text{QFT-CAPACITY}}+\\sum\_{m=1}^{n-1}\\mathbf{G}\_{\\text{DIRECT}\_{w\_{m}}} |  |
|  |  | =(n−1)​\|cbin\|​(\|cbin\|+1)\\displaystyle=(n-1)\\absolutevalue{{c}\_{\\text{bin}}}(\\absolutevalue{{c}\_{\\text{bin}}}+1) |  |
|  |  | +∑m=1n−1(3(\|cbin\|−LSO(wm))+1).\\displaystyle\\quad+\\sum\_{m=1}^{n-1}(3(\\absolutevalue{{c}\_{\\text{bin}}}-\\text{LSO}(w\_{m}))+1). |  | (30) |

##### Cycle count.

In analogy to the QFT adder, we obtain a total cycle count of

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐂SUB𝒘\\displaystyle\\mathbf{C}\_{\\text{SUB}\_{\\bm{w}}} | =2​(n−1)​𝐂QFT-CAPACITY\\displaystyle=2(n-1)\\mathbf{C}\_{\\text{QFT-CAPACITY}} |  |
|  |  | +∑m=1n−1(2⌈log2(\|cbin\|−LSO(wm))⌉+1)\\displaystyle\\quad+\\sum\_{m=1}^{n-1}\\big(2\\lceil\\log\_{2}(\\absolutevalue{{c}\_{\\text{bin}}}-\\text{LSO}(w\_{m}))\\rceil+1\\big) |  |
|  |  | =4​(n−1)​\|cbin\|−2​(n−1)\\displaystyle=4(n-1)\\absolutevalue{{c}\_{\\text{bin}}}-2(n-1) |  |
|  |  | +∑m=1n−1(2⌈log2(\|cbin\|−LSO(wm))⌉+1).\\displaystyle\\quad+\\sum\_{m=1}^{n-1}\\big(2\\lceil\\log\_{2}(\\absolutevalue{{c}\_{\\text{bin}}}-\\text{LSO}(w\_{m}))\\rceil+1\\big). |  | (31) |

#### A.5.5 Comparison

Figure 10: The optimal decomposition of a 7-qubit-controlled unitary UU. In contrast to the standard decomposition method (see \[ [49](https://arxiv.org/html/2310.06623v2#bib.bib49 "")\])which lacks gate parallelisation, our approach reduces the cycle count from 13 to 7 .

Within the QTG-based search, there are three subcircuits requiring the comparison of two integers:
First, the biased Hadamard gates within the QTG should only be executed if the remaining capacity in the second register is at least as large as the respective item weight.
Therefore, we have to implement the integer comparisons “c~≥wm\\tilde{c}\\geq w\_{m}” with unknown c~\\tilde{c}, but known wmw\_{m}, m=1,…,n−1m=1,\\ldots,n-1.
Second, the Amplitude Amplification operator 𝒬\\mathcal{Q} contains the reflection 𝒮0\\mathcal{S}\_{0}, which flips the ancilla qubit’s state if and only if the path register is in the \|𝟎⟩1\\ket{\\bm{0}}^{1} state.
Third, the threshold-dependent phase oracle within the Amplitude Amplification operator flips the ancilla state, if and only if the third register enables a profit larger than the current threshold.
That is, for known thresholds TT and unknown pp, we have to implement the comparisons “p>Tp>T”.

We realise all the above operations as multi-controlled single-target gates.
In [Figure 10](https://arxiv.org/html/2310.06623v2#A1.F10 "Figure 10 ‣ A.5.5 Comparison ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems") we provide an example of the optimal decomposition of a multi-controlled unitary UU.
The control circuit is derived from the classical digital comparator \[ [50](https://arxiv.org/html/2310.06623v2#bib.bib50 "")\]:
Given two binary represented integers a=aℓ​…​a1a=a\_{\\ell}\\ldots a\_{1} and b=bℓ​…​b1b=b\_{\\ell}\\ldots b\_{1}, introduce the Boolean variables

|     |     |     |     |
| --- | --- | --- | --- |
|  | ci≔ai​bi∨a¯i​b¯i,\\displaystyle c\_{i}\\coloneqq a\_{i}b\_{i}\\lor\\overline{a}\_{i}\\overline{b}\_{i}, |  | (32) |

which are 1 if and only if ai=bia\_{i}=b\_{i}, respectively.
Then equality and strict inequalities in both directions can be expressed as

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | (a=b)\\displaystyle(a=b) | =⋀i=1ℓci,\\displaystyle=\\bigwedge\_{i=1}^{\\ell}c\_{i}, |  | (33) |
|  | (a>b)\\displaystyle(a>b) | =⋁i=1ℓ(ai​b¯i​⋀j=i+1ℓcj),\\displaystyle=\\bigvee\_{i=1}^{\\ell}\\bigg(a\_{i}\\overline{b}\_{i}\\bigwedge\_{j=i+1}^{\\ell}c\_{j}\\bigg), |  | (34) |
|  | (a<b)\\displaystyle(a<b) | =⋁i=1ℓ(a¯i​bi​⋀j=i+1ℓcj).\\displaystyle=\\bigvee\_{i=1}^{\\ell}\\bigg(\\overline{a}\_{i}b\_{i}\\bigwedge\_{j=i+1}^{\\ell}c\_{j}\\bigg). |  | (35) |

If the integer bb is known, the variables ( [32](https://arxiv.org/html/2310.06623v2#A1.E32 "In A.5.5 Comparison ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")) can be reduced to a single literal, leaving ( [33](https://arxiv.org/html/2310.06623v2#A1.E33 "In A.5.5 Comparison ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems"))–( [35](https://arxiv.org/html/2310.06623v2#A1.E35 "In A.5.5 Comparison ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")) in orthogonal disjunctive normal form (ODNF).
In addition, for (a>b)(a>b) only those clauses contribute for which b¯i\\overline{b}\_{i} is 1, i.e., bib\_{i} is 0.
Analogously, for (a<b)(a<b) only those clauses contribute for which bib\_{i} is 1.

There are now two possibilities when implementing an operation UU which is controlled by a Boolean expression.

1. 1.


UU is applied if and only if the Boolean expression is fulfilled.

2. 2.


UU is first applied unconditionally.
Then its inverse is applied if and only if the Boolean expression is not fulfilled.


In any case, an ODNF that is checked for is beneficial as its quantisation is straightforward:
Each clause 𝒞\\mathcal{C} translates into a multi-controlled-UU (resp. U−1U^{-1}) where the control runs over all the qubits representing Boolean variables in 𝒞\\mathcal{C}.
If the classical literal is positive, we control on whether the corresponding qubit is in the \|1⟩\\ket{1} state, otherwise whether it is in the \|0⟩\\ket{0} state.
Because we assume an ODNF, we can ensure that UU (resp. U−1U^{-1}) is applied at most once when translating all the clauses into consecutive multi-controlled operations.

##### Gate count.

For a given item weight wmw\_{m}, we can now calculate the gate count for implementing the multi-controlled Hadamard gate C≥wm2​(Hbxm)C\_{\\geq w\_{m}}^{2}(\\text{H}^{x\_{m}}\_{b}).
Following the first strategy of applying Hbxm{}^{x\_{m}}\_{b} if and only if the remaining capacity covers wmw\_{m} (that is if c~>wm−1\\tilde{c}>w\_{m}-1) and assuming (i) as well as (iii), we obtain the count

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆≥wm(1)=∑i=1\|wmbin\|(1−(wm−1)i)​(2​(\|cbin\|−i)+1).\\displaystyle\\mathbf{G}\_{\\geq w\_{m}}^{(1)}=\\sum\_{i=1}^{\\absolutevalue{{w\_{m}}\_{\\text{bin}}}}(1-(w\_{m}-1)\_{i})(2(\\absolutevalue{{c}\_{\\text{bin}}}-i)+1). |  | (36) |

This implementation is favourable for weights wmw\_{m} with comparatively many ones in the less significant bits of the binary representation of the number wm−1w\_{m}-1.
Alternatively, following the second strategy, Hbxm{}^{x\_{m}}\_{b} is first applied unconditionally (adding one to the gate count);
then its inverse is applied if and only if the remaining capacity is strictly smaller than wmw\_{m}.
Again assuming (i) and (iii), this yields a total gate count of

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆≥wm(2)=1+∑i=1\|wmbin\|(wm)i​(2​(\|cbin\|−i)+1).\\displaystyle\\mathbf{G}\_{\\geq w\_{m}}^{(2)}=1+\\sum\_{i=1}^{\\absolutevalue{{w\_{m}}\_{\\text{bin}}}}(w\_{m})\_{i}(2(\\absolutevalue{{c}\_{\\text{bin}}}-i)+1). |  | (37) |

For the concrete circuit construction, we can then simply pick the implementation that requires fewer gates, i.e.,

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆≥wm=min⁡(𝐆≥wm(1),𝐆≥wm(2)).\\displaystyle\\mathbf{G}\_{\\geq w\_{m}}=\\min\\left(\\mathbf{G}\_{\\geq w\_{m}}^{(1)},\\mathbf{G}\_{\\geq w\_{m}}^{(2)}\\right). |  | (38) |

The implementation of the reflection 𝒮0\\mathcal{S}\_{0} is even more straightforward:
We simply have to check whether the path register is in the state \|𝟎⟩1\\ket{\\bm{0}}^{1} and control the ancilla flip on the outcome.
According to (i) and (iii), this yields a gate count of

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆=0=2​n−1.\\displaystyle\\mathbf{G}\_{=0}=2n-1. |  | (39) |

Lastly, the phase oracle is also realised as a single-qubit operation controlled on the truth value of a Boolean expression.
The derivation of the gate count follows the same construction as for the multi-controlled Hadamard gate, with the only exception being that the phase oracle asks for a strict inequality “p>Tp>T”.
Hence we obtain

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐆>T(1)\\displaystyle\\mathbf{G}\_{>T}^{(1)} | =∑i=1\|Tbin\|(1−(T)i)​(2​(\|Pbin\|−i)+1),\\displaystyle=\\sum\_{i=1}^{\\absolutevalue{{T}\_{\\text{bin}}}}(1-(T)\_{i})(2(\\absolutevalue{{P}\_{\\text{bin}}}-i)+1), |  | (40) |
|  | 𝐆>T(2)\\displaystyle\\mathbf{G}\_{>T}^{(2)} | =1+∑i=1\|Tbin\|(T+1)i​(2​(\|Pbin\|−i)+1),\\displaystyle=1+\\sum\_{i=1}^{\\absolutevalue{{T}\_{\\text{bin}}}}(T+1)\_{i}(2(\\absolutevalue{{P}\_{\\text{bin}}}-i)+1), |  | (41) |
|  | 𝐆>T\\displaystyle\\mathbf{G}\_{>T} | =min⁡(𝐆>T(1),𝐆>T(2)).\\displaystyle=\\min\\left(\\mathbf{G}\_{>T}^{(1)},\\mathbf{G}\_{>T}^{(2)}\\right). |  | (42) |

##### Cycle count.

Via the parallelised decomposition of multi-controlled gates exemplified in [Figure 10](https://arxiv.org/html/2310.06623v2#A1.F10 "Figure 10 ‣ A.5.5 Comparison ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems"), the respective cycle counts improve logarithmically over the gate counts.
More precisely, we obtain

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  |  | 𝐂≥wm(1)=∑i=1\|wmbin\|(1−(wm−1)i)​(2​⌈log2⁡(\|cbin\|−i)⌉+1)\\displaystyle\\mathbf{C}\_{\\geq w\_{m}}^{(1)}=\ \\,\\sum\_{i=1}^{\\absolutevalue{{w\_{m}}\_{\\text{bin}}}}\ (1-(w\_{m}-1)\_{i})(2\\lceil\\log\_{2}(\\absolutevalue{{c}\_{\\text{bin}}}-i)\\rceil+1) |  | (43) |

for the first comparison strategy,

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  |  | 𝐂≥wm(2)=1+∑i=1\|wmbin\|(wm−1)i​(2​⌈log2⁡(\|cbin\|−i)⌉+1)\\displaystyle\\mathbf{C}\_{\\geq w\_{m}}^{(2)}=1+\ \\,\\sum\_{i=1}^{\\absolutevalue{{w\_{m}}\_{\\text{bin}}}}\ (w\_{m}-1)\_{i}(2\\lceil\\log\_{2}(\\absolutevalue{{c}\_{\\text{bin}}}-i)\\rceil+1) |  | (44) |

for the second comparison method, and thus lastly

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐂≥wm=min⁡(𝐂≥wm(1),𝐂≥wm(2)).\\displaystyle\\mathbf{C}\_{\\geq w\_{m}}=\\min\\left(\\mathbf{C}\_{\\geq w\_{m}}^{(1)},\\mathbf{C}\_{\\geq w\_{m}}^{(2)}\\right). |  | (45) |

Meanwhile, the cycle cost for the reflection circuit 𝒮0\\mathcal{S}\_{0} computes to

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐂=0=2​⌈log2⁡(n−1)⌉+1.\\displaystyle\\mathbf{C}\_{=0}=2\\lceil\\log\_{2}(n-1)\\rceil+1. |  | (46) |

For the phase oracle, we also list both implementation strategies together with their corresponding cycle count:

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐂>T(1)\\displaystyle\\mathbf{C}\_{>T}^{(1)} | =∑i=1\|Tbin\|(1−(T)i)​(2​(⌈log2⁡(\|Pbin\|−i)⌉+1)CLOSE,\\displaystyle=\ \\sum\_{i=1}^{\\absolutevalue{{T}\_{\\text{bin}}}}(1-(T)\_{i})(2(\\lceil\\log\_{2}(\\absolutevalue{{P}\_{\\text{bin}}}-i)\\rceil+1), |  | (47) |
|  | 𝐂>T(2)\\displaystyle\\mathbf{C}\_{>T}^{(2)} | =1+∑i=1\|Tbin\|(T+1)i(2⌈log2(⌈\|Pbin\|−i)⌉+1),\\displaystyle=1+\\sum\_{i=1}^{\\absolutevalue{{T}\_{\\text{bin}}}}(T+1)\_{i}(2\\lceil\\log\_{2}(\\lceil\\absolutevalue{{P}\_{\\text{bin}}}-i)\\rceil+1), |  | (48) |
|  | 𝐂>T\\displaystyle\\mathbf{C}\_{>T} | =min⁡(𝐂>T(1),𝐂>T(2)).\\displaystyle=\\min\\left(\\mathbf{C}\_{>T}^{(1)},\\mathbf{C}\_{>T}^{(2)}\\right). |  | (49) |

#### A.5.6 QTG

After having detailed the resource estimations for all crucial subcircuits, we discuss now the overall gate and cycle count for the entire QTG.
We assume here the more resource-efficient version of the QTG that does not contain the last capacity update Un2U\_{n}^{2}.
Furthermore, because the ancilla qubits are used for controlling both the subtractions in the capacity register and the additions in the profit register, we may fuse the copy processes (and their inverses) that are used before applying the arithmetic rotation gates.
The gate and cycle count then is dominated by the operation that demands more rotations.

##### Gate count.

The total gate count for QTG arises as the sum of the gates counts for the nn controlled Hadamard gates Um1U\_{m}^{1} and for the capacity/profit updates with their copying steps merged as already mentioned.

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐆QTG\\displaystyle\\mathbf{G}\_{\\text{QTG}} | =∑m=1n𝐆≥wm+2​𝐆QFT-PROFIT+2​(n−1)​𝐆QFT-CAPACITY\\displaystyle=\\sum\_{m=1}^{n}\\mathbf{G}\_{\\geq w\_{m}}+2\\mathbf{G}\_{\\text{QFT-PROFIT}}+2(n-1)\\mathbf{G}\_{\\text{QFT-CAPACITY}} |  |
|  |  | +2∑m=1n−1(max(\|Pbin\|,\|cbin\|)−min(LSO(pm),LSO(wm)))+2(\|Pbin\|−LSO(pn))\\displaystyle\\quad+2\\sum\_{m=1}^{n-1}\\big(\\max(\\absolutevalue{{P}\_{\\text{bin}}},\\absolutevalue{{c}\_{\\text{bin}}})-\\min(\\text{LSO}(p\_{m}),\\text{LSO}(w\_{m}))\\big)+2(\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{n})) |  |
|  |  | +∑m=1n−1(\|Pbin\|−LSO(pm)+\|cbin\|−LSO(wm)+2)+\|Pbin\|−LSO(pn)+1.\\displaystyle\\quad+\\sum\_{m=1}^{n-1}\\big(\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{m})+\\absolutevalue{{c}\_{\\text{bin}}}-\\text{LSO}(w\_{m})+2\\big)+\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{n})+1. |  | (50) |

##### Cycle count.

Up to this point, we have explored various methodologies to optimise the efficiency of gate and cycle counts for each component of the QTG.
Now our focus shifts towards improving its overall cycle count.
We take into account the following considerations:

- I.


Copying qubit information from the path register into the ancilla register as well as the reversed operation can both be run in parallel with all the QFTc{}\_{\\text{c}} and QFT†c{}^{\\dagger}\_{\\text{c}} on the capacity register.

- II.


The number of cycles within the QFTc{}\_{\\text{c}} (logarithmic in cc) always exceeds the number of cycles involved in copying the control qubit onto the ancilla qubits (doubly-logarithmic in cc and PP).

- III.


The QFTp{}\_{\\text{p}} on the profit register can be run in parallel with all the gates in the capacity register, as it does not involve any controlled operations.


Our first observation is, however, that the different layers Um=Um3​Um2​Um1U^{\\vphantom{1}}\_{m}=U\_{m}^{3}U\_{m}^{2}U\_{m}^{1} have to be executed mutually disjointly as the subtraction in Um2U\_{m}^{2} and the addition in Um3U\_{m}^{3} are controlled by the qubits that the biased Hadamard gates in Um1U\_{m}^{1} act on.
Therefore, no components commute across different layers, and we obtain

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐂QTG=∑m=1n𝐂m,\\displaystyle\\mathbf{C}\_{\\text{QTG}}=\\sum\_{m=1}^{n}\\mathbf{C}\_{m}, |  | (51) |

where 𝐂m\\mathbf{C}\_{m} denotes the cycle count per layer unitary UmU\_{m}.
Furthermore, there cannot be any parallelisation between Um1U\_{m}^{1} and the rest of the layer;
though other parallelisation techniques are definitely applicable.

In the first layer we parallelise, according to III, QFTp and QFTc as much as possible.
Due to I and II, we can also fit in the subcircuit copying the control qubit’s information on the ancilla register.
If \|Pbin\|>\|cbin\|\\absolutevalue{{P}\_{\\text{bin}}}>\\absolutevalue{{c}\_{\\text{bin}}}, meaning that the 𝐂QFT-PROFIT>𝐂QFT-CAPACITY\\mathbf{C}\_{\\text{QFT-PROFIT}}>\\mathbf{C}\_{\\text{QFT-CAPACITY}}, we can absorb the subtraction cycle, again due to III, into the profit QFT.
The remaining addition cycle as well as uncomputing the ancilla qubits can be absorbed into the subsequent QFT†c{}\_{\\text{c}}^{\\dagger}.
In this first case we obtain

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐂1(1)=𝐂≥w1+𝐂QFT-CAPACITY+𝐂QFT-PROFIT\\displaystyle\\mathbf{C}\_{1}^{(1)}=\\mathbf{C}\_{\\geq w\_{1}}+\\mathbf{C}\_{\\text{QFT-CAPACITY}}+\\mathbf{C}\_{\\text{QFT-PROFIT}} |  | (52) |

Otherwise the subtraction cycle has to be carried out unparallelised, yielding

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐂1(2)=𝐂≥w1+2​𝐂QFT-CAPACITY+1.\\displaystyle\\mathbf{C}\_{1}^{(2)}=\\mathbf{C}\_{\\geq w\_{1}}+2\\mathbf{C}\_{\\text{QFT-CAPACITY}}+1. |  | (53) |

The other layer unitaries, except for the last one, are similarly constructed, but do not include any (inverse) QFT on the profit register.
In terms of cycles we are thus in the same situation as ( [53](https://arxiv.org/html/2310.06623v2#A1.E53 "In Cycle count. ‣ A.5.6 QTG ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")), that is

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐂m=𝐂≥wm+2​𝐂QFT-CAPACITY+1.\\displaystyle\\mathbf{C}\_{m}=\\mathbf{C}\_{\\geq w\_{m}}+2\\mathbf{C}\_{\\text{QFT-CAPACITY}}+1. |  | (54) |

The last layer unitary contains the inverse QFT for the profit register, but no weight subtraction in the capacity register.
Here, the copy subcircuit as well as the addition cycle cannot be executed in parallel with any other operation.
Therefore, we obtain

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | 𝐂n\\displaystyle\\mathbf{C}\_{n} | =𝐂≥wn+⌈log2⁡(\|Pbin\|−LSO​(pn))⌉\\displaystyle=\\mathbf{C}\_{\\geq w\_{n}}+\\lceil\\log\_{2}(\\absolutevalue{{P}\_{\\text{bin}}}-\\text{LSO}(p\_{n}))\\rceil |  |
|  |  | +𝐂QFT-PROFIT+1.\\displaystyle\\quad+\\mathbf{C}\_{\\text{QFT-PROFIT}}+1. |  | (55) |

#### A.5.7 QMaxSearch

In contrast to the QTG whose gate and cycle count can be determined in advance the QMaxSearch routine has to be simulated to infer its total resource requirement.
In order to derive a symbolic expression we assume that a run of QMaxSearch produces a sequence (Tk)k=1R(T\_{k})\_{k=1}^{R} of intermediate thresholds with T1T\_{1} being the result of Integer Greedy.
The search method is therefore not able to find a better total profit than TRT\_{R} which might indicate that an optimal solution has been found.
For each of these thresholds TkT\_{k}, QSearch is executed, incorporating the comparison “P𝒙>TkP\_{\\bm{x}}>T\_{k}” as phase oracle.
Within a given instance of QSearch a sequence (jℓ(k))ℓ=1S⁡(k)(j^{(k)}\_{\\ell})\_{\\ell=1}^{S(k)} of powers is constructed such that the termination condition

|     |     |     |     |
| --- | --- | --- | --- |
|  | ∑ℓ=1S⁡(R)−12​jℓ(R)+1<M≤∑ℓ=1S⁡(R)2​jℓ(R)+1\\displaystyle\\sum\_{\\ell=1}^{S(R)-1}2j^{(R)}\_{\\ell}+1<M\\leq\\sum\_{\\ell=1}^{S(R)}2j^{(R)}\_{\\ell}+1 |  | (56) |

holds in the last application of QSearch.
For all prior iterations the termination condition is never triggered, because an improved threshold is found, respectively.

##### Gate count.

From the knowledge about the threshold TkT\_{k} and the corresponding power sequence we can now determine the gate count of the kk-th iteration of QSearch:
Before applying 𝒬\\mathcal{Q} with a given power jj the QTG is applied once to create the initial superposition of feasible states.
The definition ( [11](https://arxiv.org/html/2310.06623v2#A1.E11 "In A.3 Quantum maximum finding ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")) of the Amplitude Amplification operator immediately gives rise to its gate count

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆𝒬k=2​𝐆QTG+𝐆=0+𝐆>Tk.\\displaystyle\\mathbf{G}\_{\\mathcal{Q}\_{k}}=2\\mathbf{G}\_{\\text{QTG}}+\\mathbf{G}\_{=0}+\\mathbf{G}\_{>T\_{k}}. |  | (57) |

Multiplying the latter with the respective power and summing over all powers we obtain for the kk-th iteration of QSearch a gate count of

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆QSearchk=∑ℓ=1S⁡(k)(2​jℓ(k)+1)​𝐆QTG+jℓ(k)​(𝐆=0+𝐆>Tk).\\displaystyle\\mathbf{G}\_{\\text{QSearch}\_{k}}=\\sum\_{\\ell=1}^{S(k)}(2j\_{\\ell}^{(k)}+1)\\mathbf{G}\_{\\text{QTG}}+j\_{\\ell}^{(k)}(\\mathbf{G}\_{=0}+\\mathbf{G}\_{>T\_{k}}). |  | (58) |

The total gate count of QMaxSearch is then given by

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐆QMaxSearch=∑k=1R𝐆QSearchk.\\displaystyle\\mathbf{G}\_{\\text{QMaxSearch}}=\\sum\_{k=1}^{R}\\mathbf{G}\_{\\text{QSearch}\_{k}}. |  | (59) |

##### Cycle count.

Because the operators 𝒮0\\mathcal{S}\_{0} and 𝒮P𝒙>Tk\\mathcal{S}\_{P\_{\\bm{x}}>T\_{k}} are controlled on the profit register’s qubits no further parallelisation within 𝒬\\mathcal{Q} is possible.
Therefore, we obtain for the QSearch cycle count

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐂QSearchk=∑ℓ=1S⁡(k)(2​jℓ(k)+1)​𝐂QTG+jℓ(k)​(𝐂=0+𝐂>Tk)\\displaystyle\\mathbf{C}\_{\\text{QSearch}\_{k}}=\\sum\_{\\ell=1}^{S(k)}(2j\_{\\ell}^{(k)}+1)\\mathbf{C}\_{\\text{QTG}}+j\_{\\ell}^{(k)}(\\mathbf{C}\_{=0}+\\mathbf{C}\_{>T\_{k}}) |  | (60) |

and, analogously, for the final cycle count of the entire
QMaxSearch routine

|     |     |     |     |
| --- | --- | --- | --- |
|  | 𝐂QMaxSearch=∑k=1R𝐂QSearchk.\\displaystyle\\mathbf{C}\_{\\text{QMaxSearch}}=\\sum\_{k=1}^{R}\\mathbf{C}\_{\\text{QSearch}\_{k}}. |  | (61) |

The formula ( [61](https://arxiv.org/html/2310.06623v2#A1.E61 "In Cycle count. ‣ A.5.7 QMaxSearch ‣ A.5 Resource estimation ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")) is precisely what is being used for calculated the elapsed quantum cycles in [Figure 3](https://arxiv.org/html/2310.06623v2#S4.F3 "Figure 3 ‣ IV Methods ‣ A quantum algorithm for solving 0-1 Knapsack problems").

### A.6 Benchmarking of competitive quantum methods

This section contains a brief overview and runtime estimations of the nested quantum search \[ [25](https://arxiv.org/html/2310.06623v2#bib.bib25 "")\] and quantum branch-and-bound \[ [27](https://arxiv.org/html/2310.06623v2#bib.bib27 ""), [38](https://arxiv.org/html/2310.06623v2#bib.bib38 "")\] algorithms, together with our benchmarking reasoning.

#### A.6.1 Nested Quantum Search

Nested quantum search (NQS) is a nested version of Grover’s algorithm specifically tailored to constraint satisfaction problems, where the search Hilbert space is decomposed into two factors ℋS=ℋA⊗ℋB\\mathcal{H}\_{\\text{S}}=\\mathcal{H}\_{\\text{A}}\\otimes\\mathcal{H}\_{\\text{B}}, corresponding to a decomposition S=A∪B\\text{S}=\\text{A}\\cup\\text{B} of the set of classical variables.
The algorithm itself is a variant of QSearch, where the superposition-creating unitary 𝒜\\mathcal{A} consists of the following two steps:

1. 1.


Grover’s search in the first tensor factor ℋA\\mathcal{H}\_{\\text{A}} to (nearly) obtain a uniform superposition of _could-be_ solutions, i.e. partial assignments (only variables in A are assigned) that fulfill all constraints that are testable on these variables.
Accordingly, these are precisely the partial assignments that _could be_ extended to a full solution of the problem.
The employed oracle checks whether a partial assignment is a could-be solution and is assumed to only act on ℋA\\mathcal{H}\_{\\text{A}}.

2. 2.


Subsequent Grover’s search on the second tensor factor ℋB\\mathcal{H}\_{\\text{B}}, but with an oracle that acts on the entire space ℋS\\mathcal{H}\_{\\text{S}} and marks full (and not partial) solutions.


The first step of NQS creates a superposition of all, say tAt\_{\\text{A}}, could-be solutions plus a vanishing amount of non could-be solutions;
this step involves ∼2\|A\|/tA\\sim\\sqrt{2^{\\absolutevalue{\\text{A}}}/t\_{\\text{A}}} Grover iterations.
Second, assume that each could-be solution gives rise to at most one full solution and let tB∈\[0,1\]t\_{\\text{B}}\\in\[0,1\] be the average number of full solutions per partial solution.
Then the total number of solutions is given by tAB=tA​tB≤tAt\_{\\text{AB}}=t\_{\\text{A}}t\_{\\text{B}}\\leq t\_{\\text{A}}.
Executing the second step produces a superposition of all solutions with amplitude ∼1​tA\\sim 1\\sqrt{t\_{\\text{A}}} and all infeasible solutions, which extend from could-be solutions that did not give rise to any solution, with amplitude ∼1/tA​2\|B\|\\sim 1/\\sqrt{t\_{\\text{A}}2^{\\absolutevalue{\\text{B}}}}, plus a vanishing amount of other infeasible solutions after ∼2\|B\|/tB\\sim\\sqrt{2^{\\absolutevalue{\\text{B}}}/t\_{\\text{B}}} steps.
The total number of Grover iterations per state preparation is

|     |     |     |
| --- | --- | --- |
|  | T∼2\|A\|/tA+2\|B\|/tB.\\displaystyle T\\sim\\sqrt{2^{\\absolutevalue{\\text{A}}}/t\_{A}}+\\sqrt{2^{\\absolutevalue{\\text{B}}}/t\_{B}}. |  |

Because there are now tABt\_{\\text{AB}} solution states each having an amplitude of ∼1/tA\\sim 1/\\sqrt{t\_{\\text{A}}}, they can be amplified to yield a positive outcome upon measuring after ∼tA/tAB\\sim\\sqrt{t\_{\\text{A}}/t\_{\\text{AB}}} iterations within QSearch.
In total this yields

|     |     |     |     |
| --- | --- | --- | --- |
|  | TNQS=T​tA/tAB∼2\|A\|/(tA​tB)+2\|B\|\\displaystyle T\_{\\text{{NQS}}}=T\\sqrt{t\_{\\text{A}}/t\_{\\text{AB}}}\\sim\\sqrt{2^{\\absolutevalue{\\text{A}}}/(t\_{\\text{A}}t\_{\\text{B}})}+\\sqrt{2^{\\absolutevalue{\\text{B}}}} |  | (62) |

Grover iterations.

NQS can also be used for constrained optimisation problems by employing it as a feasible state preparation subroutine (i.e. the measurement is omitted), on top of which QMaxSearch is executed.
For the KP\\KP, we can utilise the constraint checking techniques from the QTG also within NQS.
To derive the trend of Grover iterations required to find an optimum, we first find the best decomposition of the nn decision variables into variable sets A and B:
Following \[ [51](https://arxiv.org/html/2310.06623v2#bib.bib51 "")\], we define a break item

|     |     |     |     |
| --- | --- | --- | --- |
|  | h=max⁡{m′:∑m=1m′wm′≤c},\\displaystyle h=\\max\\left\\{m^{\\prime}:\\sum\_{m=1}^{m^{\\prime}}w\_{m^{\\prime}}\\leq c\\right\\}, |  | (63) |

where every partial assignment up to this item is feasible.
The first set of variables will be A={1,…,h,…,h+k}\\text{A}=\\{1,\\ldots,h,\\ldots,h+k\\} with 0≤k≤n−h}0\\leq k\\leq n-h\\} yet to be determined;
accordingly, B will be given as B={h+k+1,…,n}\\text{B}=\\{h+k+1,\\ldots,n\\}.
Furthermore, note that every feasible partial assignment can always be extended to a feasible full assignment and that any lower bound on the number of feasible solutions also gives a lower bound on the runtime of QMaxSearch as fewer elements have to be searched through for the optimum.
Thus, assuming that each partial assignment has exactly one feasible solution and therefore that tB=1t\_{\\text{B}}=1 and tAB=tAt\_{\\text{AB}}=t\_{\\text{A}} gives an optimistic lower bound on the runtime of QMaxSearch.

Using our assumption and the structure of A and B, ( [62](https://arxiv.org/html/2310.06623v2#A1.E62 "In A.6.1 Nested Quantum Search ‣ A.6 Benchmarking of competitive quantum methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems")) gives rise to an NQS-runtime of

|     |     |     |
| --- | --- | --- |
|  | TNQS∼2h+k/2h+2n−h−k=2k+2n−h−k\\displaystyle T\_{\\text{{NQS}}}\\sim\\sqrt{2^{h+k}/2^{h}}+\\sqrt{2^{n-h-k}}=\\sqrt{2^{k}}+\\sqrt{2^{n-h-k}} |  |

This produces an equal superposition of 2h2^{h} feasible solutions upon which we now have to find the maximum which therefore requires ∼2h\\sim\\sqrt{2^{h}} iterations of NQS within QMaxSearch, yielding a total number of Grover iterations

|     |     |     |
| --- | --- | --- |
|  | TNQS​2h∼2h+k+2n−k.\\displaystyle T\_{\\text{{NQS}}}\\sqrt{2^{h}}\\sim\\sqrt{2^{h+k}}+\\sqrt{2^{n-k}}. |  |

This expression is minimal for k=n−h2k=\\frac{n-h}{2}, leading to a number of Grover iterations of order

|     |     |     |     |
| --- | --- | --- | --- |
|  | 2(n+h)/2+2n−h−(n−h)/2=2(n+h)/4.\\displaystyle\\sqrt{2^{(n+h)/2}}+\\sqrt{2^{n-h-(n-h)/2}}=2^{(n+h)/4}. |  | (64) |

It is important to notice that setting tB=1t\_{\\text{B}}=1 is a very strong assumption (it makes the 0-1-KP\\KP instance trivial), and we use it only to gain insights into the performance of NQS.
The benchmark results on real instances are presented in [Figure 11](https://arxiv.org/html/2310.06623v2#A1.F11 "Figure 11 ‣ A.6.1 Nested Quantum Search ‣ A.6 Benchmarking of competitive quantum methods ‣ Appendix A Supplementary Information ‣ A quantum algorithm for solving 0-1 Knapsack problems").

Figure 11: Comparison between the number of Grover iterations required by QTG-based search with and without bias, Grover’s algorithm, and NQS.
We observe that the number of Grover iterations is almost constant for the biased QTG-based search.
For the other methods, we have a linear increase with the problem size: for Grover’s search for problems of size 400 the algorithm already requires more than 105010^{50} oracle calls;
non-biased QTG-based search and NQS perform better, but still requiring more than 102010^{20} oracle calls.
Interestingly, the optimistic lower bound on the runtime of NQS seems to match the worst-case behaviour of the non-biased QTG-based search.

#### A.6.2 Quantum branch-and-bound

Quantum branch-and-bound (QBnB) \[ [27](https://arxiv.org/html/2310.06623v2#bib.bib27 ""), [38](https://arxiv.org/html/2310.06623v2#bib.bib38 "")\] is one of the most promising candidates for solving ILPs, having a provable worst-case asymptotic near-quadratic speedup over its classical counterpart.
The near-quadratic speedup is achieved by using quantum walks \[ [52](https://arxiv.org/html/2310.06623v2#bib.bib52 "")\] on the tree explored by the classical algorithm.
The method has two main ingredients:

1. 1.


Quantum tree size estimation \[ [53](https://arxiv.org/html/2310.06623v2#bib.bib53 "")\]
to get an upper bound on the size of the tree. This implementation shows how to get a quadratic improvement over a classical backtracking algorithm which evaluates TT nodes of a search tree.

2. 2.


Quantum tree search \[ [52](https://arxiv.org/html/2310.06623v2#bib.bib52 "")\] to return the label of the marked node if the tree contains at least one marked node, or “not found” if there is no marked node.


In general, the QBnB routine requires multiple applications of quantum tree size estimation and quantum tree search.
At the core of these subroutines lies quantum backtracking \[ [26](https://arxiv.org/html/2310.06623v2#bib.bib26 ""), [39](https://arxiv.org/html/2310.06623v2#bib.bib39 ""), [53](https://arxiv.org/html/2310.06623v2#bib.bib53 "")\].
In the following, we give an optimistic runtime estimation of the QBnB method.
We benchmark the QBnB for the 0-1-KP\\KP under the following assumptions:

1. 1.


The optimal solution and the respective tree size TT are known, hence quantum tree size estimation has to be applied only once.

2. 2.


The success probability of the quantum subroutines is 1.

3. 3.


The most expensive part of the algorithm is the backtracking, hence we consider all the other quantum subroutines to be queried once.


In general, in order to find the optimal solution, the expected number of oracles calls is at least T​n\\sqrt{Tn}, where TT represents the number of nodes that are actually explored by the corresponding classical BnB algorithm, and nn is the number of items.
To justify this value, we give a summary of the backtracking algorithm together with our reasoning.
Consider a rooted tree with TT vertices r,1,…,T−1r,1,\\ldots,T-1, where rr is the root.
AA denotes the set of vertices at an even distance from rr, and BB the set of vertices at an odd distance from rr. x→yx\\rightarrow y signifies that yy is a child of xx in the tree.
The quantum walk operates in the space spanned by {\|x⟩:x∈{r,1,…,T−1}}\\{\\ket{x}\\,:\\,x\\in\\{r,1,\\ldots,T-1\\}\\} and starts in the state \|r⟩\\ket{r}.
This quantum walk utilises a set of diffusion operators DxD\_{x}, where DxD\_{x} is the identity operator if xx is a solution; otherwise, it diffuses on the subspace spanned by {\|x⟩}∪{\|y⟩:x→y}\\{\\ket{x}\\}\\cup\\{\\ket{y}\\,:\\,x\\rightarrow y\\}.
A step of the quantum walk involves applying the operator RB​RAR\_{B}R\_{A}, where

|     |     |     |
| --- | --- | --- |
|  | RA=⨁x∈ADx​ and ​\|r⟩⟨r\|+RB=⨁x∈BDx.\\displaystyle R\_{A}=\\bigoplus\_{x\\raisebox{0.45206pt}{$\\scriptscriptstyle\\in$}A}D\_{x}\\text{ and }\\outerproduct{r}{r}+R\_{B}=\\bigoplus\_{x\\raisebox{0.45206pt}{$\\scriptscriptstyle\\in$}B}D\_{x}. |  |

Using these operators, a marked vertex is detected, because the phase estimation operator RB​RAR\_{B}R\_{A} enables the traversing of paths leading to a solution in the tree.
According to \[ [26](https://arxiv.org/html/2310.06623v2#bib.bib26 "")\] the operator RB​RAR\_{B}R\_{A} is applied to precision β/T​n\\beta/\\sqrt{Tn}.

For our benchmarking results, we assume that β=1\\beta=1, implying that the application of the phase estimation operator has to be applied exactly T​n\\sqrt{Tn} times.
We execute the classical algorithm and record the tree size TT.

Within the BnB routine, we use the commonly used upper bound heuristic _Fractional Greedy_\[ [35](https://arxiv.org/html/2310.06623v2#bib.bib35 "")\] which, similar to (Integer) Greedy, sorts all items by decreasing density and then greedily packs items into the knapsack until an item does not fit into the knapsack (by definition the successor of the break item hh).
It then returns the sum of all the profits of contained items plus the profit of the fraction of the item that could be included additionally, i.e.

|     |     |     |
| --- | --- | --- |
|  | ∑m=1hpm+ph+1​c−∑m=1hwmwh+1.\\displaystyle\\sum\_{m=1}^{h}p\_{m}+p\_{h+1}\\frac{c-\\sum\_{m=1}^{h}w\_{m}}{w\_{h+1}}. |  |

Because this routine is very similar to the (Integer) Greedy method, all the previous calculations for the cycle count of the QTG circuit can be used to calculate the costliness of the quantum implementation of Fractional Greedy.

Experimental support, please
[view the build logs](https://arxiv.org/html/2310.06623v2/__stdout.txt)
for errors. Generated by
[L\\
A\\
T\\
Exml![[LOGO]](<Base64-Image-Removed>)](https://math.nist.gov/~BMiller/LaTeXML/).


## Instructions for reporting errors

We are continuing to improve HTML versions of papers, and your feedback helps enhance accessibility and mobile
support. To report errors in the HTML that will help us improve conversion and rendering, choose any of the
methods listed below:

- Click the "Report Issue" () button, located in the page header.

**Tip:** You can select the relevant text first, to include it in your report.

Our team has already identified [the following issues](https://github.com/arXiv/html_feedback/issues). We appreciate your time reviewing and reporting rendering errors we
may not have found yet. Your efforts will help us improve the HTML versions for all readers, because disability
should not be a barrier to accessing research. Thank you for your continued support in championing open access for
all.

Have a free development cycle? Help support accessibility at arXiv! Our collaborators at LaTeXML maintain a [list of packages that need conversion](https://github.com/brucemiller/LaTeXML/wiki/Porting-LaTeX-packages-for-LaTeXML), and welcome [developer contributions](https://github.com/brucemiller/LaTeXML/issues).

We gratefully acknowledge support from
our **major funders**,
[**member institutions**](https://info.arxiv.org/about/ourmembers.html), ,
and all contributors.


[About](https://info.arxiv.org/about)· [Help](https://info.arxiv.org/help)· [Contact](https://info.arxiv.org/help/contact.html)· [Subscribe](https://info.arxiv.org/help/subscribe)· [Copyright](https://info.arxiv.org/help/license/index.html)· [Privacy](https://info.arxiv.org/help/policies/privacy_policy.html)· [Accessibility](https://info.arxiv.org/help/web_accessibility.html)· [Operational Status (opens in new tab)](https://status.arxiv.org/)

Major funding support from

[![Simons Foundation](https://arxiv.org/static/base/1.0.1/images/funders/simons-foundation.png)](https://www.simonsfoundation.org/)[![Simons Foundation International](https://arxiv.org/static/base/1.0.1/images/funders/simons-foundation-international.png)](https://www.sfi.org.bm/)[![Schmidt Sciences](https://arxiv.org/static/base/1.0.1/images/funders/schmidt-sciences.png)](https://www.schmidtsciences.org/)