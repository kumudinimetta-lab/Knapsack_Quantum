[Skip to main content](https://arxiv.org/html/quant-ph/0410184v1#infobox)

##### Report GitHub Issue

×

Title:

Content selection saved. Describe the issue below:

Description:

Submit without GitHubSubmit in GitHub

![](https://static.arxiv.org/static/design-system/latest/logos/smileybones.svg)Scheduled maintenance: Wednesday, October 28, 7:00 to 12:00 EDT (11:00 to 16:00 UTC).[Read more on our blog](https://blog.arxiv.org/2026/10/21/scheduled-database-maintenance)Dismiss announcement

[![archive](https://static.arxiv.org/static/design-system/latest/logos/arxiv-logo.svg)](https://arxiv.org/)

[Why HTML?](https://info.arxiv.org/about/accessible_HTML.html)Report Issue[Back to Abstract](https://arxiv.org/abs/quant-ph/0410184v1 "Back to abstract page") [Download PDF](https://arxiv.org/pdf/quant-ph/0410184v1 "Download PDF")ContentsReading modeColour theme

1. [Abstract](https://arxiv.org/html/quant-ph/0410184v1#abstract1 "In A new quantum ripple-carry addition circuit")
2. [1 Introduction](https://arxiv.org/html/quant-ph/0410184v1#S1 "In A new quantum ripple-carry addition circuit")
3. [2 The basic idea](https://arxiv.org/html/quant-ph/0410184v1#S2 "In A new quantum ripple-carry addition circuit")
4. [3 Improving the circuit](https://arxiv.org/html/quant-ph/0410184v1#S3 "In A new quantum ripple-carry addition circuit")
5. [4 Extensions](https://arxiv.org/html/quant-ph/0410184v1#S4 "In A new quantum ripple-carry addition circuit")
   1. [4.1 Addition Modulo 2n2^{n}](https://arxiv.org/html/quant-ph/0410184v1#S4.SS1 "In 4 Extensions ‣ A new quantum ripple-carry addition circuit")
   2. [4.2 Addition with Incoming Carry](https://arxiv.org/html/quant-ph/0410184v1#S4.SS2 "In 4 Extensions ‣ A new quantum ripple-carry addition circuit")
   3. [4.3 High Bit Only](https://arxiv.org/html/quant-ph/0410184v1#S4.SS3 "In 4 Extensions ‣ A new quantum ripple-carry addition circuit")
6. [5 Conclusions](https://arxiv.org/html/quant-ph/0410184v1#S5 "In A new quantum ripple-carry addition circuit")
7. [References](https://arxiv.org/html/quant-ph/0410184v1#bib "In A new quantum ripple-carry addition circuit")

[License: Assumed arXiv.org perpetual non-exclusive license](https://info.arxiv.org/help/license/index.html#licenses-available)

arXiv:quant-ph/0410184v1 \[quant-ph\] 22 Oct 2004

# A new quantum ripple-carry addition circuit

Steven A. Cuccaro
††thanks: Center for Computing Sciences, 17100 Science Drive, Bowie, MD 20715. cuccaro@super.orgThomas G. Draper
††thanks: Department of Mathematics, University of Maryland, College Park, MD 20742. tgd@math.umd.eduSamuel A. Kutin
††thanks: Center for Communications Research, 805 Bunn Drive,
Princeton, NJ 08540. kutin@idaccr.orgDavid Petrie Moulton
††thanks: Center for Communications Research, 805 Bunn Drive,
Princeton, NJ 08540. moulton@idaccr.org

###### Abstract

We present a new linear-depth ripple-carry quantum addition circuit.
Previous addition circuits required linearly many ancillary qubits;
our new adder uses only a single ancillary qubit. Also, our circuit has
lower depth and fewer gates than previous ripple-carry adders.

## 1 Introduction

We present a new quantum circuit for addition. The circuit is
based on the ripple-carry approach, in which we start with the
low-order bits of the input and work our way up to the high-order
bits. Since our computation must be reversible, we then work our way
from the high-order bits back down to the low-order bits.

A ripple-carry adder has previously been proposed by Vedral,
Barenco, and Ekert \[ [4](https://arxiv.org/html/quant-ph/0410184v1#bib.bib4 "")\]. Their circuit takes two nn-bit
numbers as input, computes the sum in place, and outputs a single
bit (the high bit of the sum). They also require n−O⁡(1)n-O(1)
scratch qubits, or ancillae.

Our circuit is different in that it requires only one ancilla.
Also, the depth and size of the circuit are smaller. The VBE adder is
made up of 4​n+O⁡(1)4n+O(1)CNOT (controlled-NOT) gates and 4​n+O⁡(1)4n+O(1)
Toffoli (doubly-controlled-NOT) gates,
with little parallelism. Our circuit uses 2​n+O⁡(1)2n+O(1) Toffoli
gates, 5​n+O⁡(1)5n+O(1)CNOT gates, and 2​n+O⁡(1)2n+O(1) negations; the
depth is 2​n+O⁡(1)2n+O(1).

The key ingredient of the new adder is a circuit computing the
majority of three bits in place. We present this circuit, and a
simple version of the adder, in Section [2](https://arxiv.org/html/quant-ph/0410184v1#S2 "2 The basic idea ‣ A new quantum ripple-carry addition circuit"). We then
give an optimized version in Section [3](https://arxiv.org/html/quant-ph/0410184v1#S3 "3 Improving the circuit ‣ A new quantum ripple-carry addition circuit").
See Figure [5](https://arxiv.org/html/quant-ph/0410184v1#S3.F5 "Figure 5 ‣ 3 Improving the circuit ‣ A new quantum ripple-carry addition circuit") for a pseudocode version of
the adder, and Figure [6](https://arxiv.org/html/quant-ph/0410184v1#S3.F6 "Figure 6 ‣ 3 Improving the circuit ‣ A new quantum ripple-carry addition circuit") for a pictorial version.

In Section [4](https://arxiv.org/html/quant-ph/0410184v1#S4 "4 Extensions ‣ A new quantum ripple-carry addition circuit"), we discuss several variants of the
adder: performing addition modulo 2n2^{n}, using an incoming carry bit,
and computing only the high bit of the sum. This last variant can
be modified to produce a comparator. The complexities of these
variants are summarized in Table [1](https://arxiv.org/html/quant-ph/0410184v1#S4.T1 "Table 1 ‣ 4 Extensions ‣ A new quantum ripple-carry addition circuit") on
Page [1](https://arxiv.org/html/quant-ph/0410184v1#S4.T1 "Table 1 ‣ 4 Extensions ‣ A new quantum ripple-carry addition circuit").

## 2 The basic idea

Our goal is to compute the sum of two nn-bit numbers aa and bb.
Write a=an−1⋯a0a=a\_{n-1}\\cdots a\_{0}, with a0a\_{0} the lowest-order
bit, and similarly write b=bn−1⋯b0b=b\_{n-1}\\cdots b\_{0}. We use
AiA\_{i} and BiB\_{i} to denote the memory locations where aia\_{i} and bib\_{i}
are initially stored.

We will add aa and bb in place; at the end, BiB\_{i} will contain
sis\_{i}, the iith bit of the sum. There is one additional output
location, ZZ, for the high bit sns\_{n}.

We define the carry string for aa and bb recursively: Let
c0=0c\_{0}=0, and let ci+1=MAJ(ai,bi,ci)c\_{i+1}=\\mathop{\\rm MAJ}\\nolimits(a\_{i},b\_{i},c\_{i}) for i≥0i\\geq 0.
Note that MAJ(ai,bi,ci)=ai​bi⊕ai​ci⊕bi​ci\\mathop{\\rm MAJ}\\nolimits(a\_{i},b\_{i},c\_{i})=a\_{i}b\_{i}\\mathbin{\\oplus}a\_{i}c\_{i}\\mathbin{\\oplus}b\_{i}c\_{i}.
We then have si=ai⊕bi⊕cis\_{i}=a\_{i}\\mathbin{\\oplus}b\_{i}\\mathbin{\\oplus}c\_{i} for all i<ni<n, and sn=cns\_{n}=c\_{n}.
In a classical ripple-carry adder, we compute each cic\_{i} in order,
working our way from c1c\_{1} up to cnc\_{n}. In a reversible ripple-carry
adder, we must then erase the carry bits, working our way back down.

The first component of our adder, depicted in Figure [1](https://arxiv.org/html/quant-ph/0410184v1#S2.F1 "Figure 1 ‣ 2 The basic idea ‣ A new quantum ripple-carry addition circuit"),
is a gate that computes the majority of three bits in place. We build
our circuits out of negations, CNOTs, and Toffoli
gates; time flows from left to right in our circuit diagrams. For the
in-place majority, we apply first two CNOTs and then one Toffoli.

|  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | =\\hskip 9.24994pt\\hskip 9.24994pt{=}\\hskip 9.24994pt\\hskip 9.24994pt |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |

Figure 1: The in-place majority gate MAJ{\\mathop{\\rm MAJ}\\nolimits}

The second component, depicted in Figure [2](https://arxiv.org/html/quant-ph/0410184v1#S2.F2 "Figure 2 ‣ 2 The basic idea ‣ A new quantum ripple-carry addition circuit"), is an
“UnMajority and Add”, or UMA\\mathop{\\rm UMA}\\nolimits, gate. We give two versions, each
of which computes the same function on the qubits. The first is
conceptually simpler, but the second admits greater parallelism.

|  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | =\\hskip 9.24994pt{=}\\hskip 9.24994pt |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |

(a)2-CNOT version

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | =\\hskip 9.24994pt{=}\\hskip 9.24994pt |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

(b)3-CNOT version

Figure 2: Two implementations of the UMA{\\mathop{\\rm UMA}\\nolimits} gate

The effect of using these two gates together is shown in
Figure [3](https://arxiv.org/html/quant-ph/0410184v1#S2.F3 "Figure 3 ‣ 2 The basic idea ‣ A new quantum ripple-carry addition circuit"). Suppose that we have just computed the
carry bit cic\_{i}. We apply the MAJ{\\mathop{\\rm MAJ}\\nolimits} gate, which writes
ci+1c\_{i+1} into AiA\_{i}. We then continue our computation.
After we are done using ci+1c\_{i+1}, we apply the UMA{\\mathop{\\rm UMA}\\nolimits} gate,
which restores aia\_{i} to AiA\_{i} and cic\_{i} to Ai−1A\_{i-1} and
writes sis\_{i} to BiB\_{i}.

|     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| cic\_{i} |  |  |  | ci⊕ai\\;c\_{i}\\mathbin{\\oplus}{a\_{i}}\\; |  |  |  | cic\_{i} |
| bib\_{i} |  |  |  | bi⊕aib\_{i}\\mathbin{\\oplus}{a\_{i}} |  |  |  | sis\_{i} |
| aia\_{i} |  |  |  | ci+1c\_{i+1} |  |  |  | aia\_{i} |

Figure 3: Combining the MAJ{\\mathop{\\rm MAJ}\\nolimits} and UMA{\\mathop{\\rm UMA}\\nolimits} gates

It follows that we can string together MAJ{\\mathop{\\rm MAJ}\\nolimits} and UMA{\\mathop{\\rm UMA}\\nolimits} gates
to build a ripple-carry adder. Such an adder is depicted in
Figure [4](https://arxiv.org/html/quant-ph/0410184v1#S2.F4 "Figure 4 ‣ 2 The basic idea ‣ A new quantum ripple-carry addition circuit"). We have one ancilla, labeled XX,
initialized to 00. We view XX as containing the initial carry bit c0c\_{0}.
The output bit ZZ contains some value zz when the circuit begins and
z⊕snz\\mathbin{\\oplus}s\_{n} when the circuit concludes.

|     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0=c00=c\_{0} |  |  |  |  |  |  |  |  |  |  |  |  |  | c0⊕a0c\_{0}\\mathbin{\\oplus}{a\_{0}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 00 |
| b0b\_{0} |  |  |  |  |  |  |  |  |  |  |  |  |  | b0⊕a0b\_{0}\\mathbin{\\oplus}{a\_{0}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s0s\_{0} |
| a0a\_{0} |  |  |  |  |  |  |  |  |  |  |  |  |  | c1⊕a1c\_{1}\\mathbin{\\oplus}{a\_{1}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a0a\_{0} |
| b1b\_{1} |  |  |  |  |  |  |  |  |  |  |  |  |  | b1⊕a1b\_{1}\\mathbin{\\oplus}{a\_{1}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s1s\_{1} |
| a1a\_{1} |  |  |  |  |  |  |  |  |  |  |  |  |  | c2⊕a2c\_{2}\\mathbin{\\oplus}{a\_{2}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a1a\_{1} |
| b2b\_{2} |  |  |  |  |  |  |  |  |  |  |  |  |  | b2⊕a2b\_{2}\\mathbin{\\oplus}{a\_{2}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s2s\_{2} |
| a2a\_{2} |  |  |  |  |  |  |  |  |  |  |  |  |  | c3⊕a3c\_{3}\\mathbin{\\oplus}{a\_{3}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a2a\_{2} |
| b3b\_{3} |  |  |  |  |  |  |  |  |  |  |  |  |  | b3⊕a3b\_{3}\\mathbin{\\oplus}{a\_{3}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s3s\_{3} |
| a3a\_{3} |  |  |  |  |  |  |  |  |  |  |  |  |  | c4⊕a4c\_{4}\\mathbin{\\oplus}{a\_{4}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a3a\_{3} |
| b4b\_{4} |  |  |  |  |  |  |  |  |  |  |  |  |  | b4⊕a4b\_{4}\\mathbin{\\oplus}{a\_{4}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s4s\_{4} |
| a4a\_{4} |  |  |  |  |  |  |  |  |  |  |  |  |  | c5⊕a5c\_{5}\\mathbin{\\oplus}{a\_{5}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a4a\_{4} |
| b5b\_{5} |  |  |  |  |  |  |  |  |  |  |  |  |  | b5⊕a5b\_{5}\\mathbin{\\oplus}{a\_{5}} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s5s\_{5} |
| a5a\_{5} |  |  |  |  |  |  |  |  |  |  |  |  |  | c6c\_{6} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a5a\_{5} |
| zz |  |  |  |  |  |  |  |  |  |  |  |  |  | zz |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | z⊕s6z\\mathbin{\\oplus}{s\_{6}} |

Figure 4: A simple ripple-carry adder for n=6n=6.

## 3 Improving the circuit

We can reduce the depth of the basic circuit of Figure [4](https://arxiv.org/html/quant-ph/0410184v1#S2.F4 "Figure 4 ‣ 2 The basic idea ‣ A new quantum ripple-carry addition circuit")
in several ways. It is necessary to use the 3-CNOT version of the
UMA{\\mathop{\\rm UMA}\\nolimits} gate from Figure [2(b)](https://arxiv.org/html/quant-ph/0410184v1#S2.F2.sf2 "In Figure 2 ‣ 2 The basic idea ‣ A new quantum ripple-carry addition circuit").

input:Ai=aiA\_{i}=a\_{i}Bi=biB\_{i}=b\_{i}Z=zZ=zX=0X=0output:Ai=aiA\_{i}=a\_{i}Bi=siB\_{i}=s\_{i}Z=z⊕snZ=z\\mathbin{\\oplus}s\_{n}X=0X=0circuit:fori=1i=1ton−1n-1:  Bi⊕⁣=AiB\_{i}\\mathbin{\\oplus\\!\\!=}A\_{i}X⊕⁣=A1X\\mathbin{\\oplus\\!\\!=}A\_{1}X⊕⁣=A0​B0X\\mathbin{\\oplus\\!\\!=}A\_{0}B\_{0}  ; A1⊕⁣=A2A\_{1}\\mathbin{\\oplus\\!\\!=}A\_{2}A1⊕⁣=X​B1A\_{1}\\mathbin{\\oplus\\!\\!=}XB\_{1}  ; A2⊕⁣=A3A\_{2}\\mathbin{\\oplus\\!\\!=}A\_{3}fori=2i=2ton−3n-3:Ai⊕⁣=Ai−1​BiA\_{i}\\mathbin{\\oplus\\!\\!=}A\_{i-1}B\_{i}  ; Ai+1⊕⁣=Ai+2A\_{i+1}\\mathbin{\\oplus\\!\\!=}A\_{i+2}An−2⊕⁣=An−3​Bn−2A\_{n-2}\\mathbin{\\oplus\\!\\!=}A\_{n-3}B\_{n-2}  ; Z⊕⁣=An−1Z\\mathbin{\\oplus\\!\\!=}A\_{n-1}Z⊕⁣=An−2​Bn−1Z\\mathbin{\\oplus\\!\\!=}A\_{n-2}B\_{n-1}  ; fori=1i=1ton−2n-2:  Negate BiB\_{i}B1⊕⁣=XB\_{1}\\mathbin{\\oplus\\!\\!=}X  ; fori=2i=2ton−1n-1: Bi⊕⁣=Ai−1B\_{i}\\mathbin{\\oplus\\!\\!=}A\_{i-1}An−2⊕⁣=An−3​Bn−2A\_{n-2}\\mathbin{\\oplus\\!\\!=}A\_{n-3}B\_{n-2}fori=n−3i=n-3down to22:Ai⊕⁣=Ai−1​BiA\_{i}\\mathbin{\\oplus\\!\\!=}A\_{i-1}B\_{i}  ; Ai+1⊕⁣=Ai+2A\_{i+1}\\mathbin{\\oplus\\!\\!=}A\_{i+2}
; Negate Bi+1B\_{i+1}A1⊕⁣=X​B1A\_{1}\\mathbin{\\oplus\\!\\!=}XB\_{1}  ; A2⊕⁣=A3A\_{2}\\mathbin{\\oplus\\!\\!=}A\_{3}  ; Negate B2B\_{2}X⊕⁣=A0​B0X\\mathbin{\\oplus\\!\\!=}A\_{0}B\_{0}  ; A1⊕⁣=A2A\_{1}\\mathbin{\\oplus\\!\\!=}A\_{2}  ; Negate B1B\_{1}X⊕⁣=A1X\\mathbin{\\oplus\\!\\!=}A\_{1}fori=0i=0ton−1n-1:  Bi⊕⁣=AiB\_{i}\\mathbin{\\oplus\\!\\!=}A\_{i}

Figure 5: The ripple-carry adder for n≥4n\\geq 4. Each line of pseudocode
corresponds to a single time-slice.

|     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| b0b\_{0} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s0s\_{0} |
| a0a\_{0} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a0a\_{0} |
| 00 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 00 |
| b1b\_{1} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s1s\_{1} |
| a1a\_{1} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a1a\_{1} |
| b2b\_{2} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s2s\_{2} |
| a2a\_{2} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a2a\_{2} |
| b3b\_{3} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s3s\_{3} |
| a3a\_{3} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a3a\_{3} |
| b4b\_{4} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s4s\_{4} |
| a4a\_{4} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a4a\_{4} |
| b5b\_{5} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s5s\_{5} |
| a5a\_{5} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a5a\_{5} |
| zz |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | z⊕s6z\\mathbin{\\oplus}{s\_{6}} |

Figure 6: The ripple-carry adder for n=6n=6.

1. 1.


The first CNOTs of all the MAJ{\\mathop{\\rm MAJ}\\nolimits} gates can be performed
in a single time-slice at the beginning. Similarly, the final
CNOTs of all the UMA{\\mathop{\\rm UMA}\\nolimits} gates can be performed in a single
time-slice at the end.

2. 2.


Consider the first half of the circuit: the MAJ{\\mathop{\\rm MAJ}\\nolimits} ripple.
The Toffoli at the end of the iith MAJ{\\mathop{\\rm MAJ}\\nolimits} gate
commutes with the second CNOT of the (i+1)(i+1)th gate. If we swap these
two gates for each ii, then the depth decreases: the Toffoli of
the iith MAJ{\\mathop{\\rm MAJ}\\nolimits} gate can now be done in parallel
with the second CNOT of the (i+2)(i+2)th MAJ{\\mathop{\\rm MAJ}\\nolimits} gate.

3. 3.


We can perform a similar transformation
on the second half of the circuit.
We swap the Toffoli of the (i+1)(i+1)th UMA{\\mathop{\\rm UMA}\\nolimits} gate with the second
CNOT of the iith UMA{\\mathop{\\rm UMA}\\nolimits} gate. Again, the depth decreases: the second CNOT of the iith UMA{\\mathop{\\rm UMA}\\nolimits} gate can be done in parallel
with the Toffoli of the (i+2)(i+2)th UMA{\\mathop{\\rm UMA}\\nolimits} gate.

4. 4.


We know c0=0c\_{0}=0, so we do not need a MAJ\\mathop{\\rm MAJ}\\nolimits gate to compute
c1=a0​b0c\_{1}=a\_{0}b\_{0}. Instead, we compute c1c\_{1} with a single Toffoli and
store it in our ancilla. At the end of the circuit, we undo this
same Toffoli, and then set B0B\_{0} to s0s\_{0} with a single CNOT.

5. 5.


It is inefficient to write cnc\_{n} into An−1A\_{n-1}, copy it to the
output, and then erase it. We
can instead write directly to the output. We replace the central
piece (two Toffolis, two CNOTs, and two negations) with one
Toffoli and two CNOTs. One of the CNOTs can be done in parallel
with other computation.


Our final ripple-carry circuit is described in
Figure [5](https://arxiv.org/html/quant-ph/0410184v1#S3.F5 "Figure 5 ‣ 3 Improving the circuit ‣ A new quantum ripple-carry addition circuit"). The construction applies for any nn,
but the pseudocode in Figure [5](https://arxiv.org/html/quant-ph/0410184v1#S3.F5 "Figure 5 ‣ 3 Improving the circuit ‣ A new quantum ripple-carry addition circuit") is valid only for
n≥4n\\geq 4. A sample circuit for n=6n=6 is depicted in
Figure [6](https://arxiv.org/html/quant-ph/0410184v1#S3.F6 "Figure 6 ‣ 3 Improving the circuit ‣ A new quantum ripple-carry addition circuit"). Note that, in Figure [4](https://arxiv.org/html/quant-ph/0410184v1#S2.F4 "Figure 4 ‣ 2 The basic idea ‣ A new quantum ripple-carry addition circuit"),
the ancilla contains c0c\_{0} and is the topmost wire; in
Figure [6](https://arxiv.org/html/quant-ph/0410184v1#S3.F6 "Figure 6 ‣ 3 Improving the circuit ‣ A new quantum ripple-carry addition circuit"), the ancilla contains c1c\_{1} and is the
third wire from the top.

Assuming n≥2n\\geq 2, the circuit size is 2​n−12n-1 Toffoli gates, 5​n−35n-3CNOTs, and 2​n−42n-4 negations. The depth is 2​n+42n+4: 2​n−12n-1 Toffoli
time-slices and 55CNOT time-slices.

## 4 Extensions

We now discuss various slightly-modified versions of the ripple-carry
adder:

- •


modulo 2n2^{n}: We do not compute the high bit.

- •


incoming carry: We consider the ancilla c0c\_{0} to be an
extra input bit.

- •


high bit only: We compute the high bit, but do not overwrite the
bb input. This circuit can be adapted to give a comparator.


|     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | Number of Bits | Size | Depth |
| Function | IC? | In | Out | Anc. | Toffoli | CNOT |  |
| ++ in ℤ\\mathbb{Z} | N | 2​n2n | 1 | 1 | 2​n−12n-1 | 5​n−35n-3 | 2​n+42n+4 |
| ++ in ℤ\\mathbb{Z} | Y | 2​n+12n+1 | 1 | 0 | 2​n−12n-1 | 5​n+15n+1 | 2​n+62n+6 |
| ++ (mod 2n2^{n}) | N | 2​n2n | 0 | 1 | 2​n−32n-3 | 5​n−75n-7 | 2​n+22n+2 |
| ++ (mod 2n2^{n}) | Y | 2​n+12n+1 | 0 | 0 | 2​n−32n-3 | 5​n−35n-3 | 2​n+42n+4 |
| Compare | N | 2​n2n | 1 | 1 | 2​n−12n-1 | 4​n−34n-3 | 2​n+32n+3 |
| Compare | Y | 2​n+12n+1 | 1 | 0 | 2​n−12n-1 | 4​n+14n+1 | 2​n+52n+5 |
| VBE adder \[ [4](https://arxiv.org/html/quant-ph/0410184v1#bib.bib4 "")\] | N | 2​n2n | 1 | nn | 4​n−24n-2 | 4​n−24n-2 | 6​n−26n-2 |

Table 1: Circuit summary, for n≥3n\\geq 3. The first column gives the function
being computed. The second lists whether we take an incoming carry bit
as input. We then list the number of input, output, and ancilla bits,
the number of Toffoli and CNOT gates, and the overall depth. We do
not include negations when counting size or depth.

In each case, the circuit is a simple modification of the circuit of
Section [3](https://arxiv.org/html/quant-ph/0410184v1#S3 "3 Improving the circuit ‣ A new quantum ripple-carry addition circuit"). The only question is the exact
depth and size of the circuit. The results are summarized in
Table [1](https://arxiv.org/html/quant-ph/0410184v1#S4.T1 "Table 1 ‣ 4 Extensions ‣ A new quantum ripple-carry addition circuit"). For each circuit, we give the number of
Toffoli gates, the number of CNOT gates, and the overall depth. In
each case, the number of Toffoli time-slices is equal to the number
of Toffoli gates; the remaining time-slices contain CNOTs.
For the VBE adder, the circuit has 3​n−13n-1 Toffoli time-slices and
3​n−13n-1CNOT time-slices.

### 4.1 Addition Modulo 2n2^{n}

Suppose that we wish to compute a+b⁡(mod ​2n)a+b\ (\\text{mod }2^{n}); that is, we do not
want to compute the high bit cnc\_{n}. One approach is the following:

1. 1.


Add the low-order n−1n-1 bits of
aa and bb, using the circuit of Section [3](https://arxiv.org/html/quant-ph/0410184v1#S3 "3 Improving the circuit ‣ A new quantum ripple-carry addition circuit").
Use Bn−1B\_{n-1} as the output bit.

2. 2.


Set Bn−1⊕⁣=An−1B\_{n-1}\\mathbin{\\oplus\\!\\!=}A\_{n-1}.


After step 1, we have correctly computed s0s\_{0} through sn−2s\_{n-2}, and
we have written bn−1⊕cn−1b\_{n-1}\\mathbin{\\oplus}c\_{n-1} into Bn−1B\_{n-1}. Then,
in step [2](https://arxiv.org/html/quant-ph/0410184v1#S4.I2.i2 "item 2 ‣ 4.1 Addition Modulo 2^𝑛 ‣ 4 Extensions ‣ A new quantum ripple-carry addition circuit"), we complete the calculation of sn−1s\_{n-1}.
Note that step [2](https://arxiv.org/html/quant-ph/0410184v1#S4.I2.i2 "item 2 ‣ 4.1 Addition Modulo 2^𝑛 ‣ 4 Extensions ‣ A new quantum ripple-carry addition circuit") occurs in parallel with the final
time-slice of step [1](https://arxiv.org/html/quant-ph/0410184v1#S4.I2.i1 "item 1 ‣ 4.1 Addition Modulo 2^𝑛 ‣ 4 Extensions ‣ A new quantum ripple-carry addition circuit").

For n≥3n\\geq 3, this circuit contains 2​n−32n-3 Toffolis,
5​n−75n-7CNOTs, and 2​n−62n-6 negations.
The depth is 2​n+22n+2: 2​n−32n-3 Toffoli
time-slices and 5 CNOT time-slices.

### 4.2 Addition with Incoming Carry

Suppose we want to allow an incoming carry into our addition circuit.
We have an additional input bit yy, and we compute a+b+ya+b+y.

We observe that the circuit of Section [2](https://arxiv.org/html/quant-ph/0410184v1#S2 "2 The basic idea ‣ A new quantum ripple-carry addition circuit") already
solves this problem; we use yy in place of the ancilla c0c\_{0}.
We then correctly compute c1c\_{1}, and the ripple continues.

We cannot use the fourth improvement from Section [3](https://arxiv.org/html/quant-ph/0410184v1#S3 "3 Improving the circuit ‣ A new quantum ripple-carry addition circuit"),
since we can no longer assume the incoming bit is zero. The
other improvements still apply.

We obtain a ripple-carry adder with incoming carry which consists of
2​n−12n-1 Toffolis, 5​n+15n+1CNOTs, and 2​n−22n-2 negations.
For n≥2n\\geq 2, the circuit has depth 2​n+62n+6: 2​n−12n-1 Toffoli time-slices and 7 CNOT
time-slices.

We can also apply the incoming-carry modification to the circuit
of Section [4.1](https://arxiv.org/html/quant-ph/0410184v1#S4.SS1 "4.1 Addition Modulo 2^𝑛 ‣ 4 Extensions ‣ A new quantum ripple-carry addition circuit"). For n≥3n\\geq 3, we get a circuit
with 2​n−32n-3 Toffolis, 5​n−35n-3CNOTs, and 2​n−42n-4 negations. The depth is 2​n+42n+4: 2​n−32n-3 Toffoli time-slices and 7 CNOT time-slices.

### 4.3 High Bit Only

We now consider the problem of computing only the high bit of the sum
a+ba+b. The first half of the circuit is identical to the first half
of our adder from Section [3](https://arxiv.org/html/quant-ph/0410184v1#S3 "3 Improving the circuit ‣ A new quantum ripple-carry addition circuit"): when we get to the
middle point, we have written the high bit to ZZ. Now, we simply
undo the first half of the circuit. We can view this as applying a
series of MAJ\\mathop{\\rm MAJ}\\nolimits gates, followed by a Toffoli and a series of
MAJ−1\\mathop{\\rm MAJ}\\nolimits^{-1} gates.

For n≥2n\\geq 2, the resulting circuit contains 2​n−12n-1 Toffoli gates
and 4​n−34n-3CNOTs. The depth is 2​n+32n+3: 2​n−12n-1 Toffoli time-slices and
44CNOT time-slices.

We can combine the high-bit circuit with the incoming-carry modification
discussed in Section [4.2](https://arxiv.org/html/quant-ph/0410184v1#S4.SS2 "4.2 Addition with Incoming Carry ‣ 4 Extensions ‣ A new quantum ripple-carry addition circuit"). We obtain a circuit
with 2​n−12n-1 Toffolis and 4​n+14n+1CNOTs. For n≥2n\\geq 2, the depth
is 2​n+52n+5: 2​n−12n-1 Toffoli time-slices and 66CNOT time-slices.

It is worth noting that our ripple-carry adder can easily be turned
into a subtractor. Whether we use one’s-complement or two’s-complement
arithmetic, we have the identity

|     |     |     |
| --- | --- | --- |
|  | a−b=(a′+b)′,a-b=(a^{\\prime}+b)^{\\prime}, |  |

where ′ denotes bitwise complementation. Hence, we can subtract by
adding two time-slices: complement aa at the start, and complement
aa and ss at the end.

If we combine this subtraction idea with the high-bit computer of
this section, we obtain a comparator: we compute the high bit of
a−ba-b, which is 1 if and only if a<ba<b.

## 5 Conclusions

One interesting open problem is to construct an optimal addition circuit.
In particular, if a reversible addition circuit uses just one ancilla,
must it have linear depth? A logarithmic-depth adder has been
constructed using 2​n2n ancillae \[ [3](https://arxiv.org/html/quant-ph/0410184v1#bib.bib3 "")\]; more generally, for
any k>0k>0, we can construct a family of circuits using n/kn/k ancillae
with depth O⁡(k+log⁡n)O(k+\\log n). Is there a
logarithmic-depth addition circuit family using only a constant number
of ancillae? If not, can we prove a lower bound on depth?

A version of our ripple-carry adder has been proposed that uses no
ancillae \[ [1](https://arxiv.org/html/quant-ph/0410184v1#bib.bib1 "")\]. That circuit requires that the output bit
be initialized to zero. We do not know whether we can add in linear
depth with no ancillae and without this restriction on the output bit.

It would be interesting to compare the ripple-carry adder of this
paper to the transform adder \[ [2](https://arxiv.org/html/quant-ph/0410184v1#bib.bib2 "")\]. Both circuits have
linear depth. It is unclear which adder would be easier to implement
in practice; the answer depends on the relative costs of Toffoli gates
and controlled rotations.

|     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| b0b\_{0} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s0s\_{0} |
| a0a\_{0} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a0a\_{0} |
| 00 |  | i |  | i |  |  |  | -i |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | i |  | i |  |  |  | -i |  | 00 |
| b1b\_{1} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s1s\_{1} |
| a1a\_{1} |  |  |  |  |  |  |  | i |  | i |  |  |  | -i |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | -i |  |  |  | i |  | i |  |  |  |  |  |  |  | a1a\_{1} |
| b2b\_{2} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s2s\_{2} |
| a2a\_{2} |  |  |  |  |  |  |  |  |  |  |  |  |  | i |  | i |  |  |  | -i |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | -i |  |  |  | i |  | i |  |  |  |  |  |  |  |  |  |  |  |  |  | a2a\_{2} |
| b3b\_{3} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s3s\_{3} |
| a3a\_{3} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | i |  | i |  |  |  | -i |  |  |  |  |  | -i |  |  |  | i |  | i |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a3a\_{3} |
| b4b\_{4} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | s4s\_{4} |
| a4a\_{4} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | a4a\_{4} |
| zz |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | i |  | i |  |  |  | -i |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | z⊕s5z\\mathbin{\\oplus}{s\_{5}} |

Figure 7: 5-bit ripple carry adder written in terms of controlled
rotations. The depth is 28. Here a circled ii denotes a “square
root of NOT”; i.e., a rotation by π/2\\pi/2. A circled −i-i denotes
the inverse operation.

It is well-known that a Toffoli gate can be built from five
controlled rotations. One might thus expect the controlled-unary
depth of our ripple-carry adder to be 10​n+O⁡(1)10n+O(1). In fact, the
Toffolis can be overlapped; the depth is only 6​n−26n-2. An example with
n=5n=5 is depicted in Figure [7](https://arxiv.org/html/quant-ph/0410184v1#S5.F7 "Figure 7 ‣ 5 Conclusions ‣ A new quantum ripple-carry addition circuit").

We can also consider the cost of adding a classical quantity
to a quantum quantity. We have some nn-bit number in our quantum memory,
and we wish to add a fixed nn-bit number (known at compile time). Our
ripple-carry adder does not become any simpler in this setting; we still
need to use nn quantum bits to store the classical addend. On the other
hand, the transform adder benefits greatly: the classical information
need not be stored in quantum memory, and the controlled rotations are
replaced with fixed and known rotations. In this setting, the transform
adder seems superior.

## References

- \[1\]
Richard J. Dore and Samuel A. Kutin, _A logarithmic-depth quantum_
_comparison circuit with one ancilla_, in preparation.

- \[2\]
Thomas G. Draper, _Addition on a quantum computer_, quant-ph/0008033.

- \[3\]
Thomas G. Draper, Samuel A. Kutin, Eric M. Rains, and Krysta M. Svore, _A_
_logarithmic-depth quantum carry-lookahead adder_, EQIS, 2004,
quant-ph/0406142.

- \[4\]
Vlatko Vedral, Adriano Barenco, and Artur Ekert, _Quantum networks for_
_elementary arithmetic operations_, quant-ph/9511018.


Experimental support, please
[view the build logs](https://arxiv.org/html/quant-ph/quant-ph/0410184v1/__stdout.txt)
for errors. Generated by
[L\\
A\\
T\\
Exml![[LOGO]](<Base64-Image-Removed>)](https://math.nist.gov/~BMiller/LaTeXML/).


## Instructions for reporting errors

We are continuing to improve HTML versions of papers, and your feedback helps enhance accessibility and mobile
support. To report errors in the HTML that will help us improve conversion and rendering, choose any of the
methods listed below:

- Click the "Report Issue" () button, located in the page header.

**Tip:** You can select the relevant text first, to include it in your report.

Our team has already identified [the following issues](https://github.com/arXiv/html_feedback/issues). We appreciate your time reviewing and reporting rendering errors we
may not have found yet. Your efforts will help us improve the HTML versions for all readers, because disability
should not be a barrier to accessing research. Thank you for your continued support in championing open access for
all.

Have a free development cycle? Help support accessibility at arXiv! Our collaborators at LaTeXML maintain a [list of packages that need conversion](https://github.com/brucemiller/LaTeXML/wiki/Porting-LaTeX-packages-for-LaTeXML), and welcome [developer contributions](https://github.com/brucemiller/LaTeXML/issues).

We gratefully acknowledge support from our [**major funders**](https://info.arxiv.org/about/major_funders.html),
[**member institutions**](https://info.arxiv.org/about/ourmembers.html), ,
and all contributors.


[About](https://info.arxiv.org/about)· [Help](https://info.arxiv.org/help)· [Contact](https://info.arxiv.org/help/contact.html)· [Subscribe](https://info.arxiv.org/help/subscribe.html)· [Copyright](https://info.arxiv.org/help/license/index.html)· [Privacy](https://info.arxiv.org/help/policies/privacy_policy.html)· [Accessibility](https://info.arxiv.org/help/web_accessibility.html)· [Operational Status (opens in new tab)](https://status.arxiv.org/)