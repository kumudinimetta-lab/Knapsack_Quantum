**ORIGINAL RESEARCH**

# Optimal solving of a binary knapsack problem on a D-Wave quantum machine and its implementation in production systems

**Wojciech Bȯzejko<sup>1</sup> · Anna Burduk<sup>2</sup> · Jarosław Pempera<sup>1</sup> ·**
**Mariusz Uchro ´nski<sup>3</sup> · Mieczysław Wodecki<sup>4</sup>**

## Mariusz Uchro ´nski 3 · Mieczysław Wodecki 4

Received: 4 October 2023 / Accepted: 16 April 2024

© The Author(s) 2024

### Abstract

The efficient management of complex production systems is a challenge in today’s logistics.
In the field of intelligent and sustainable logistics, the optimization of production batches,
especially in the context of a rapidly changing product range, requires fast and precise computational solutions. This paper explores the potential of quantum computers for solving
these problems. Traditional computational methods are often limited when it comes to optimizing complex logistics systems. In response to these challenges, the paper proposes the
use of a hybrid algorithm that combines quantum technologies with classical computational
methods. Such integration allows the computational power of both types of technologies
to be harnessed, leading to faster and more efficient identification of optimal solutions. In
this work, we consider the knapsack problem, a classic NP-hard optimization problem that
is commonly used to verify the effectiveness of new algorithm construction methods. The
algorithm presented is based on the Branch and Bound method and aims to ensure solution optimality in the context of the non-determinism of quantum computers. Within the
algorithm, computations are performed alternately on a classical processor and a quantum

B Wojciech Bȯzejko
wojciech.bozejko@pwr.edu.pl

Anna Burduk
anna.burduk@pwr.edu.pl

Jarosław Pempera
jaroslaw.pempera@pwr.edu.pl

Mariusz Uchrónski
mariusz.uchronski@pwr.edu.pl

Mieczysław Wodecki
mieczyslaw.wodecki@pwr.edu.pl

1 Department of Control Systems and Mechatronics Wrocław, University of Science and Technology,
Janiszewskiego 11/17, 50-372 Wrocław, Poland

2 Faculty of Mechanical Engineering, Wrocław University of Science and Technology, Ignacego
Łukasiewicza 5, 50-371 Wrocław, Poland

3 Wroclaw Centre for Networking and Supercomputing, Wybrzėze Wyspiánskiego 27, 50-370
Wrocław, Poland

4 Department of Telecommunications and Teleinformatics, Wrocław University of Science and
Technology, Wybrzėze Wyspiánskiego 27, 50-370 Wrocław, Poland processor. In addition, the lower and upper bounds of the objective function are computed in
constant time using the D-Wave quantum machine.

**Keywords** Discrete optimization · Knapsack problem · Quantum annealing

## 1 Introduction

Packing problems are very important in the practice of managing production processes, their
automation and logistics. They enable the modeling of practical issues related to transport,
managing warehouse space, loading goods, designing systems with a high scale of integration
or managing computer networks and databases. The construction of effective methods for
determining solutions allows for the reduction of transport and storage costs.

In the paper, we consider the binary knapsack problem (PP), i.e., the one-dimensional
packing problem. In this problem, the data is a collection of things (elements) each of which
has a fixed weight and value. You need to designate a subset of items with a maximum
sum of values whose total weight does not exceed the capacity of the knapsackk. In the
literature, there are many such issues related to many additional assumptions and constraints.
In particular, one- and multi-criteria problems of two- and three-dimensional packaging of
elements, including irregularly shaped ones.

In this paper, we present an optimal hybrid algorithm for solving the knapsack problem,
the design of which is based on the Branch and Bound method (B&B). Although the quantum
annealing algorithm does not guarantee the optimality of the determined solution (see Pusey-
Nazzaro & Date, 2020 for the knapsack problem), it can be used in the construction of an
exact algorithm, as it improves its efficiency through non-deterministic control of the solution
space search process. We propose a new approach, consisting in determining the upper and
lower bounds of the objective function on the quantum annealer. For the determination of the
upper bound, we formulate the problem of binary quadratic programming with constraints,
translated natively onto QUBO, which is a natural way of formulating computational tasks
for the D-Wave machine. In contrast, for the determination of the lower bound, we apply the
Lagrange relaxation.

### 1.1 State of the art

The Knapsack problem, despite the simplicity of the formulation (linear objective function
and one linear constraint), belongs to the class of the most difficult, NP-hard, discrete optimization problems. Already, for 60 items, the number of solutions is 2<sup>60</sup> solutions. If we
checked a billion solutions in 1 s, it would take over 30 years to check all combinations. This
problem is important both from the point of view of practice and theory. Biglar (2018) lists
over 20 practical issues directly related to the packaging problem considered in this work,
including production planning, power allocation management, resource management as well
as power allocation planning. Many interesting practical examples of the Knapsack Problemm applications and methods of solving them are also presented in the works of Laabadi
et al. (2018), Wilbaut et al. (2008), and Cho (2019). The methods and constructions of algorithms presented in this paper can be adapted to model and solve more complex industrial
and logistic processes.

Methods for solving the Knapsack Problem have a long and rich history. The first optimal
algorithms based on dynamic programming and division and constraints were published at the turn of the 1950 s and 1960 s. They allowed solving examples of up to a dozen items.
Too small from the point of view of practical applications. Despite the passage of many
years, exact methods, including pseudo-polynomial algorithms, i.e. polynomial with respect
to the knapsack payload, are successively developed and published. An overview of the
methods and algorithms are presented, among others, in the following works: Coniglio et al.
(2021), Zavala-Diaz et al. (2019); Rizk-Allah and Hassanien (2018) and Shen et al. (2019).
Many construction algorithms have also been published, mainly based on the greedy method.
They are easy to implement, work quickly, but usually, the designated solutions are far from
optimal. They are used primarily to determine starting solutions in optimal algorithms.

A significant breakthrough occurred in the 1990 s. In response to the expectations of practitioners, there has been an intensive development of approximate methods, including the
now classic metaheuristics: Tabu Search, Simulate Annealing, and evolutionary algorithms
such as genetic algorithm, particle swarm optimization, differential evolution, ant ant colony
optimization. The work by Zhang (2011) presents an algorithm using artificial intelligence;
Refaei et al. (2020) proposes neural networks and machine learning. Approximation algorithms and extensive analyses of the performed computational experiments are included in
the works: He et al. (2024), Refaei et al. (2020), and Zhang (2011). An overview of packaging problems and methods of solving them is presented in the monograph of Kellerer et al.
(2004). An extensive review of the current literature is provided in Cacchiani et al. (2022),
Wang et al. (2022), and Barakat et al. (2016).

The possibility of multi-processor computing has resulted in a significant shift in the size
of instances that can be solved exactly in an acceptable time. In addition to the exact and
approximation algorithms that have been known for years (Zavala-Diaz et al., 2019; Vu&
Derbel, 2016; Vasilchikov, 2018), parallel versions of algorithms inspired by nature have also
been published (He et al., 2024), as well as: neural networks, artificial intelligence (Zhang,
2011; Ji et al.,2017) and learning techniques (Refaei et al., 2020).

Great hopes are attached to the possibility of performing calculations on quantum computers. Currently, they have little practical application in solving (exactly) discrete optimization
problems. The main limitation is the small number of qubits. In recent years, they have
been developing intensively. It can be expected that in the coming years practical examples
of very large size will be solved within a reasonable time. Among quantum approaches,
Pusey-Nazzaro and Date (2020) claims that adiabatic quantum optimization is unable to
provide the optimal solution to a variety of small knapsack problems. In the work of Li
et al. (2023), the authors use a new approach to solving the Knapsack Problem by using
quantum-behaved particle swarm optimization. Approximation algorithms are presented in
Dam et al. (2021). Bȯzejko et al. (2022) proposed a distributed quantum annealing algorithm
for a single-machine scheduling problem with total weighted tardiness criterion. In terms
of optimal solving of optimization problems (Bȯzejko et al., 2024, 2023) proposed exact
algorithms for solving single-machine scheduling problems on a quantum machine in the
CPU-QPU hybrid approach. In the work of Yarkoni et al. (2022) is presented a review of the
literature on the use of a quantum annealer, which can be used in combinatorial optimization.

The effective use of modern quantum computing technologies, including D-Wave quantum machines, is associated with a number of specific limitations. It requires, among others,
formulating the problem to be solved in the form of a binary quadratic programming task
(Quadratic, Unconstrained Binary Optimization, QUBO). This is often very difficult, especially when the objective function is minimax.

Calculations on D-Wave quantum computers for a wider range of users have been possible practically since 2011 (D-Wave One machine). The size of currently possible solvable
examples (number of elements) is limited by the number of qubits (today, over 5000 for

---

D-Wave Pegasus technology). The systematic development of hardware suggests that in the
near (near) future, it will be possible to solve examples of much larger sizes than on classic
computers.

The quantum computers currently in use represent two concepts of quantum computing.
The first is quantum computers based on the gate model, with quantum gates operating on
qubits and programs written as a circuit (*circuit).* Quantum gates (Pauli’s, Hadamard, Toffoli,
CNOT, etc.), unlike classical logic gates in electronic computing, are reversible. This type of
computer is currently being developed by IBM and Google.

The second type of quantum machines are the so-called *quantum annealers* realizing
adiabatic quantum computing. They use a physical process to obtain the state of the qubits of
a quantum system representing the discrete optimization problem being solved in a minimalenergy state. The advantage of quantum annealers is that the number of qubits can be much
larger than that currently available in gate-based quantum computing systems (noise is not
as significant as in quantum gate models); however, their use is limited only to specific cases
related to the representation of the problem to be minimized. This type of device is being
developed by NEC and D-Wave.

### 1.2 Quantum annealing

It is a promising computational method using quantum phenomena to solve challenging
optimization tasks. A quantum machine implementing quantum annealing handles a certain
limited class of optimization problems, which can be formulated as problems of Quadratic
Unconstrained Binary optimization (QUBO). There is currently an intensive search for applications of this technology in practice, learning about its capabilities and limitations – the
largest currently available quantum machines of this type have 5640 qubits. The quantum
annealer, through the continuous evolution of the quantum system, searches for the minimum
energy of the Ising Hamiltonian (see Ajagekar et al., 2020; Denkena et al., 2021).

In practice, the tasks formulated for a quantum machine implementing quantum annealing
are in the form of an Ising or QUBO model, with the translation of problems between
these models being natural. The Ising model is used in statistical mechanics with a criterion
function:
∑<sup>N</sup>∑<sup>N</sup>∑<sup>N</sup>

$$
E_{I s i n g}(s)=\sum_{i=1}^{N}h_{i}s_{i}+\sum_{i=1}^{N}\sum_{j=i+1}^{N}J_{i,j}s_{i}s_{j},
$$

where *s*<sub>i</sub>, *i* = *1,2,...,N* express spins of +1 and−1, while the linear coefficients corresponding to the cubit deviations are *h*<sub>i</sub>and the quadratic coefficients corresponding to the
coupling forces are *J*<sub>i, j</sub>. In the QUBO model, on the other hand, the function to be minimized
is of the form
∑<sup>N</sup>∑<sup>N</sup>∑<sup>N</sup>

(1)

$$
s_{i},i=1,2,\ldots,N
$$

$$
h_{i}
$$

$$
J_{i,j}
$$

$$
f(x)=\sum_{i=1}^{N}Q_{i,i}x_{i}+\sum_{i=1}^{N}\sum_{j=i+1}^{N}Q_{i,j}x_{i}x_{j},
$$

(2)

where *Q* is an upper-diagonal matrix with *N*
variables, *x*<sub>i</sub>∈ {0,1}, *i* = *1,2,...,N.*

× *N* real weights, *x* is a vector of binary

$$
x_{i}\in\{0,1\},i=1,2,\ldots,N
$$

QUBO is an unconstrained model, meaning that in practice, any constraints on the problem must be included in the objective function. Some of the computation models (solvers)
available within the D-Wave Ocean libraries are constrained models, e.g. *LeapHybridCQM-
Sampler*—Constrained Quadratic Model (CQM), for which the translation of a constrained
problem to an unconstrained problem takes place inside the solver. The problem formulation for the CQM model takes the form of a minimization:

$$
\sum_{i=1}^{N}a_{i}x_{i}+\sum_{i=1}^{N}\sum_{j=i+1}^{N}b_{i,j}x_{i}x_{j}+c,
$$

(3)

with constraints:

$$
\sum_{i=1}^{N}a_{i}^{(m)}x_{i}+\sum_{i=1}^{N}\sum_{j=i+1}^{N}b_{i,j}^{(m)}x_{i}x_{j}+c^{(m)}\propto0,\quad m=1,2,\ldots,M
$$

(4)

where *x*<sub>i</sub>, *i* = *1,2,...,N* are binary or integer variables, *a*<sub>i</sub>*, b*<sub>i, j</sub>*, c, i, j* = *1,2,...,N,* are
real values, relation ∝∈ {≥, ≤,=} and *M* is the number of all constraints.

$$
x_{i},i=1,2,\ldots,N
$$

$$
a_{i},b_{i,j},c,i,j=1,2,\ldots,N
$$

$$
\propto\in\{\geq,\leq,=\}
$$

## 2 Discrete knapsack problem

In this paper, we consider a well-known problem in the literature called the Discrete Knapsack
Problem (in short DK), often found in production planning issues (Camargo et al., 2012).
There is a set of *items N* = *{1,2,...,n}* and capacity of the knapsack *W.* With every item
*i* ∈ *N* the following notions are linked:

$$
\mathcal{N}=\{1,2,\ldots,n\}
$$

$$
i\in\mathcal{N}
$$

*w*<sub>i</sub>weight of the item *i,*

$$
w_{i}
$$

*v*<sub>i</sub>value of the item *i.*

$$
v_{i}
$$

One has to determine the subset of items with a maximum sum of values whose sum of weights
does not exceed the load capacity of the knapsack *W.* Each solution can be represented by a
binary sequence
**x** = *(x, x,...,x),*

$$
\mathbf{x}=(x_1,x_2,\ldots,x_n),
$$

(5)

where *x*<sub>i</sub>∈ {0,1}, *i* ∈ *N.* If *x*<sub>i</sub>= 1 then that means thati-th item is ‘packed’ in the knapsack.
As a discrete linear programming problem, the knapsack problem is formulated as follows:

$$
x_{i}\in\{0,1\},i\in\mathcal{N}.\mathrm{If}x_{i}=1
$$

$$
maximize:F(\mathbf{x})=\sum_{i=1}^{n}v_i x_i.
$$

(6)

subject to:

$$
\sum_{i=1}^{n}w_{i}x_{i}\leq W,\quad x_{i}\in\{0,1\},\quad i\in\mathcal{N}.
$$

(7)

Despite the simplicity of its formulation (a linear criterion and a single linear constraint),
it belongs to the class of *NP*-hard problems. These are problems for which no algorithms are
currently known for solving them with polynomial computational complexity.

By *X* we denote the set of *feasible solutions,* i.e., *n*-element binary sequences,

$$
\mathcal{X}=\{(x_{1},x_{2},\ldots,x_{n}):\quad\sum_{i=1}^{n}w_{i}x_{i}\leq W,\quad x_{i}\in\{0,1\},i\in\mathcal{N}\}.
$$

(8)

In view of this, the knapsack problem reduces to determining the element inX, that maximizes
the criterion (6), i.e., the optimal solution **x<sup>∗</sup>** ∈ *X* such that

$$
\mathbf{X}^{*}\in\mathcal{X}
$$

$$
F(\mathbf{x}^*)=\max\{F(\mathbf{x}):\mathbf{x}\in\mathcal{X}\}.
$$

(9)

---

In the further part of this paper, we present a method and algorithm for optimal solving the
knapsack problem and procedures for counting, on a D-Wave quantum machine, the lower
and upper bounds.

## 3 Solution method

If the solutions to the DK problem are represented by binary sequences then, according to
(9), solving the problem reduces to determining the optimal element in the set of feasible
solutions *X.* The process of viewing the elements of this set will be represented by a directed
*solution tree H.*

The root of the tree (the only vertex at level zero) is any (starting) sequence **x** ∈ *X,* in which
the set of free elements *K* = *N.* In the root, at most two vertices at level one, are generated
from each free element. These are created by determining the value of one undetermined
element *z,* i.e., by substituting *x*<sub>z</sub>= 0 orx<sub>z</sub>= 1. Similarly, from each vertex of level
one, two more vertices can be generated by determining the value of one of the *n* − 1 free
elements. These form the 2nd level of the tree. Proceeding similarly, we can generate vertices
(solutions) at subsequent levels. Since the tree represents the set of *X,* feasible solutions,
we fix the *z*-th free element, i.e., we adopt *x*<sub>z</sub>= 1, only if the solution generated in this
way satisfies the constraint (8). In the algorithm for searching the solution tree *H* based on
the B&B method, the following procedures play an essential role: generating a new vertex,
backtracking to a lower level of the tree, and computing the lower and upper bounds on the
value of the criterion function. The constraints of the function allow certain subtrees to be
omitted from the search process of the *H* tree without losing the optimality of the solution.
By *H(x)we* denote a subtree in *H,* whose root is a vertex of the **x.**

$$
\mathcal{K}=\mathcal{N}
$$

$$
\mathbf{x}\in\mathcal{X}
$$

$$
x_{z}=0
$$

$$
x_{z}=1
$$

$$
n-1
$$

$$
x_{z}=1
$$

**Generating a new vertex.** Letx∈ *X* be a vertex ofH on the *h*-th level. We generate a
new vertex **y** (on (h+1)-th level) by fixing a job *z* from the set of candidates *K.* Then we
add an arc (x,y) to thetreeH. In each successor of the vertex **y** the job *z* is fixed. The order
in which candidates are selected for determination has a significant impact on the possible
rejection of a subtree in the process of searching the solution tree.

$$
\mathbf{x}\in\mathcal{X}
$$

**Backtracking.** Let us assume that the vertex **y** was generated from **x** by determining the
element *z.* Therefore, if we backtrack from **y** to vertex **x** then from the set of candidates in
vertex **x** we remove the element *z.* The backtracking operation is performed if the set of
candidates at the vertex is an empty set. If it is the root of the tree, the algorithm terminates.
Solving the DK problem thus boils down to determining the vertex (sequence) in the tree *H*
of the maximal value of the objective function (6).

**Lower and upper bounds.** We consider the vertex of the **x** of the solution tree *H.* The
lower bound on the value of the criterion function in the subtree *H(x)* is defined as

$$
LB(\mathbf{x})=\sum_{i=1}^{n}v_{i}x_{i}+LBQ(\mathbf{x}),
$$

(10)

where the first component is the sum of the values of the items determined in **x** (the items
already selected for the knapsack). On the other hand, *LBQ(x*) is a lower bound on the of
the sum of the values of the items with which we can still complete the knapsack. However,
∑
their weight must not exceed *W* −<sub>in</sub><sub>=1</sub>*w*<sub>i</sub>*x*<sub>i</sub>*.* It is easy to see that *LB(x)* is the value of
∗ ∗
some solution **x** of the subtree *H(x).* Element *x* = 1, *i* = *1,2,...,n,* if *x*<sub>i</sub>= 1 ori-th
i
element was chosen when computing the value of LBQ(x). Then, the value of the criterion
function *F (x<sup>∗</sup>)* = *LB(x).*

$$
LBQ(\mathbf{x})
$$

$$
W-\sum_{i=1}^{n}w_{i}x_{i}
$$

$$
\mathbf{x}^{*}
$$

$$
x_{i}^{*}=1,i=1,2,\ldots,n
$$

$$
x_{i}=1
$$

$$
LBQ(\mathbf{x})
$$

$$
F(\mathbf{x}^{*})=LB(\mathbf{x})
$$

---

In turn, the upper bound of the value of the criterion function

$$
UB(\mathbf{x})=\sum_{i=1}^{n}v_i x_i+UBQ(\mathbf{x}),
$$

(11)

where the first component is the sum of the values of the items fixed in **x** (items already
selected to be in the knapsack), whereas *UBQ(x*) is the upper bound of the sum of the values
of items that are not yet determined (to the knapsack).

$$
UBQ(\mathbf{x})
$$

The values of the lower and upper bounds have an important impact on the B&B algorithm workflow. This is because if *LB(x)* ≥ *UB(x),* then without losing the optimality of
the solution, the subtree *H(x),* including the vertex of **x** can be omitted. In this way, the
computation time can be significantly reduced. In order to obtain the largest possible value
of the lower bound and the smallest possible value of the upper bound, we will determine
both on the D-Wave quantum machine.

$$
LB(\mathbf{x})\geq UB(\mathbf{x})
$$

The most important elements of the proposed B&B method are methods of determining
the upper estimate of the optimal value of the objective function and determination of the
best possible solution for each node of the tree. Let *UB(N, W)* be the upper estimate of the
value of the objective function for the set of elements *N* for a knapsack of the load *W,* then
the value of the upper estimate of the optimal value of the objective function for the node
described by the quadratic *(h, α,x, K)* can be determined from the formula

$$
UB(h,\alpha,x,\mathcal{K})=\sum_{i=1}^{h}v_{\alpha(i)}x_{\alpha(i)}+UB(\mathcal{K},W-\sum_{i=1}^{h}w_{\alpha(i)}x_{\alpha(i)}).
$$

(12)

Further, let *BF(N, W)* be the value of the objective function determined for a set of
elements and a knapsack of *W,* then value of the objective function for the best solution
representing the node described by the tuble *(h, α,x, K)* is

$$
BF(\mathcal{N},W)
$$

$$
(h,\alpha,x,\mathcal{K})
$$

$$
B F(h,\alpha,x,\mathcal{K})=\sum_{i=1}^{h}v_{\alpha(i)}x_{\alpha(i)}+B F(\mathcal{K},W-\sum_{i=1}^{h}w_{\alpha(i)}x_{\alpha(i)}).
$$

(13)

∗ ∗
If *UB(h, α,x, K)* ≤ *F (x),* wherex is the best solution found so far then it is removed
from the tree (cut in the B&B method). The values of *UB(N, W)* and *BF(N, W)* will be
determined on the D-Wave quantum computer. This requires their transformation to QUBO
form.

$$
x^{*}
$$

$$
UB(h,\alpha,x,\mathcal{K})\leq F(x^*)
$$

### 3.1 Determination of constraints on a D-Wave quantum machine

Tasks formulated for a solution by a D-Wave quantum machine must be in the form of discrete
quadratic programming with constraints and minimization of the objective function (QUBO).
We will therefore reduce the tasks of counting the value of the lower and upper bounds to
this form. To simplify the notation, let us assume that the free elements in the solution **x,** are
numbered consecutively with numbers from 1 to *t.*

**Lower bound.** To determine the value of *LBQ(x)* in the formula for the lower bound
(10), we will formulate a certain subproblem (abbreviated as PDK) of the initial knapsack
∑
problem. Let *P* = *W* −<sub>in</sub><sub>=1</sub>*w*<sub>i</sub>*x*<sub>i</sub>be the load capacity of the knapsack. One should choose
such a subset of the set of elements with indices *i* = *1,2,...,t* that the sum of the value of
elements is maximal and the sum of the weights does not exceed the load capacity *P.* Thus,

$$
P=W-\sum_{i=1}^{n}w_{i}x_{i}
$$

$$
i=1,2,\ldots,t
$$ one should

$$
\operatorname{maximize}:f(\mathbf{y})=\sum_{i=1}^{t}v_i y_i
$$

(14)

with constraints:

$$
\sum_{i=1}^{t}w_{i}y_{i}\leq P,\quad y_{i}\in\{0,1\},i=1,2,\ldots,t.
$$

(15)

Since max *f (x)* =−min(− *f (x))* thus the optimization problem (14)–(15) represents the
binary optimization problem with constraints, which can be natively translated on a D-Wave
to a QUBO model. If **y<sup>∗</sup>** is its solution, then we assume *LBQ(x)* = *f (y<sup>∗</sup>).*

$$
f(x)=-\min(-f(x))
$$

$$
\mathbf{y}^{*}
$$

$$
LBQ(\mathbf{x})=f(\mathbf{y}^*)
$$

**Upper bound.** We use the Lagrange relaxation method to determine the value of the
upper bound *LBQ(x),* for the PDK problem defined in (14)–(15), The Lagrange function
with multiplier *u,* forthe variablesy = *(y*<sub>1</sub>*, y*<sub>2</sub>*,...,y*<sub>t</sub>*),* takes the form:

$$
LBQ(\mathbf{x})
$$

$$
y=(y_1,y_2,\ldots,y_t)
$$

$$
\begin{align*}L(y,u)&=\sum_{i=1}^{t}v_i y_i+u(w_1y_1+w_2y_2+\ldots+w_t y_t-W)\\&=\sum_{i=1}^{t}L_i(y_i,u)-u W,\end{align*}
$$

(16)

where

$$
L_{i}(y_{i},u)=y_{i}(v_{i}+w_{i}u).
$$

Maximalization *L(x, u)* with respect to individual variables *x*<sub>i</sub>, for fixed values of *u,* can be
performed independently.

$$
L(x,u)
$$

$$
x_{i}
$$

$$
u,
$$

Let us note that for *any u* ≤ 0, and the optimal solution *y<sup>∗</sup>* of the PDK problem, the
following lemma holds:

$$
u\leq0
$$

$$
y^{*}
$$

**Lemma 1** *(Bȯzejko et al., 2024) For any value u*<sub>i</sub>≤ *0,i* = *1,2,...,t of the Lagrange
multipliers, the value L(y, u) of the Lagrangian function is an upper bound on the optimal*
∑
∗
*objective function value*<sub>it</sub><sub>=1</sub>*v*<sub>i</sub>*y of the PDK problem.*
i

$$
u_{i}\leq0,i=1,2,\ldots,t
$$

$$
L(y,u)
$$

$$
\sum_{i=1}^{t}v_{i}y_{i}^{*}
$$

Using the above lemma, it can be shown that
{

$$
UBQ(\mathbf{x})=\min_{u\in U}\left\{\sum_{i=1}^{t}\max_{y_i\in\{0,1\}}L_i(y_i,u)-uW\right\}
$$

(17)

∑
∗
is an upper bound on the optimal value of the maximized objective function<sub>it</sub><sup>=1</sup>*w*<sub>i</sub>*y* for
i
the PDK problem. Thus, to compute *UBQ(x),* the upper bound of the Lagrange function for
the PDK problem on the D-Wave computer, we determine the values of the vector *u* using
quantum annealing by solving the following QUBO task:
{}

$$
\sum_{i=1}^{t}w_{i}y_{i}^{*}
$$

$$
UBQ(\mathbf{x})
$$

$$
\min_{u\in U,y\in A}\left\{\sum_{i=1}^{t}L_{i}(y_{i},u)-u W\right\},
$$

(18)

where *A* is the set of solutions admissible for the PDK problem, given the constraints:

$$
L_{i}(y_{i},u)\geq L_{i}(0,u),
$$

and

(19)

$$
L_{i}(y_{i},u)\geq L_{i}(1,u),
$$

for *u* ≤ 0.

$$
u\leq0.
$$

(20)

---

**Table 1** Problem instance data

| i | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| wi | 94 | 416 | 992 | 649 | 815 | 422 | 791 | 667 | 598 | 7 | 766 | 893 |
| pi | 96 | 417 | 993 | 651 | 816 | 423 | 792 | 669 | 600 | 9 | 768 | 894 |

$$
w_{i}
$$

In total, the total number of constraints is 2t. Thevariablesy<sub>i</sub>take two values 0 or 1. In
view of this, the maximization over the vector *y* in the expression (17) is replaced by the
inequalities (19) and(20)—paradoxically, the maximization over *y* is obtained in the formula
(18) even though formally a minimum is written, but de facto it only means a run over all
values of the variable *y.* This formulation is necessary in order to run the task on a D-Wave
machine that only performs minimization with respect to the given variables.

$$
y_{i}
$$

## 4 Exact hybrid algorithm

By performing calculations on a quantum machine, it is possible to determine the lower
and upper bounds of the criterion function at a vertex of the solution tree in a short time
(in our experiments the QPU time was 15–32 ms). In the hybrid B&B algorithm, the lower
and upper bounds are determined on the QPU of the D-Wave quantum machine, and the
remaining computations are performed on the CPU. When searching the solution tree of *H,*
a *best-first* strategy is used with a priority queue implemented in the heap structure (variable
*Heap*) containing the values of the upper bounds. Tuples are remembered at the vertices of
the mound: (*heap, x,α candidate set, upper bound, value of objective function),* where *x* is
the vertex of the tree and *α* the set element generating the successor of *x* in the tree.

The algorithm starts from step 1, fetching the tuplet from the priority queue (heap). In step
2, a decision is made whether to develop a new subtree. In step 3 of the algorithm, for each
candidate, *k* ∈ *K,* the feasibility of the solution is checked (step 3.2), and then the estimates
are calculated. If the generated solution is not feasible or the value of the upper estimate is not
greater than the lower estimate (the best one determined so far), the vertex corresponding to
the value *x*<sub>k</sub>= 1 is not generated. The element *k* is removed from the set of candidates (step
3.3). The selection of the best candidate to determine and the updating of the best solution
is performed in step 4. In steps 5 to 8 the new vertices of the solution tree are generated. In
step 8.1, selected candidates are put to the *H eap* (see Fig. 1).

$$
k\in\mathcal{K}.
$$

$$
x_{k}=1
$$

### 4.1 Case study

Using a small example of a knapsack problem, we show the progression of the classical B&B
algorithm (running on the CPU) and the hybrid B&B_CPU_QPU algorithm run on the QPU
and CPU. The set of items *N* = {1,2,...,12}. The weights and the values of the items are
provided in Table 1. knapsack capacities *W* = 994.

$$
\mathcal{N}=\{1,2,\ldots,12\}
$$

The solution tree of the B&B algorithm is shown in Fig. 2 for a test instance data from
Table 1. Each vertex in the tree contains: the iteration number (top left corner), the value of
the upper bound (top right corner), the items in the knapsack (center), and the sum of the
values of the items in the knapsack (bottom right corner). The absence of descendant vertices
means that they have been cut off. There were 20 vertices generated during the calculation.
The optimal solution was obtained in 3 iterations. There were still 18 iterations until the

---

**Fig. 1** Hybrid quantum algorithm

$$
x^{*}-
$$

$$
x^{*}=\arg\max_{x}BF(0,\alpha,x,\mathcal{N})
$$

$$
\begin{aligned}{\iota(\mathit{H e a p,}(0,x^{*},\alpha,\mathcal{N},U B(0,\alpha,x,\mathcal{N}),F(x^{*}))}\\ \end{aligned}
$$

$$
Heap\neq\emptyset
$$

$$
\left(\mathrm{Heap},(h,x,\alpha,\mathcal{K},UB)\right)
$$

$$
(\lfloor U B\rfloor\leq F(x^{*}))
$$

$$
k\in\mathcal{K}
$$

$$
\alpha(h+1)=k;x_k=1
$$

$$
\sum_{i=1}^{h+1}x_{\alpha(i)}w_{\alpha(i)}\leq W
$$

$$
UB(h+1,\alpha,x,\mathcal{K}\setminus k)>F(x^*)
$$

$$
y^{k}=\arg\max_{x}B F(h+1,\alpha,x,\bar{\mathcal{K}}\setminus k)
$$

$$
\mathcal{K}=\mathcal{K}\setminus k;
$$

$$
z=\arg\min_{k\in\mathcal{K}}F(y^{k});\:\mathbf{if}\;F(y^{z})<F(x^{*})\mathbf{then}x^{*}=y^{z}
$$

$$
x_{z}=0;
$$

$$
UB(h+1,\alpha,x,\mathcal{K}\setminus z)>F(x^*)
$$

$$
\mathrm{Put}(\mathrm{Heap},(h+1,x,\alpha,\mathcal{K}\setminus z,
$$

$$
UB(h+1,\alpha,x,\mathcal{K}\setminus z),F(x)))
$$

$$
x_{z}=1
$$

$$
UB(h+1,\alpha,x,\mathcal{K}\setminus z)>F(x^*)
$$

$$
(\mathrm{Heap},(h+1,x,\alpha,\mathcal{K}\setminus z,
$$

$$
UB(h+1,\alpha,x,\mathcal{K}\setminus z),F(x)))
$$

calculation was fully completed. Fig. 3 shows a fragment of the solution tree illustrating the
flow of calculations between the CPU and QPU to generate the vertexes.

The hybrid algorithm B&B_CPU_QPU, at the root of the solution tree, determined a
solution *x*<sub>1</sub>= 1, *x*<sub>10</sub>= 1 andx<sub>12</sub>= 1 (the remaining elements are 0) with a value of 999. At
this vertex, the upper estimate of the optimal value of the objective function is *UB=* 1001.9.
Next, vertices from level 1 of the tree were generated sequentially. Some results are included
in Table 2. Row one (denoted by *z*) shows the variables that were sequentially given the value
1. Row two shows the values of the upper bounds, and row three shows the values of the best
solution found.

$$
x_{1}=1,x_{10}=1
$$

$$
x_{12}=1
$$

$$
UB=1001.9
$$

For the vertex of the tree generated by determining *x*<sup>3</sup>= *1,* the value of the upper bound
∗
*UBQ* = 993 is less than *F (x)* = 999, thus item 3 is removed from the set of candidates.
The same is true for items 2, 4, 5, 6, 7, 8, 9, 11, and 12. Finally, the set of candidates to be
determined *K* = {1,10,12}.

$$
x_{3}=1
$$

$$
UBQ=993
$$

$$
F(x^{*})=999
$$

$$
\mathcal{K}=\{1,10,12\}
$$

---

1 1001
0
x₁₀ = 0
18 999
0
x₁₀ = 1
2 1001
10
9
x₁ = 0
11 1000
10
9
x₁ = 1
3 1001
1 10
105
x₁₂ = 0
12 1001
10
9
x₁₂ = 0
4 1002
1 10
105
x₁₂ = 1
999
12 1 10
999
x₂ = 0
13 1001
10
9
x₂ = 0
5 1002
1 10
105
x₅ = 0
14 1001
10
9
x₅ = 0
6 1002
1 10
105
x₇ = 0
15 1001
10
9
x₇ = 0
7 1002
1 10
105
x₁₁ = 0
16 1002
10
9
x₁₁ = 0
8 1004
1 10
105
x₈ = 0
17 1000
10
9
x₈ = 0
9 1002
1 10
105
x₄ = 0
19 999
10
9
x₄ = 0
10 1001
1 10
105

**Fig. 2** The solution tree of the B&B algorithm

CPU get vertex
QPU Upper Bound
QPU Lower Bound
CPU put vertex

time

root

CPU QPU QPU
CPU

**Fig. 3** Flow of computation by the CPU/QPU

---

**Table 2** Values determined for the *root* in the first iteration of the algorithm

| z | x1 | x2 | x3 | x4 | x5 | x6 | x7 | x8 | x9 | x10 | x11 | x12 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| UBQ | 4260 | 944 | 993 | 756 | 921 | 528 | 897 | 774 | 705 | 11,688 | 873 | 999 |
| F(x*) | 999 | - | - | - | - | - | - | - | - | 901 | - | - |

$$
F(x^{*})
$$

Let *z* = 1 be the candidate selected in Step 5. For *x*<sup>1</sup>= 0 thevalueofUBis 903, while
∗
for *x*<sub>1</sub>= 1 it is 999. Both values are smaller than *F (π),* therefore no descendant nodes will
be generated, which terminates the algorithm.

$$
z=1
$$

$$
x_{1}=0
$$

$$
x_{1}=1
$$

$$
F(\pi^{*})
$$

## 5 Computational results

This section aims to experimentally investigate the efficiency of quantum computing on a
medium to large data sizes.

We evaluate the performance of quantum computing on state-of-the-art instances of the
knapsack problem taken from OR-Library (they are available here Pempera & Uchrónski,
2023). We especially focus on 30 hard instances ranging from *n* = 100 to *n* = 500 items.
The original test instances have more than one constraint; therefore, we only considered the
first constraints in the problem under consideration.

$$
n=100
$$

$$
n=500
$$

The calculations on the quantum machine were limited to calculating only UB and LB for
the root of the B&B search tree for each instance. This is related to a long time of initial data
processing in the cloud by the provider of the quantum computing service and/or its business
policy. This time is not less than 5 s for one run of calculations. In addition, calculations
were carried out on a classic computer using the GUROBI package. As a result of these
calculations, optimal values were obtained.

### 5.1 D-Wave quantum computing environment

Quantum calculations were performed using *LeapHybridCQMSampler* solver, which implements quantum annealing in hardware. CQM solver runs with an Advantage backend for
the quantum portion of the quantum-classical hybrid solver. Advantage QPUs are based on
the Pegasus graph topology with size P16 containing at least 5000 qubits with 15 couplers
per qubit, totaling at least 35.000 couplers. Classical calculations were performed on a Dell
OptiPlex 7040 computer with an Intel Core i5-6500 processor and 12 GB RAM.

The Table 3 presents the results of experimental studies. Column 4 shows the total access
time to the quantum machine, including programming the machine and computation time. It
should be noted that the actual quantum computation time is at least an order of magnitude
shorter than the access time (see Online document D-Wave Timing Documentation, 2024).

### 5.2 Discussion of the results

Quantum computation environments are already a real competition for classical supercomputer computations based on silicon processors. Especially for problems for which the natural
representation of solutions are binary variables, as in the knapsack problem, translation to the
QUBO model is natural and allows solving relatively large examples on the QPU quantum

---

**Table 3** Results of computational experiments (optimal values are marked in bold)

| Instance | QAdB&amp;B LB | QAdB&amp;B UB | QAdB&amp;B QPU [ms] | GUROBI OPT | GUROBI CPU [ms] |
| --- | --- | --- | --- | --- | --- |
| OR5x100-0.25_1 | 39, 109 | 42, 236 | 16 | 39, 109 | 37 |
| OR5x100-0.25_2 | 36, 836 | 40, 401 | 31 | 36, 836 | 40 |
| OR5x100-0.25_3 | 34, 279 | 37, 812 | 31 | 34, 279 | 39 |
| OR5x100-0.25_4 | 35, 593 | 40, 050 | 32 | 35, 593 | 36 |
| OR5x100-0.25_5 | 33, 247 | 36, 944 | 31 | 33, 249 | 45 |
| OR5x100-0.25_6 | 36, 406 | 39, 208 | 16 | 36, 425 | 39 |
| OR5x100-0.25_7 | 35, 954 | 40, 419 | 31 | 35, 969 | 44 |
| OR5x100-0.25_8 | 36, 969 | 40, 810 | 31 | 36, 969 | 41 |
| OR5x100-0.25_9 | 35, 261 | 39, 194 | 15 | 35, 276 | 34 |
| OR5x100-0.25_10 | 34, 855 | 38, 935 | 31 | 34, 855 | 43 |
| Average |  |  | 26 |  | 39 |
| OR30x250-0.25_1 | 93, 553 | 96, 667 | 16 | 93, 898 | 65 |
| OR30x250-0.25_2 | 94, 620 | 99, 902 | 16 | 96, 320 | 71 |
| OR30x250-0.25_3 | 90, 597 | 94, 109 | 16 | 91, 169 | 66 |
| OR30x250-0.25_4 | 98, 159 | 101, 978 | 15 | 98, 747 | 64 |
| OR30x250-0.25_5 | 97, 722 | 101, 985 | 15 | 98, 984 | 71 |
| OR30x250-0.25_6 | 96, 262 | 99, 272 | 15 | 96, 475 | 69 |
| OR30x250-0.25_7 | 89, 382 | 93, 048 | 16 | 90, 141 | 77 |
| OR30x250-0.25_8 | 97, 812 | 101, 450 | 16 | 98, 215 | 69 |
| OR30x250-0.25_9 | 94, 158 | 98, 211 | 16 | 95, 266 | 72 |
| OR30x250-0.25_10 | 94, 905 | 98, 692 | 15 | 95, 706 | 73 |
| Average |  |  | 15 |  | 69 |
| OR30x500-0.25_1 | 181, 024 | 187, 679 | 16 | 183, 946 | 204 |
| OR30x500-0.25_2 | 182, 558 | 192, 438 | 16 | 184, 876 | 208 |
| OR30x500-0.25_3 | 190, 230 | 196, 035 | 16 | 191, 857 | 199 |
| OR30x500-0.25_4 | 184, 492 | 194, 754 | 15 | 190, 270 | 191 |
| OR30x500-0.25_5 | 189, 511 | 199, 901 | 16 | 192, 276 | 164 |
| OR30x500-0.25_6 | 176, 709 | 191, 185 | 16 | 179, 981 | 199 |
| OR30x500-0.25_7 | 178, 692 | 188, 532 | 16 | 184, 622 | 212 |
| OR30x500-0.25_8 | 182, 609 | 190, 747 | 16 | 185, 662 | 198 |
| OR30x500-0.25_9 | 185, 354 | 193, 559 | 16 | 189, 127 | 210 |
| OR30x500-0.25_10 | 188, 991 | 199, 669 | 15 | 193, 674 | 423 |
| Average |  |  | 15 |  | 220 |

processor. Comparing the quality of the solutions obtained, it should be noted that in the
instances with 100 items, the quantum machine found the optimal solution in 5 out of 10
cases. The average error of the solutions, calculated as the relative difference between the
value of the knapsack generated by this machine and the optimal value in relation to the
optimal value, is only 0.014% for this group of instances. For instances with 250 and 500
items, this error is accordingly 0.819% and 1.969%. The average time of using a quantum machine is comparable to the time of calculations on a classical computer for *n* = 100 and
over 13 times shorter for *n* = 500.

$$
n=500
$$

It is worth noting that the current capabilities of quantum annealers related to the number
of qubits and their connections significantly limit (to a few or a dozen tasks) the size of
solvable examples of optimization and decision-making problems. This is a limitation that
applies to all researchers conducting computational experiments on quantum computers. For
example, in the work of Chen et al. (2022) the results are approximate for the 3-SAT problem
of size *n* ≤ 15, and in Jain’s work Jain (2021) the largest example size for the traveling
salesman problem was *n* = 10. In this context, our solving optimally most examples of
size *n* = 100 and approximately for *n* = 250 and *n* = 500 represents a significant shift
in the boundary of solvable problem instances. Moreover, for instances for which we have
determined an approximate solution, we are able to precisely provide the maximum error
of this approximation by determining the Lower and Upper Bounds (*LB* and *UB*) of the
optimal solution.

$$
n\leq15
$$

## 6 Summary

The paper presents the potential of utilizing a quantum machine to hardware-implement quantum annealing procedures for the exact solving of the NP-hard Knapsack Problem based on
the Branch and Bound method. Quantum annealing is executed on the QPU alternating with
a control procedure overseeing the search tree implemented on a silicon-based CPU. The
studied problem pertains to production systems, specifically focusing on production line balancing, transportation logistics, and inner-factorial route optimization. The study introduces
an innovative approach, leveraging quantum machinery for hardware realization of the quantum annealing procedure, grounded in the Branch and Bound method. The results obtained
from the D-Wave quantum machine indicate that, despite the probabilistic nature of quantum
computations, it is possible to generate truly optimal solutions using this groundbreaking
technology.

In the experimental outcomes derived from the quantum machine, a significant acceleration in solving the knapsack problem was observed compared to traditional computational
methods. The integration of quantum annealing with the Branch and Bound method enabled
precise and efficient control over the algorithm, leading to the discovery of optimal solutions in a shorter timeframe. Future research directions are planned to further investigate
the algorithm’s effectiveness and efficiency across various logistical scenarios, taking into
account diverse operational conditions such as different types of heavy-duty trucks, varying
load requirements, and distinct route constraints. Additionally, optimization of the quantum annealing procedure and integration with other advanced computational techniques are
envisioned to enhance the algorithm’s overall efficiency and performance.

**Acknowledgements** We gratefully acknowledge Polish high-performance computing infrastructure PLGrid
(HPC Center: ACK Cyfronet AGH) for providing computer facilities and support within computational grant
no. PLG/2024/017186.

**Data availability** The dataset for computational experiments is available at http://zasobynauki.pl/zasoby/
83109. Data for a case study on the transport problem from Section 3 can be sent on request.

---

## Declarations

**Conflict of interest** The authors do not declare any financial or non-financial Conflict of interest in connection
with the work.

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which
permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give
appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence,
and indicate if changes were made. The images or other third party material in this article are included in the
article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is
not included in the article’s Creative Commons licence and your intended use is not permitted by statutory
regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder.
To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/.

## References

Ajagekar, A., Humble, T., & You, F. (2020). Quantum computing based hybrid solution strategies for largescale discrete-continuous optimization problems. *Computers & Chemical Engineering, 132,* 106630.

Barakat, D.E.-S., El-Henawy, I. M., & Abdel-Basset, M. (2016). Knapsack Problems: a comprehensive review.
*Asian Journal of Mathematics and Computer Research,* 14(4), 296–317.

Biglar, A. (2018). *Some applications of Knapsack problem,* (2018). https://doi.org/10.13140/RG.2.2.15115.
39209.

Bȯzejko, W., Pempera, J., Uchrónski, M., & Wodecki, M. (2022). Distributed Quantum Annealing on D-Wave
for the Single Machine Total Weighted Tardiness Scheduling Problem. In D. Groen, C. de Mulatier, M.
Paszynski, V.V. Krzhizhanovskaya, J.J. Dongarra, P.M.A. Sloot, (Ed.), *Computational Science,* 13353,
(pp. 171–178). LNCS.

Bȯzejko, W., Pempera, J., Uchrónski, M., & Wodecki, M. (2024). Quantum annealing-driven branch and
bound for the single machine total weighted number of tardy jobs scheduling problem. *Future Generation
Computer Systems, 155,* 245–255.

Bȯzejko, W., Klempous, R., Pempera, J., Rozenblit, J., Uchrónski, M., & Wodecki, M. (2023). Optimal
solving of a scheduling problem using quantum annealing metaheuristics on the D-Wave quantum solver,
TechRxiv, Preprint, https://doi.org/10.36227/techrxiv.22677721.v1.

Cacchiani, V., Iori, M., Locatelli, A., & Martello, S. (2022). Knapsack problems - An overview of recent
advances. Part I: Single knapsack problems. *Computers & Operations Research, 143,* 105692.

Camargo, V., Mattiolli, L., & Toledo, F. (2012). A knapsack problem as a tool to solve the production planning
problem in small foundries. *Computers & Operations Research, 39,* 86–92.

Chen, Y. Q., Chen, Y., Lee, C. K., Zhang, S., & Hs, C. Y. (2022). Optimizing quantum annealing schedules
with Monte Carlo tree search enhanced with neural networks. *Nature Machine Intelligence, 4,* 269–278.

Cho, M. (2019). The Knapsack Problem and Its Applications to the Cargo Loading Problem, *Analysis of
Applied Mathematics,48.*

Coniglio, S., Furini, F., & San Segundo, P. (2021). A new combinatorial branch-and-bound algorithm for the
Knapsack Problem with Conflicts. *European Journal of Operational Research,* 289(2), 435–455.

Dam, W., Eldefrawy, K., Genise, N., & Parham, N. (2021). Quantum Optimization Heuristics with an
Application to Knapsack Problems.2021 *IEEE International Conference on Quantum Computing and
Engineering (QCE),* (pp. 160–170) Broomfield, CO, USA, (2021).

Denkena, B., Schinkel, F., Pirnay, J., & Wilmsmeier, S. (2021). Quantum algorithms for process parallel
flexible job shop scheduling. *CIRP Journal of Manufacturing Science and Technology, 33,* 100–114.

He, Y., Wang, J., Liu, X., Wang, X., & Ouyang, H. (2024). Modeling and solving of knapsack problem with
setup based on evolutionary algorithm. *Mathematics and Computers in Simulation, 219,* 378–403.

Jain, S. (2021). Solving the Traveling Salesman Problem on the D-Wave Quantum Computer. *Frontiers in
Physics, 9,* 760783. https://doi.org/10.3389/fphy.2021.760783

Ji, Z., Wang, Z., Wu, T., & Huang, W. (2017). Solving the 0–1 knapsack problem based on a parallel intelligent
molecular computing model system. *Journal of Intelligent & Fuzzy Systems,* 33(5), 2719–2726.

Kellerer, H., Pferschy, U., & Pisinger, D. (2004). *Knapsack problems.* Berlin: Springer.

Laabadi, S., Naimi, M., El Amri, H. & Achchab, B. (2018). The 0/1 Multidimensional Knapsack Problem and
Its Variants: A Survey of Practical Models and Heuristic Approaches. *American Journal of Operations
Research,8(05),* https://doi.org/10.4236/ajor.2018.85023.

---

Li, X., Fang, W., & Zhu, S. (2023). An improved binary quantum-behaved particle swarm optimization
algorithm for knapsack problems. *Information Sciences, 648,* 119529.

Online document D-Wave Timing Documentation. Retrieved April 7, 2024. https://docs.dwavesys.com/docs/
latest/c_qpu_timing.html

Pempera, J., & Uchrónski, M. (*2023).Benchmark test files for the binary knapsack problem,* http://zasobynauki.
pl/zasoby/83109.

Pusey-Nazzaro, L., & Date, P. (2020). Adiabatic Quantum Optimization Fails to Solve the Knapsack Problem,
arxiv:2008.07456.

Refaei, R., Zhang, A. Y., Firat, M., & Kaymak, U. (2020). A State Aggregation Approach for Solving Knapsack
Problem with Deep Reinforcement Learning. *Proceedings of Machine Learning Research, 129,* 81–96.

Rizk-Allah, R. M., & Hassanien, A. E. (2018). New binary bat algorithm for solving 0–1 knapsack problem.
*Complex & Intelligent Systems, 4,* 31–53.

Shen, J., Shigeoka, K., Ino, F., & Hagihara, K. (2019). GPU-based branch-and-bound method to solve large 0–1
knapsack problems with data-centric *strategies.Concurrency and Computation: Practice and Experience,
31,* e4954.

Vasilchikov, V. V. (2018). On a Recursive-Parallel Algorithm for Solving the Knapsack Problem. *Automatic
Control and Computer Sciences, 52,* 810–816.

Vu, T., & Derbel, B. (2016). Parallel Branch-and-Bound in multi-core multi-CPU multi-GPU heterogeneous
environments. *Future Generation Computer Systems, 56,* 95–109.

Wang, Z., Zhang, H., & Li, Y. (2022). Fast Polynomial Time Approximate Solution for 0-1 Knapsack Problem.
*Hindawi Computational Intelligence and Neuroscience,* Article ID 1266529, https://doi.org/10.1155/
2022/1266529.

Wilbaut, Ch., Hanafi, S., & Salhi, S. (2008). A survey of effective heuristics and their application to a variety
of knapsack problems. *IMA Journal of Management Mathematics,* 19(3), 227–244.

Yarkoni, S., Raponi, E., Bäck, T., & Schmitt, S. (2022). Quantum annealing for industry applications: introduction and review. *Reports on Progress in Physics,* 85(10), 104001. https://doi.org/10.1088/1361-6633/
ac8c54

Zavala-Diaz, J. C., Cruz-Chávez, M. A., López-Calderón, J., Hernández-Aguilar, J. A., & Luna-Ortíz, M. E.
(2019). A Multi-Branch-and-Bound Binary Parallel Algorithm to Solve the Knapsack Problem 0–1in a
Multicore Cluster. *Applied Sciences, 9,* 53–68.

Zhang, J. (2011). Comparative Study of Several Intelligent Algorithms for Knapsack Problem. *Procedia
Environmental Sciences, 11,* 163–168.

**Publisher’s Note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and
institutional affiliations.