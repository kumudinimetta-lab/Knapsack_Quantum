##### Report GitHub Issue

×

Title:

Content selection saved. Describe the issue below:

Description:

Submit without GitHubSubmit in GitHub

![](https://arxiv.org/static/base/1.0.1/images/icons/smileybones-small.svg)arXiv is now an independent nonprofit! [Learn more](https://info.arxiv.org/about) ×

[![arXiv logo](https://arxiv.org/static/base/1.0.1/images/arxiv-logo-primary-light.svg)Back to arXiv](https://arxiv.org/)

[Why HTML?](https://info.arxiv.org/about/accessible_HTML.html) [Report Issue](https://arxiv.org/html/quant-ph/9511018v1# "Report an Issue") [Back to Abstract](https://arxiv.org/abs/quant-ph/9511018v1 "Back to abstract page") [Download PDF](https://arxiv.org/pdf/quant-ph/9511018v1 "Download PDF")

1. [Abstract](https://arxiv.org/html/quant-ph/9511018v1#abstract1 "In Quantum Networks for Elementary Arithmetic Operations")
2. [I Introduction](https://arxiv.org/html/quant-ph/9511018v1#S1 "In Quantum Networks for Elementary Arithmetic Operations")
3. [II Basic concepts](https://arxiv.org/html/quant-ph/9511018v1#S2 "In Quantum Networks for Elementary Arithmetic Operations")
4. [III Network architecture](https://arxiv.org/html/quant-ph/9511018v1#S3 "In Quantum Networks for Elementary Arithmetic Operations")
   1. [III.1 Plain adder](https://arxiv.org/html/quant-ph/9511018v1#S3.SS1 "In III Network architecture ‣ Quantum Networks for Elementary Arithmetic Operations")
   2. [III.2 Adder modulo NN](https://arxiv.org/html/quant-ph/9511018v1#S3.SS2 "In III Network architecture ‣ Quantum Networks for Elementary Arithmetic Operations")
   3. [III.3 Controlled–multiplier modulo NN](https://arxiv.org/html/quant-ph/9511018v1#S3.SS3 "In III Network architecture ‣ Quantum Networks for Elementary Arithmetic Operations")
   4. [III.4 Exponentiation Modulo N](https://arxiv.org/html/quant-ph/9511018v1#S3.SS4 "In III Network architecture ‣ Quantum Networks for Elementary Arithmetic Operations")
5. [IV Network complexity](https://arxiv.org/html/quant-ph/9511018v1#S4 "In Quantum Networks for Elementary Arithmetic Operations")
6. [V Conclusion](https://arxiv.org/html/quant-ph/9511018v1#S5 "In Quantum Networks for Elementary Arithmetic Operations")
7. [VI Acknowledgments](https://arxiv.org/html/quant-ph/9511018v1#S6 "In Quantum Networks for Elementary Arithmetic Operations")
8. [References](https://arxiv.org/html/quant-ph/9511018v1#bib "In Quantum Networks for Elementary Arithmetic Operations")

[License: Assumed arXiv.org perpetual non-exclusive license](https://info.arxiv.org/help/license/index.html#licenses-available)

arXiv:quant-ph/9511018v1 \[quant-ph\] 16 Nov 1995

# Quantum Networks for Elementary Arithmetic Operations

Vlatko Vedral
††thanks: Current address: Blackett Laboratory,
Imperial College, Prince Consort Road, London SW7 2BZ, U.K.Adriano Barenco and Artur Ekert

Clarendon
Laboratory, Department of Physics

University of Oxford, Oxford, OX1 3PU, U.K.

Submitted to Phys. Rev. A

###### Abstract

Quantum computers require quantum arithmetic. We provide an explicit
construction of quantum networks effecting basic arithmetic
operations: from addition to modular exponentiation. Quantum modular
exponentiation seems to be the most difficult (time and space
consuming) part of Shor’s quantum factorising algorithm. We show
that the auxiliary memory required to perform this operation in a
reversible way grows linearly with the size of the number to be
factorised.

###### pacs

03.65.Ca, 07.05.Bx, 89.80.+h

## I Introduction

A quantum computer is a physical machine that can accept input states
which represent a coherent superposition of many different possible
inputs and subsequently evolve them into a corresponding superposition
of outputs. Computation, i.e. a sequence of unitary
transformations, affects simultaneously each element of the
superposition, generating a massive parallel data processing albeit
within one piece of quantum hardware \[ [1](https://arxiv.org/html/quant-ph/9511018v1#bib.bib1 "")\]. This way quantum
computers can efficiently solve some problems which are believed to be
intractable on any classical computer \[ [2](https://arxiv.org/html/quant-ph/9511018v1#bib.bib2 ""), [3](https://arxiv.org/html/quant-ph/9511018v1#bib.bib3 "")\]. Apart from
changing the complexity classes, the quantum theory of computation
reveals the fundamental connections between the laws of physics and
the nature of computation and mathematics \[ [4](https://arxiv.org/html/quant-ph/9511018v1#bib.bib4 "")\].

For the purpose of this paper a quantum computer will be viewed as a
quantum network (or a family of quantum networks) composed of quantum
logic gates; each gate performing an elementary unitary operation on
one, two or more two–state quantum systems called qubits\[ [5](https://arxiv.org/html/quant-ph/9511018v1#bib.bib5 "")\]. Each qubit represents an elementary unit of
information; it has a chosen “computational” basis
{\|0⟩,\|1⟩}\\{\|0\\rangle,\|1\\rangle\\} corresponding to the classical bit values
00 and 11. Boolean operations which map sequences of 0’s and 1’s
into another sequences of 0’s and 1’s are defined with respect to this
computational basis.

Any unitary operation is reversible that is why quantum networks
effecting elementary arithmetic operations such as addition,
multiplication and exponentiation cannot be directly deduced from
their classical Boolean counterparts (classical logic gates such as
AND or OR are clearly irreversible: reading
11 at the output of the OR gate does not provide enough
information to determine the input which could be either (0,1)(0,1) or
(1,0)(1,0) or (1,1)(1,1)). Quantum arithmetic must be built from
reversible logical components. It has been shown that reversible
networks (a prerequisite for quantum computation) require some
additional memory for storing intermediate results \[ [6](https://arxiv.org/html/quant-ph/9511018v1#bib.bib6 ""), [7](https://arxiv.org/html/quant-ph/9511018v1#bib.bib7 "")\].
Hence the art of building quantum networks is often reduced to
minimising this auxiliary memory or to optimising the trade–off
between the auxiliary memory and a number of computational steps
required to complete a given operation in a reversible way.

In this paper we provide an explicit construction of several
elementary quantum networks. We focus on the space complexity i.e. on the optimal use of the auxiliary memory.
In our constructions, we save memory by reversing some computations
with different computations (rather than with the same computation but
run backwards \[ [7](https://arxiv.org/html/quant-ph/9511018v1#bib.bib7 "")\]). The networks are presented in the
ascending order of complication. We start from a simple quantum
addition, and end up with a modular exponentiation

|     |     |     |     |
| --- | --- | --- | --- |
|  | Ua,N​\|x⟩⊗\|0⟩→\|x⟩⊗\|axmodN⟩,U\_{a,N}\|x\\rangle\\otimes\|0\\rangle\\rightarrow\|x\\rangle\\otimes\|a^{x}\\bmod N\\rangle, |  | (1) |

where aa and NN are predetermined and known parameters.
This particular operation plays an important role in Shor’s quantum
factoring algorithm \[ [3](https://arxiv.org/html/quant-ph/9511018v1#bib.bib3 "")\] and seems to be its most demanding
part.

The structure of the paper is as follows: in Section [II](https://arxiv.org/html/quant-ph/9511018v1#S2 "II Basic concepts ‣ Quantum Networks for Elementary Arithmetic Operations") we
define some basic terms and describe methods of reversing some types
computation, in Section [III](https://arxiv.org/html/quant-ph/9511018v1#S3 "III Network architecture ‣ Quantum Networks for Elementary Arithmetic Operations") we provide a detailed
description of the selected quantum networks and in
Section [IV](https://arxiv.org/html/quant-ph/9511018v1#S4 "IV Network complexity ‣ Quantum Networks for Elementary Arithmetic Operations") we discuss their complexity.

## II Basic concepts

For completeness let us start with some basic definitions. A quantum
network is a quantum computing device consisting of quantum logic
gates whose computational steps are synchronised in time. The outputs
of some of the gates are connected by wires to the inputs of others.
The size of the network is its number of gates. The size of the input
of the network is its number of input qubits i.e. the qubits
that are prepared appropriately at the beginning of each computation
performed by the network. Inputs are encoded in binary form in the
computational basis of selected qubits often called a quantum
register, or simply a register. For instance, the binary
form of number 66 is 110110 and loading a quantum register with this
value is done by preparing three qubits in state \|1⟩⊗\|1⟩⊗\|0⟩\|1\\rangle\\otimes\|1\\rangle\\otimes\|0\\rangle. In the following we use a more compact
notation: \|a⟩\|a\\rangle stands for the direct product \|an⟩⊗\|an−1⟩​…​\|a1⟩⊗\|a0⟩\|a\_{n}\\rangle\\otimes\|a\_{n-1}\\rangle\\ldots\|a\_{1}\\rangle\\otimes\|a\_{0}\\rangle which
denotes a quantum register prepared with the value a=20​a0+21​a1+…​2n​ana=2^{0}a\_{0}+2^{1}a\_{1}+\\ldots 2^{n}a\_{n}. Computation is defined as a unitary evolution of the
network which takes its initial state “input” into some final state
“output”.

Both the input and the output can be encoded in several registers.
Even when ff is a one–to–one map between the input xx and the
output f⁡(x)f(x) and the operation can be formally written as a unitary
operator UfU\_{f}

|     |     |     |     |
| --- | --- | --- | --- |
|  | Uf​\|x⟩→\|f⁡(x)⟩,U\_{f}\|x\\rangle\\rightarrow\|f(x)\\rangle, |  | (2) |

we may still need an auxiliary register to store the intermediate
data. When ff is not a bijection we have to use an additional
register in order to guarantee the unitarity of computation. In this
case the computation must be viewed as a unitary transformation UfU\_{f}
of (at least) two registers

|     |     |     |     |
| --- | --- | --- | --- |
|  | Uf\|x,0⟩→\|x,f(x)⟩,U\_{f}\|x,0\\rangle\\rightarrow\|x,f(x)\\rangle, |  | (3) |

where the second register is of appropriate size to accommodate
f⁡(x)f(x).

As an example, consider a function fa,N:x→a​xmodNf\_{a,N}:x\\rightarrow ax\\bmod N.
A quantum network that effects this computation takes the value xx
from a register and multiplies it by a parameter aa modulo another
parameter NN. If aa and NN are coprime, the function is bijective
in the interval {0,1,…,N−1}\\{0,1,\\ldots,N-1\\}, and it is possible to
construct a network that writes the answer into the same register
which initially contained the input xx (as in the equation
( [2](https://arxiv.org/html/quant-ph/9511018v1#S2.E2 "In II Basic concepts ‣ Quantum Networks for Elementary Arithmetic Operations"))). This can be achieved by introducing an auxiliary
register and performing

|     |     |     |     |
| --- | --- | --- | --- |
|  | Ua,N\|x,0⟩→\|x,axmodN⟩.U\_{a,N}\|x,0\\rangle\\rightarrow\|x,ax\\bmod N\\rangle. |  | (4) |

Then we can precompute a−1modNa^{-1}\\bmod N, the inverse of aa modulo NN
(this can be done classically in an efficient way using Euclid’s
algorithm \[ [8](https://arxiv.org/html/quant-ph/9511018v1#bib.bib8 "")\]), and, by exchanging the two registers and
applying Ua−1modN,N−1U^{-1}\_{a^{-1}\\bmod N,N} to the resulting state, we obtain

|     |     |     |     |
| --- | --- | --- | --- |
|  | Ua−1modN,N−1S\|x,axmodN⟩→Ua−1modN,N−1\|axmodN,x⟩→\|axmodN,0⟩,U^{-1}\_{a^{-1}\\bmod N,N}S\|x,ax\\bmod N\\rangle\\rightarrow U^{-1}\_{a^{-1}\\bmod N,N}\|ax\\bmod N,x\\rangle\\rightarrow\|ax\\bmod N,0\\rangle, |  | (5) |

where SS is a unitary operation that exchanges the states of the two
registers. Thus,

|     |     |     |     |
| --- | --- | --- | --- |
|  | Ua−1modN,N−1SUa,N\|x,0⟩→\|axmodN,0⟩U^{-1}\_{a^{-1}\\bmod N,N}SU\_{a,N}\|x,0\\rangle\\rightarrow\|ax\\bmod N,0\\rangle |  | (6) |

effectively performs

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|x⟩→\|f⁡(x)⟩\|x\\rangle\\rightarrow\|f(x)\\rangle |  | (7) |

where the second register is treated as an internal part of the
network (temporary register).

## III Network architecture

Quantum networks for basic arithmetic operations can be constructed in
a number of different ways. Although almost any non-trivial quantum
gate operating on two or more qubits can be used as an elementary
building block of the networks \[ [9](https://arxiv.org/html/quant-ph/9511018v1#bib.bib9 "")\] we have decided to use the
three gates described in Fig. [1](https://arxiv.org/html/quant-ph/9511018v1#S6.F1 "Figure 1 ‣ Quantum Networks for Elementary Arithmetic Operations"), hereafter refered to
as elementary gates. None of these gates is universal for
quantum computation, however, they suffice to build any Boolean
functions as the Toffoli gate alone suffices to support any classical reversible computation. The NOT and the
Control–NOT gates are added for convenience (they can be
easily obtained from the Toffoli gates).

### III.1 Plain adder

The addition of two registers \|a⟩\|a\\rangle and \|b⟩\|b\\rangle is probably
the most basic operation, in the simplest form it can be written as

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|a,b,0⟩→\|a,b,a+b⟩.\|a,b,0\\rangle\\rightarrow\|a,b,a+b\\rangle. |  | (8) |

Here we will focus on a slightly more complicated (but more useful)
operation that rewrites the result of the computation into the one of
the input registers , i.e.

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|a,b⟩→\|a,a+b⟩,\|a,b\\rangle\\rightarrow\|a,a+b\\rangle, |  | (9) |

As one can reconstruct the input (a,b)(a,b) out of the output (a,a+b)(a,a+b),
there is no loss of information, and the calculation can be
implemented reversibly. To prevent overflows, the second register
(initially loaded in state \|b⟩\|b\\rangle) should be sufficiently large,
i.e. if both aa and bb are encoded on nn qubits, the second
register should be of size n+1n+1. In addition, the network described
here also requires a temporary register of size n−1n-1, initially in
state \|0⟩\|0\\rangle, to which the carries of the addition are
provisionally written (the last carry is the most significant bit of
the result and is written in the last qubit of the second register).

The operation of the full addition network is illustrated in
Fig. [2](https://arxiv.org/html/quant-ph/9511018v1#S6.F2 "Figure 2 ‣ Quantum Networks for Elementary Arithmetic Operations") and can be understood as follows:

- •


We compute the most significant bit of the result a+ba+b. This step
requires computing all the carries cic\_{i} through the relation ci←aic\_{i}\\leftarrow a\_{i}ANDbib\_{i}ANDci−1c\_{i-1},
where aia\_{i}, bib\_{i} and cic\_{i} represent the iith qubit of the first,
second and temporary (carry) register respectively. Fig. [3](https://arxiv.org/html/quant-ph/9511018v1#S6.F3 "Figure 3 ‣ Quantum Networks for Elementary Arithmetic Operations") i)
illustrates the sub–network that effects the carry calculation.

- •


Subsequently we reverse all these operations (except for the
last one which computed the leading bit of the result) in order to
restore every qubit of the temporary register to its initial state
\|0⟩\|0\\rangle. This enables us to reuse the same temporary register,
should the problem, for example, require repeated additions. During
the resetting process the other nn qubits of the result are
computed through the relation bi←aib\_{i}\\leftarrow a\_{i}XORbib\_{i}XORci−1c\_{i-1} and stored in the second register.
This operation effectively computes the nn first digits of the sum
(the basic network that performs the summation of three qubits
modulo 22 is depicted in Fig. [3](https://arxiv.org/html/quant-ph/9511018v1#S6.F3 "Figure 3 ‣ Quantum Networks for Elementary Arithmetic Operations") ii).)


If we reverse the action of the above network (i.e. if we
apply each gate of the network in the reversed order) with the input
(a,b)(a,b), the output will produce (a,a−b)(a,a-b) when a≥ba\\geq b. When a<ba<b,
the output is (a,2n+1−(b−a))(a,2^{n+1}-(b-a)), where n+1n+1 is the size of the
second register. In this case the most significant qubit of the second
register will always contain 11 . By checking this “overflow bit”
it is therefore possible to compare the two numbers aa and bb; we
will use this operation in the network for modular addition.

### III.2 Adder modulo NN

A slight complication occurs when one attempts to build a network that
effects

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|a,b⟩→\|a,a+bmodN⟩,\|a,b\\rangle\\rightarrow\|a,a+b\\bmod N\\rangle, |  | (10) |

where 0≤a,b<N0\\leq a,b<N. As in the case of the plain adder, there is no
a priori violation of unitarity since the input (a,b)(a,b) can be
reconstructed from the output (a,a+bmodN)(a,a+b\\bmod N), when 0≤a,b<N0\\leq a,b<N
(as it will always be the case). Our approach is based on taking the
output of the plain adder network, and subtracting NN, depending on
whether the value a+ba+b is bigger or smaller than NN. The method,
however, must also accomodate a superposition of states for which some
values a+ba+b are bigger than NN and some smaller than NN.

Fig. [4](https://arxiv.org/html/quant-ph/9511018v1#S6.F4 "Figure 4 ‣ Quantum Networks for Elementary Arithmetic Operations") illustrates the various steps needed to implement
modular addition. The first adder performs a plain addition on the
state \|a,b⟩\|a,b\\rangle returning \|a,a+b⟩\|a,a+b\\rangle; the first register is
then swapped with a temporary register formerly loaded with NN, and a
subtractor (i.e. an adder whose network is run backwards) is
used to obtain the state \|N,a+b−N⟩\|N,a+b-N\\rangle. At this stage the most
significant bit of the second register indicates whether or not an
overflow occurred in the subtraction, i.e. whether a+ba+b is
smaller than NN or not. This information is “copied” into a
temporary qubit \|t⟩\|t\\rangle (initially prepared in state \|0⟩\|0\\rangle)
through the Control–NOT gate. Conditionally on the
value of this last qubit \|t⟩\|t\\rangle, NN is added back to the second
register, leaving it with the value a+bmodNa+b\\bmod N. This is done by
either leaving the first register with the value NN (in case of
overflow), or resetting it to 00 (if there is no overflow) and then
using a plain adder. After this operation, the value of the first
register can be reset to its original value and the first and the
temporary register can be swapped back, leaving the first two
registers in state \|a,a+bmodN⟩\|a,a+b\\bmod N\\rangle and the temporary one in
state \|0⟩\|0\\rangle. At this point the modular addition has been
computed, but some information is left in the temporary qubit
\|t⟩\|t\\rangle that recorded the overflow of the subtraction. This
temporary qubit cannot be reused in a subsequent modular addition,
unless it is coherently reset to zero. The last two blocks of the
network take care of this resetting: first the value in the first
register (=a=a) is subtracted from the value in the second (=a+bmodN=a+b\\bmod N) yielding a total state \|a,(a+bmodN)−a⟩\|a,(a+b\\bmod N)-a\\rangle. As
before, the most significant bit of the second register contains the
information about the overflow in the subtraction, indicating whether
or not the value NN was subtracted after the third network. This bit
is then used to reset the temporary bit \|t⟩\|t\\rangle to \|0⟩\|0\\rangle
through a second Control–NOT gate. Finally the last
subtraction is undone, returning the two registers to the state
\|a,a+bmodN⟩\|a,a+b\\bmod N\\rangle.

### III.3 Controlled–multiplier modulo NN

Function fa,N​(x)=a​xmodNf\_{a,N}(x)=ax\\bmod N can be implemented by repeated
conditional additions (modulo NN): a​x=20​a​x0+21​a​x1+…​2n−1​a​xn−1ax=2^{0}ax\_{0}+2^{1}ax\_{1}+\\ldots 2^{n-1}ax\_{n-1}. Starting from a register initially in the state
\|0⟩\|0\\rangle, the network consists simply of nn stages in which the
value 2i​a2^{i}a is added conditionally, depending on the state of the
qubit \|xi⟩\|x\_{i}\\rangle. Fig. [5](https://arxiv.org/html/quant-ph/9511018v1#S6.F5 "Figure 5 ‣ Quantum Networks for Elementary Arithmetic Operations") shows the corresponding
network; it is slightly complicated by the fact that we want the
multiplication to be effected conditionally upon the value of some
external qubit \|c⟩\|c\\rangle, namely, we want to implement

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|c;x,0⟩→{\|c;x,a×xmodN⟩if \|c⟩=\|1⟩\|c;x,x⟩if \|c⟩=\|0⟩\|c;x,0\\rangle\\rightarrow\\left\\{\\begin{array}\[\]{ll}\|c;x,a\\times x\\bmod N\\rangle&\\mbox{if $\|c\\rangle=\|1\\rangle$}\\\<br>\|c;x,x\\rangle&\\mbox{if $\|c\\rangle=\|0\\rangle$}\\end{array}\\right. |  | (11) |

To account for this fact at the iith modular addition stage the first
register is loaded with the value 2i​a2^{i}a if
\|c,xi⟩=\|1,1⟩\|c,x\_{i}\\rangle=\|1,1\\rangle and with value 00 otherwise.
This is done by applying the Toffoli gate to the control qubits
\|c⟩\|c\\rangle and \|xi⟩\|x\_{i}\\rangle and the appropriate target
qubit in the register; the gate is applied each time value “11”
appears in the binary form of the number 2i​a2^{i}a.

Resetting the register to its initial state is done by applying the
same sequence of the Toffoli gates again (the order of the gates is
irrelevant as they act on different target qubits). If
\|c⟩=\|0⟩\|c\\rangle=\|0\\rangle only 00 values are added at each of the nn
stages to the result register giving state \|c;x,0⟩\|c;x,0\\rangle. Since we
want the state to be \|c;x,x⟩\|c;x,x\\rangle we copy the content of the input
register to the result register if \|c⟩=\|0⟩\|c\\rangle=\|0\\rangle. This last
operation is performed by the rightmost elements of the network of
Fig. [5](https://arxiv.org/html/quant-ph/9511018v1#S6.F5 "Figure 5 ‣ Quantum Networks for Elementary Arithmetic Operations"). The conditional copy is implemented using an
array of Toffoli gates.

### III.4 Exponentiation Modulo N

A reversible network that computes the function fa,N​(x)=axmodNf\_{a,N}(x)=a^{x}\\bmod N can now be designed using the previous constructions. Notice first
that axa^{x} can be written as ax=a20​x0⋅a21​x1⋅…​a2m−1​xm−1a^{x}=a^{2^{0}x\_{0}}\\cdot a^{2^{1}x\_{1}}\\cdot\\ldots a^{2^{m-1}x\_{m-1}}, thus modular exponentiation can be
computed by setting initially the result register to \|1⟩\|1\\rangle, and
successively effecting nn multiplications by a2ia^{2^{i}} (modulo NN)
depending on the value of the qubit \|xi⟩\|x\_{i}\\rangle; if xi=1x\_{i}=1, we want
the operation

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|a20​x0+…​2i−1​xi−1,0⟩→\|a20​x0+…​2i−1​xi−1,a20​x0+…​2i−1​xi−1⋅a2i⟩\|a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}},0\\rangle\\rightarrow\|a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}},a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}}\\cdot a^{2^{i}}\\rangle |  | (12) |

to be performed, otherwise, when
xi=0x\_{i}=0 we just require

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|a20​x0+…​2i−1​xi−1,0⟩→\|a20​x0+…​2i−1​xi−1,a20​x0+…​2i−1​xi−1⟩.\|a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}},0\\rangle\\rightarrow\|a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}},a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}}\\rangle. |  | (13) |

Note that in both cases the result can be written as
\|a20​x0+…​2i−1​xi−1,a20​x0+…​2i​xi⟩\|a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}},a^{2^{0}x\_{0}+\\ldots 2^{i}x\_{i}}\\rangle.
To avoid an accumulation of intermediate data in the memory of the
quantum computer, a particular care should be taken to erase the
partial information generated. This is done, as explained in
Sect. [II](https://arxiv.org/html/quant-ph/9511018v1#S2 "II Basic concepts ‣ Quantum Networks for Elementary Arithmetic Operations"), by running backwards a controlled multiplication
network with the value a−2imodNa^{-2^{i}}\\bmod N. This quantity can be
efficiently precomputed in a classical way \[ [8](https://arxiv.org/html/quant-ph/9511018v1#bib.bib8 "")\].
Fig. [6](https://arxiv.org/html/quant-ph/9511018v1#S6.F6 "Figure 6 ‣ Quantum Networks for Elementary Arithmetic Operations") shows the network for a complete modular
exponentiation. It is made out of mm stages; each stage performs the
following sequence of operations:

|     |     |     |     |
| --- | --- | --- | --- |
|  | \|a20​x0+…​2i−1​xi−1,0⟩→(multiplication)\|a20​x0+…​2i−1​xi−1,a20​x0+…​2i​xi⟩→(swapping)\|a20​x0+…​2i​xi,a20​x0+…​2i−1​xi−1⟩→(resetting)\|a20​x0+…​2i​xi,0⟩\\begin{array}\[\]{ll}\|a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}},0\\rangle\\rightarrow&\\hskip 56.9055pt\\mbox{\\small(multiplication)}\\\<br>\\hskip 56.9055pt\|a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}},a^{2^{0}x\_{0}+\\ldots 2^{i}x\_{i}}\\rangle\\rightarrow&\\hskip 56.9055pt\\mbox{\\small(swapping)}\\\<br>\\hskip 56.9055pt\|a^{2^{0}x\_{0}+\\ldots 2^{i}x\_{i}},a^{2^{0}x\_{0}+\\ldots 2^{i-1}x\_{i-1}}\\rangle\\rightarrow&\\hskip 56.9055pt\\mbox{\\small(resetting)}\\\<br>\\hskip 56.9055pt\|a^{2^{0}x\_{0}+\\ldots 2^{i}x\_{i}},0\\rangle\\end{array} |  | (14) |

## IV Network complexity

The size of the described networks depends on the size of their input
nn. The number of elementary gates in the plain adder, the modular
addition and the controlled–modular addition network scales linearly
with nn. The controlled modular multiplication contains nn
controlled modular additions, and thus requires of the order of n2n^{2}
elementary operations. Similarly the network for exponentiation
contains of the order of nn controlled modular multiplications and
the total number of elementary operations is of the order of n3n^{3}.
The multiplicative overhead factor in front depends very much on what
is considered to be an elementary gate. For example, if we choose the
Control–NOT to be our basic unit then the Toffoli gate
can be simulated by 66 Control–NOT gates  \[ [10](https://arxiv.org/html/quant-ph/9511018v1#bib.bib10 "")\].

Let us have a closer look at the memory requirements for the modular
exponentiation; this can help to asses the difficulty of quantum
factorisation. We set nn to be the number of bits needed to encode
the parameter NN of Eq. ( [1](https://arxiv.org/html/quant-ph/9511018v1#S1.E1 "In I Introduction ‣ Quantum Networks for Elementary Arithmetic Operations")). In Shor’s algorithm, xx can
be as big as N2N^{2}, and therefore the register needed to encode it
requires up to 2​n2n qubits. Not counting the two input registers and
an additional bit to store the most significant digit of the result,
the plain adder network requires an extra (n−1)(n-1)–qubit temporary
register for storing temporary (carry) qubits. This register is reset
to its initial value, \|0⟩\|0\\rangle, after each operation of the network
and can be reused later. The modular addition network, in addition to
the temporary qubit needed to store overflows in subtractions,
requires another nn–qubit temporary register; in total this makes
two nn–qubit temporary registers for modular addition. Controlled
modular multiplication is done by repeated modular additions, and
requires three temporary nn–qubit registers: one for its own
operation and two for the modular addition (controlled modular
multiplication also requires a temporary qubit used by the modular
addition network). Finally, the network for exponentiation needs four
temporary nn–qubit registers, one for its own operation and three
for the controlled modular multiplication (plus an additional qubit
used by the modular addition). Altogether the total number of qubits
required to perform the first part of the factorisation algorithm is
7​n+17n+1, where 2​n2n qubits are used to store xx, nn qubits store the
result axmodNa^{x}\\bmod N and 4​n+14n+1 qubits are used as temporary qubits.

The networks presented in this paper are by no means the only or the
most optimal ones. There are many ways to construct operation such as
axmodNa^{x}\\bmod N, given parameters aa and NN. Usually a dedicated
network composed of several sub–units does not have to be a simple
sum of the sub–units. In the modular exponentiation, for example, it
is relatively easy to reduce the memory i.e. the constant
overhead factor (77 in our case) by noting that the first register in
the plain adder network always stores specific classical values:
either 00 and NN. The same holds for the temporary register in the
adder modulo NN which always stores either 00 and 2i​amodN2^{i}a\\bmod N.
There is no need to use a full quantum register for this: a classical
register plus a single qubit (that keeps track of the entanglement)
are sufficient. This reduces the number of qubits to 5​n+25n+2. One
further register can be removed by using the addition network that
does not require a temporary register \[ [11](https://arxiv.org/html/quant-ph/9511018v1#bib.bib11 "")\]; the trick is to
use the nn–bit Toffoli gates to add nn–bit numbers. If the
difficulty of the practical implementations of the nn–bit Toffoli
gates is comparable to that of the regular Toffoli gate, then this can
be a good way of saving memory. All together the number of qubits can
be reduced from 7​n+17n+1 to 4​n+34n+3. This means that apart from the
register storing xx and another one storing axmodNa^{x}\\bmod N we need
additional n+3n+3 temporary qubits to perform quantum modular
exponentiation in Shor’s algorithm. The required memory grows only as
a linear function of the size of NN.

## V Conclusion

In this paper we have explicitly constructed quantum networks
performing elementary arithmetic operations including the modular
exponentiation which dominates the overall time and memory complexity
in Shor’s quantum factorisation algorithm. Our network for the modular
exponentiation achieves only a linear growth of auxiliary memory by
exploiting the fact that fa,N​(x)=a​xmodNf\_{a,N}(x)=ax\\bmod N is a bijection (when
aa and NN are coprime) and can be made reversible by simple
auxiliary computations. In more practical terms our results indicate
that with the “trapped ions computer” \[ [12](https://arxiv.org/html/quant-ph/9511018v1#bib.bib12 "")\] about 2020 ions
suffice (at least in principle) to factor N=15N=15. Needless to say, the
form of the actual network that will be used in the first quantum
computer will greatly depend on the type of technology employed; the
notion of an optimal network is architecture dependent and any further
optimisation has to await future experimental progress.

## VI Acknowledgments

V. V. thanks the Royal Society for the vacation scholarship which
enabled him to undertake the research project on the subject of the
paper. A. B. acknowledges the financial support of the Berrows
Fund at Lincoln College, Oxford.

The authors would like to thank D. Deutsch, D. DiVincenzo,
S. Gardiner, H.J. Kimble, P.L. Knight, E. Knill, T. Pellizzari, and
P. Zoller for useful discussions.

## References

- \[1\] D. Deutsch, Proc. R. Soc. Lond. A 400, 97 (1985).

- \[2\] D. Deutsch and R. Jozsa, Proc. R. Soc. Lond. A 439, 553 (1992); E. Bernstein and U. Vazirani, in Proc. 25th
ACM Symposium on the Theory of Computation, 11 (1993);
D.S. Simon, Proceedings of the 35th Annual Symposium on the
Foundations of Computer Science, edited by S. Goldwasser (IEEE
Computer Society Press, Los Alamitos, CA), 16 (1994);

- \[3\] P.W. Shor, in Proceedings of the 35th Annual
Symposium on the Theory of Computer Science, edited by S.
Goldwasser (IEEE Computer Society Press, Los Alamitos, CA), p.124
(1994).

- \[4\] D. Deutsch, The Fabric of Reality
(Viking–Penguin Publishers, London, in print).

- \[5\] D. Deutsch, Proc. R. Soc. Lond. A 425, 73 (1989).

- \[6\] R. Landauer, IBM J. Res. Dev. 5, 183 (1961);
C.H Bennett, IBM J. Res. Dev. 32, 16 (1988); T. Toffoli,
Math. Systems Theory 14, 13 (1981).

- \[7\] C.H. Bennett, SIAM J. Comput. 18(4), 766 (1989).

- \[8\] D.E. Knuth, The Art of Computer Programming, Volume 2:
Seminumerical Algorithms (Addison-Wesley, New York, 1981).

- \[9\] A. Barenco, Proc. R. Soc. Lond. A, 449, 679
(1995); T. Sleator and H. Weinfurter, Phys. Rev. Lett. 74 4087
(1995); D. Deutsch, A. Barenco and A. Ekert, Proc. R. Soc. Lond. A
449 669 (1995); S. Lloyd, Phys. Rev. Lett. 75, 346
(1995).

- \[10\] A. Barenco, C.H. Bennett, R. Cleve, D.P. DiVicenzo,
N. Margolus, P. Shor, T. Sleator, J. Smolin and H. Weinfurter,
Phys. Rev. A 52, 3457 (1995).

- \[11\] S.A. Gardiner, T. Pellizzari and P. Zoller, private
communication.

- \[12\] J.I. Cirac and P. Zoller, Phys. Rev. Lett 74,
4091 (1995).


![Refer to caption](https://arxiv.org/html/quant-ph/9511018v1/elembm.png)

Figure 1: Truth tables and graphical representations of the elementary
quantum gates used for the construction of more complicated quantum
networks. The control qubits are graphically represented by a dot,
the target qubits by a cross. i) NOT operation. ii)
Control–NOT. This gate can be seen as a “copy
operation” in the sense that a target qubit (bb) initially in the
state 00 will be after the action of the gate in the same state as
the control qubit. iii) Toffoli gate. This gate can also be seen as
a Control–control–NOT: the target bit (cc) undergoes
a NOT operation only when the two controls (aa and
bb) are in state 11.

![Refer to caption](https://arxiv.org/html/quant-ph/9511018v1/adder.png)

Figure 2: Plain adder network. In a first step, all the carries are calculated
until the last carry gives the most significant digit of the result.
Then all these operations apart from the last one are undone in
reverse order, and the sum of the digits is performed
correspondingly. Note the position of a thick black bar on the right
or left hand side of basic carry and sum networks. A network with a
bar on the left side represents the reversed sequence of elementary
gates embeded in the same network with the bar on the right side.

![Refer to caption](https://arxiv.org/html/quant-ph/9511018v1/carrysum.png)

Figure 3: Basic carry and sum operations for the plain addition network. i)
the carry operation (note that the carry operation perturbs the
state of the qubit bb). ii) the sum operation.

![Refer to caption](https://arxiv.org/html/quant-ph/9511018v1/modadd.png)

Figure 4: Adder modulo NN. The first and the second network add aa and bb
together and then subtract NN. The overflow is recorded into the
temporary qubit \|t⟩\|t\\rangle. The next network calculates (a+b)modN(a+b)\\bmod N. At this stage we have extra information about the value
of the overflow stored in \|t⟩\|t\\rangle. The last two blocks restore
\|t⟩\|t\\rangle to \|0⟩\|0\\rangle. The arrow before the third plain adder
means that the first register is set to \|0⟩\|0\\rangle if the value of
the temporary qubit \|t⟩\|t\\rangle is 11 and is otherwise left
unchanged (this can be easily done with Control–NOT
gates, as we know that the first register is in the state
\|N⟩\|N\\rangle). The arrow after the third plain adder resets the first
register to its original value (here \|N⟩\|N\\rangle). The significance
of the thick black bars is explained in the caption of
Fig. [2](https://arxiv.org/html/quant-ph/9511018v1#S6.F2 "Figure 2 ‣ Quantum Networks for Elementary Arithmetic Operations").

![Refer to caption](https://arxiv.org/html/quant-ph/9511018v1/cmult.png)

Figure 5: Controlled multiplication modulo NN consists of consecutive modular
additions of 2i​a2^{i}a or 00 depending on the values of cc and xix\_{i}.
The operation before the iith modular adder consists in storing
2i−1​a2^{i-1}a or 00 in the temporary register depending on whether
\|c,xi⟩=\|1,1⟩\|c,x\_{i}\\rangle=\|1,1\\rangle or not respectively. Immediately after
the addition has taken place, this operation is undone. At the end,
we copy the content of the input register in the result register
only if \|c⟩=\|0⟩\|c\\rangle=\|0\\rangle, preparing to account for the fact
that the final output state should be \|c;x,x⟩\|c;x,x\\rangle and not
\|c;x,0⟩\|c;x,0\\rangle when c=0c=0. The signification of the thick black
bars is given in the caption of Fig. [2](https://arxiv.org/html/quant-ph/9511018v1#S6.F2 "Figure 2 ‣ Quantum Networks for Elementary Arithmetic Operations").

![Refer to caption](https://arxiv.org/html/quant-ph/9511018v1/modexp.png)

Figure 6: Modular exponentiation consists of successive modular
multiplications by a2ia^{2^{i}}. The even networks perform the reverse
control modular multiplication by inverse of a2imodNa^{2^{i}}\\bmod N thus
resetting one of the registers to zero and freeing it for the next
control modular multiplication. The signification of the thick black
bars is given in the caption of Fig. [2](https://arxiv.org/html/quant-ph/9511018v1#S6.F2 "Figure 2 ‣ Quantum Networks for Elementary Arithmetic Operations").

Experimental support, please
[view the build logs](https://arxiv.org/html/quant-ph/quant-ph/9511018v1/__stdout.txt)
for errors. Generated by
[L\\
A\\
T\\
Exml![[LOGO]](<Base64-Image-Removed>)](https://math.nist.gov/~BMiller/LaTeXML/).


## Instructions for reporting errors

We are continuing to improve HTML versions of papers, and your feedback helps enhance accessibility and mobile
support. To report errors in the HTML that will help us improve conversion and rendering, choose any of the
methods listed below:

- Click the "Report Issue" () button, located in the page header.

**Tip:** You can select the relevant text first, to include it in your report.

Our team has already identified [the following issues](https://github.com/arXiv/html_feedback/issues). We appreciate your time reviewing and reporting rendering errors we
may not have found yet. Your efforts will help us improve the HTML versions for all readers, because disability
should not be a barrier to accessing research. Thank you for your continued support in championing open access for
all.

Have a free development cycle? Help support accessibility at arXiv! Our collaborators at LaTeXML maintain a [list of packages that need conversion](https://github.com/brucemiller/LaTeXML/wiki/Porting-LaTeX-packages-for-LaTeXML), and welcome [developer contributions](https://github.com/brucemiller/LaTeXML/issues).

We gratefully acknowledge support from
our **major funders**,
[**member institutions**](https://info.arxiv.org/about/ourmembers.html), ,
and all contributors.


[About](https://info.arxiv.org/about)· [Help](https://info.arxiv.org/help)· [Contact](https://info.arxiv.org/help/contact.html)· [Subscribe](https://info.arxiv.org/help/subscribe)· [Copyright](https://info.arxiv.org/help/license/index.html)· [Privacy](https://info.arxiv.org/help/policies/privacy_policy.html)· [Accessibility](https://info.arxiv.org/help/web_accessibility.html)· [Operational Status (opens in new tab)](https://status.arxiv.org/)

Major funding support from

[![Simons Foundation](https://arxiv.org/static/base/1.0.1/images/funders/simons-foundation.png)](https://www.simonsfoundation.org/)[![Simons Foundation International](https://arxiv.org/static/base/1.0.1/images/funders/simons-foundation-international.png)](https://www.sfi.org.bm/)[![Schmidt Sciences](https://arxiv.org/static/base/1.0.1/images/funders/schmidt-sciences.png)](https://www.schmidtsciences.org/)