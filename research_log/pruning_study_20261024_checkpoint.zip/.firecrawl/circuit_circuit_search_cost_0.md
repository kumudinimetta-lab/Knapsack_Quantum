Title:

Content selection saved. Describe the issue below:

Description:

![](https://arxiv.org/static/base/1.0.1/images/icons/smileybones-small.svg)arXiv is now an independent nonprofit! [Learn more](https://info.arxiv.org/about) ×

[License: arXiv.org perpetual non-exclusive license](https://info.arxiv.org/help/license/index.html#licenses-available)

arXiv:1908.11291v1 \[cs.DM\] 29 Aug 2019

# Practical implementation of a quantum backtracking algorithm

Simon Martiel
Maxime Remaud

1Atos, Quantum R&D, 78340 Les Clayes-sous-Bois, France

###### Abstract

In previous work, Montanaro presented a method to obtain quantum speedups for backtracking algorithms, a general meta-algorithm to solve constraint satisfaction problems (CSPs). In this work, we derive a space efficient implementation of this method. Assume that we want to solve a CSP with mm constraints on nn variables and that the union of the domains in which these variables take their value is of cardinality dd. Then, we show that the implementation of Montanaro’s backtracking algorithm can be done by using 𝒪⁡(n​log⁡(d))\\mathcal{O}(n\\log{d}) data qubits. We detail an implementation of the predicate associated to the CSP with an additional register of 𝒪⁡(log⁡(m))\\mathcal{O}(\\log{m}) qubits. We explicit our implementation for graph coloring and SAT problems, and present simulation results. Finally, we discuss the impact of the usage of static and dynamic variable ordering heuristics in the quantum setting.

Keywords: Backtracking Algorithm, Quantum Walk, CSP, Graph Coloring, SAT.

## 1 Introduction

_Quantum computing._ Quantum computing is one of the most promising emerging computation technology. Theory promises algorithmic speed ups ranging from quadratic, for unstructured problems, up to exponential for some particular key problems. Besides the some problems such as integer factoring and its obvious applications in cryptology, very few applicable large scale algorithms have been derived or studied. In 2015 especially, Montanaro \[ [22](https://arxiv.org/html/1908.11291v1#bib.bib22 "")\] presented a general method to obtain speedups of backtracking-based algorithms, relying on Belovs’ previous work \[ [5](https://arxiv.org/html/1908.11291v1#bib.bib5 "")\] (merged in \[ [6](https://arxiv.org/html/1908.11291v1#bib.bib6 "")\]). The algorithm uses Quantum Walks, a well developed quantum algorithmic tool intensively studied in the scope of search algorithms \[ [1](https://arxiv.org/html/1908.11291v1#bib.bib1 ""), [2](https://arxiv.org/html/1908.11291v1#bib.bib2 ""), [9](https://arxiv.org/html/1908.11291v1#bib.bib9 ""), [18](https://arxiv.org/html/1908.11291v1#bib.bib18 ""), [20](https://arxiv.org/html/1908.11291v1#bib.bib20 ""), [25](https://arxiv.org/html/1908.11291v1#bib.bib25 ""), [26](https://arxiv.org/html/1908.11291v1#bib.bib26 "")\].

_Constraint satisfaction problems._ CSPs form a very general class of problems, that encompass a large set of practical problems. The most famous examples are the Boolean satisfiability problem (SAT) \[ [17](https://arxiv.org/html/1908.11291v1#bib.bib17 "")\] and the graph coloring problem \[ [21](https://arxiv.org/html/1908.11291v1#bib.bib21 "")\]. Both have applications in many fields, like scheduling \[ [19](https://arxiv.org/html/1908.11291v1#bib.bib19 "")\] or timetabling \[ [12](https://arxiv.org/html/1908.11291v1#bib.bib12 "")\] for graph coloring, and in computer science or artificial intelligence, among others, for SAT (refer to \[ [17](https://arxiv.org/html/1908.11291v1#bib.bib17 "")\] for a wide list of applications of SAT).

CSPs have been widely studied and a well known tool taking advantage of their structure to solve them is backtracking. For example, the DPLL \[ [10](https://arxiv.org/html/1908.11291v1#bib.bib10 ""), [11](https://arxiv.org/html/1908.11291v1#bib.bib11 "")\] backtracking-based algorithm has been introduced in 1962 and is currently the procedure at the basis of some of the most efficient SAT solvers \[ [14](https://arxiv.org/html/1908.11291v1#bib.bib14 ""), [16](https://arxiv.org/html/1908.11291v1#bib.bib16 ""), [27](https://arxiv.org/html/1908.11291v1#bib.bib27 "")\]. Since backtracking algorithms explore a tree whose vertices are partial solutions to the associated CSP \[ [27](https://arxiv.org/html/1908.11291v1#bib.bib27 "")\], one can think of using a quantum walk to obtain a speedup.

_Quantum backtracking._ In 2017, Ambainis and Kokainis \[ [3](https://arxiv.org/html/1908.11291v1#bib.bib3 "")\] have dealt with Montanaro’s algorithm in depth and in 2018, Aono, Nguyen and Shen \[ [4](https://arxiv.org/html/1908.11291v1#bib.bib4 "")\] used these works to speed up the two most efficient forms of enumeration (a lattice algorithm) known. They claim that it affects the security estimates of several lattice-based submissions to the NIST post-quantum standardization process \[ [8](https://arxiv.org/html/1908.11291v1#bib.bib8 "")\]. In turn, Montanaro \[ [24](https://arxiv.org/html/1908.11291v1#bib.bib24 "")\] has presented how to get a quantum speedup of branch-and-bound algorithms by using Ambainis-Kokainis’ work and his own. Thus, Montanaro’s algorithm is of high interest in computing science and cryptography. In 2018, Campbell, Khurana and Montanaro \[ [7](https://arxiv.org/html/1908.11291v1#bib.bib7 "")\] reviewed its complexity when applied to the graph coloring problem and SAT, assuming access to a very large amount of qubits, since they aggressively optimized the circuit depth. The aim of this work is to investigate a memory efficient implementation of this backtracking algorithm, in order to be able to validate the algorithm on small instances via classical emulation.

The paper is organized as follows. Section [2](https://arxiv.org/html/1908.11291v1#S2 "2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") introduces definitions. We discuss the choice of heuristic in section [3](https://arxiv.org/html/1908.11291v1#S3 "3 Variable ordering heuristics ‣ Practical implementation of a quantum backtracking algorithm"). Then, section [4](https://arxiv.org/html/1908.11291v1#S4 "4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm") is about the use of the predicate, how to implement it and how to check some generic constraints. We conclude by presenting some of the results we got for graph coloring, thanks to a simulator, in section [5](https://arxiv.org/html/1908.11291v1#S5 "5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm").

## 2 Preliminaries

Thereafter, we will denote by 𝒫\\mathcal{P} a constraint satisfaction problem defined by a triple ⟨X,D,C⟩\\langle X,D,C\\rangle, where X={x1,…,xn}X=\\{x\_{1},\\dots,x\_{n}\\} is a set of nn variables, D=\[\[1,d\]\]D=\[\\!\[1,d\]\\!\] is a set of dd values and CC is a set of mm constraints. We will also use 𝒟\\mathcal{D} to denote the extended domain D∪{∗}D\\cup\\{\\ast\\} in which each variable can take its value, ∗\\ast standing for "the variable has no value".

Let xx be an assignment of values to the nn variables of a CSP 𝒫\\mathcal{P}. It will be said to be a solution to 𝒫\\mathcal{P} if it verifies all the constraints in CC; complete if ∀xi∈X,xi≠∗\\forall x\_{i}\\in X,~x\_{i}\\neq\\ast, partial otherwise; valid if it is partial and can be extended to a solution; invalid if it is partial and not a solution.

### 2.1 Backtracking algorithm

A standard approach for solving a CSP 𝒫\\mathcal{P} is the technique of backtracking. For this, we assume that we have access to a predicate PP which can receive an assignment (complete or partial) of values xx as argument and returns "true" if xx is a solution, "indeterminate" if it is valid, "false" otherwise. We also assume access to a heuristic hh which specifies which variable should be instantiated next. The general algorithm is presented as algorithm [1](https://arxiv.org/html/1908.11291v1#alg1 "Algorithm 1 ‣ 2.1 Backtracking algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm").

Algorithm 1 General backtracking algorithm

1:

An assignment of values xx, access to h:𝒟→\[\[1,n\]\]h:\\mathcal{D}\\rightarrow\[\\!\[1,n\]\\!\] and to P:𝒟→{t​r​u​e,i​n​d​e​t​e​r​m​i​n​a​t​e,f​a​l​s​e}P:\\mathcal{D}\\rightarrow\\{true,indeterminate,false\\}.

2:ifP⁡(x)P(x) is true then output xx and return

3:ifP⁡(x)P(x) is false thenreturn

4:j←h⁡(x)j\\leftarrow h(x)

5:forw∈\[\[1,d\]\]w\\in\[\\!\[1,d\]\\!\]do

6:y←xy\\leftarrow x with the jj-th entry replaced with ww.

7:returnAlgorithm [1](https://arxiv.org/html/1908.11291v1#alg1 "Algorithm 1 ‣ 2.1 Backtracking algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm")(y)(y)

### 2.2 Montanaro’s algorithm

The algorithm presented in \[ [22](https://arxiv.org/html/1908.11291v1#bib.bib22 "")\] is based on a quantum walk on trees. The idea is summarized as follows. Consider a rooted tree 𝒯\\mathcal{T} with TT vertices, labeled r,1,…,T−1r,1,\\dots,T-1, the vertex rr being the root of 𝒯\\mathcal{T}. Hereafter, AA (resp. BB) will denote the set of vertices at an even (resp. odd) distance from rr and x⟶yx\\longrightarrow y will mean that yy is a child of xx in the tree. The quantum walk operates on the space spanned by {\|x⟩;x∈{r}∪\[\[1,T−1\]\]}\\{\\ket{x};~x\\in\\{r\\}\\cup\[\\!\[1,T-1\]\\!\]\\}, and starts in the state \|r⟩\\ket{r}. It is based on a set of diffusion operators DxD\_{x}, where DxD\_{x} is the identity if xx is a solution, otherwise, diffuses on the subspace spanned by {\|x⟩}∪{\|y⟩:x⟶y}\\{\\ket{x}\\}\\cup\\{\\ket{y}:x\\longrightarrow y\\}. A step of the walk consists in applying the operator RB​RAR\_{B}R\_{A}, where :

RA=⨁x∈ADxR\_{A}=\\bigoplus\_{x\\in A}D\_{x} and RB=\|r⟩⟨r\|+⨁x∈BDxR\_{B}=\\outerproduct{r}{r}+\\bigoplus\_{x\\in B}D\_{x}

Thanks to these operators, an algorithm for detecting a solution in a tree can be established (algorithm [2](https://arxiv.org/html/1908.11291v1#alg2 "Algorithm 2 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm")). It is the phase estimation of the operator RB​RAR\_{B}R\_{A} which allows the quantum walker to go through the paths leading to a solution in 𝒯\\mathcal{T}. By applying the detection algorithm to wisely chosen vertices of 𝒯\\mathcal{T}, it is possible to construct an hybrid algorithm for finding a solution (algorithm [3](https://arxiv.org/html/1908.11291v1#alg3 "Algorithm 3 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm")). Montanaro has shown that it finds a solution in time complexity 𝒪⁡(T​n3/2​log⁡(n)​log⁡(1/δ))\\mathcal{O}(\\sqrt{T}n^{3/2}\\log{n}\\log{1/\\delta}) and if there exists a unique solution, it is shown to be 𝒪⁡(T​n​log3⁡n​log⁡(1/δ))\\mathcal{O}(\\sqrt{Tn}\\log^{3}{n}\\log{1/\\delta}). For more details on the quantum walk, refer to \[ [22](https://arxiv.org/html/1908.11291v1#bib.bib22 "")\].

Algorithm 2 Detecting a solution (algorithm 2 of \[ [22](https://arxiv.org/html/1908.11291v1#bib.bib22 "")\])

1:

Operators RAR\_{A}, RBR\_{B}, a failure probability δ\\delta, upper bounds on the depth nn and the number of vertices TT. Let β,γ>0\\beta,\\gamma>0 be universal constants to be determined.

2:RepeatK=⌈γ​log⁡(1/δ)⌉~K=\\lceil\\gamma\\log{1/\\delta}\\rceil times:

3:

Apply phase estimation to the operator RB​RAR\_{B}R\_{A} with precision β/T​n\\beta/\\sqrt{Tn}.

4:If the eigenvalue is 1 then accept

5:If number of acceptances ≥3​K/8\\geq 3K/8thenreturn "Solution exists"

6:else return "No solution"

Algorithm 3 Finding a solution (described in subsection 2.1 of \[ [22](https://arxiv.org/html/1908.11291v1#bib.bib22 "")\])

1:

Apply algorithm [2](https://arxiv.org/html/1908.11291v1#alg2 "Algorithm 2 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") to the entire tree.

2:If it outputs "No solution" thenreturn

3:

Apply algorithm [2](https://arxiv.org/html/1908.11291v1#alg2 "Algorithm 2 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") to each child of the root until one outputs "Solution exists".

4:If this child is a solution then output its label and return

5:else go back to step 3 with this child as the root.

## 3 Variable ordering heuristics

In order to be able to test the algorithm with the means we have, our glance was initially towards the choice of the heuristic. In fact, the largest qubit overhead in the implementation comes from the heuristic implementation, since one has to store variable indexes inside the quantum memory (𝒪⁡(n​log⁡n)\\mathcal{O}(n\\log n) qubits are needed). Moreover, even though the depth overhead of the heuristic is asymptotically negligible compared to the rest of the algorithm, it seems
that for instances of reasonable size, this overhead is not negligible.

Since we are interested in optimizing the number of qubits, we chose to deal with static variable ordering (SVO) heuristics, which can be classically precomputed at the start of the meta-algorithm. This has two main benefits: only 𝒪⁡(n​log⁡d)\\mathcal{O}(n\\log d) data qubits are required to store an assignment and we do not have to produce a reversible implementation of a dynamic variable ordering (DVO) heuristic.

In \[ [7](https://arxiv.org/html/1908.11291v1#bib.bib7 "")\] and \[ [23](https://arxiv.org/html/1908.11291v1#bib.bib23 "")\], the implementation of Montanaro’s algorithm has been optimized in depth and its complexity has been studied considering the use of a DVO heuristic. However, the benefit of implementing a DVO heuristic is unclear in the range of parameters for which it is claimed in \[ [7](https://arxiv.org/html/1908.11291v1#bib.bib7 "")\] that a graph could be colored in one day (up to approximately 150 vertices). Let TT (resp. T′T^{\\prime}) be the number of vertices in the backtracking tree associated with a SVO (resp. DVO) heuristic and cTc\_{T} (resp. cT′c\_{T^{\\prime}}) the number of calls to RB​RAR\_{B}R\_{A} made by Montanaro’s algorithm. If we denote the depth of the overhead due to the implementation of a DVO heuristic by dhd\_{h} and the depth of the operators RAR\_{A} and RBR\_{B} without heuristic by dRd\_{R}, we have that using a dynamic heuristic is more efficient than using a static one if: cT​dR≥cT′​(dR+dh)c\_{T}d\_{R}\\geq c\_{T^{\\prime}}(d\_{R}+d\_{h}), i.e. if cTcT′≥1+dhdR\\frac{c\_{T}}{c\_{T^{\\prime}}}\\geq 1+\\frac{d\_{h}}{d\_{R}}. This is asymptotically true but thanks to the script computing algorithm [3](https://arxiv.org/html/1908.11291v1#alg3 "Algorithm 3 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") complexity to solve graph coloring given in \[ [23](https://arxiv.org/html/1908.11291v1#bib.bib23 "")\], one can compute an estimate of dhdR\\frac{d\_{h}}{d\_{R}} (Fig. [1](https://arxiv.org/html/1908.11291v1#S3.F1 "Figure 1 ‣ 3 Variable ordering heuristics ‣ Practical implementation of a quantum backtracking algorithm")). In the considered range of parameters, we can see that using a DVO heuristic would be better than using a SVO one if cT≥54​cT′c\_{T}\\geq\\frac{5}{4}c\_{T^{\\prime}}. Unfortunately, as far as we know, no DVO heuristic has been proved to verify such a bound. Thus, the time-saving trick allowed by a DVO heuristic may not be obvious and it might be worth using a SVO heuristic for "small" instances.

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/depth.png)Figure 1: dh/dRd\_{h}/d\_{R} according to finalcomplexity.py for graph coloring given in \[ [23](https://arxiv.org/html/1908.11291v1#bib.bib23 "")\].

The modified algorithm for RAR\_{A} and RBR\_{B} is presented as algorithm [4](https://arxiv.org/html/1908.11291v1#alg4 "Algorithm 4 ‣ 3 Variable ordering heuristics ‣ Practical implementation of a quantum backtracking algorithm").

Algorithm 4 Implementation of the operator RAR\_{A}

1:

A basis state \|ℓ⟩​\|v1⟩​…​\|vn⟩∈ℂn+1⊗(ℂd+1)⊗n\\ket{\\ell}\\ket{v\_1}\\dots\\ket{v\_n}\\in\\mathbb{C}^{n+1}\\otimes(\\mathbb{C}^{d+1})^{\\otimes n} corresponding to a partial assignment x1=v1,…,xℓ=vℓx\_{1}=v\_{1},\\dots,x\_{\\ell}=v\_{\\ell}. Ancilla registers : ℋanc\\mathcal{H}\_{\\text{anc}}, ℋchildren\\mathcal{H}\_{\\text{children}}, storing a tuple (a,S)(a,S), where a∈{∗}∪\[d\]a\\in\\{\\ast\\}\\cup\[d\],
S⊆\[d\]S\\subseteq\[d\], initialized to a=∗a=\\ast, S=∅S=\\emptyset.

2:

If ℓ\\ell is odd, swap aa with vℓv\_{\\ell}.

3:

Compute P⁡(x)P(x).

4:

If P⁡(x)P(x) is true, go to step 8.

5:

If a≠∗a\\neq\\ast, subtract 1 from ℓ\\ell.

6:

For each w∈\[d\]w\\in\[d\], if P⁡(v1,…,vℓ,w)P(v\_{1},\\dots,v\_{\\ell},w) is not false, set S=S∪{w}S=S\\cup\\{w\\}.

7:

If ℓ=0\\ell=0, i=ni=n, else, i=1i=1. Perform I−2​\|ϕi,S⟩⟨ϕi,S\|I-2\\outerproduct{\\phi\_{i,S}}{\\phi\_{i,S}} on ℋanc\\mathcal{H}\_{\\text{anc}}.

8:

Revert steps 5 and 4.

9:

Revert steps 2 and 1.

RBR\_{B} is similar, except that: step 1 is preceded by the check "If ℓ=0\\ell=0, return"; "odd" is replaced with "even" in step 1; and the check "If ℓ=0\\ell=0 is removed from step 6.

In order to test our implementation of Montanaro’s algorithm, we used the following SVO heuristics:

- •


Maximum cardinality (MC) \[ [13](https://arxiv.org/html/1908.11291v1#bib.bib13 "")\]: chooses the variable with the largest number of neighbors to be the first one and then orders the others by choosing at each step the most connected one with previously ordered ones;

- •


Maximum degree (MD) \[ [13](https://arxiv.org/html/1908.11291v1#bib.bib13 "")\]: orders the variables in the decreasing order of the size of their neighborhood;

- •


Minimum width (MW) \[ [15](https://arxiv.org/html/1908.11291v1#bib.bib15 "")\]: orders the variables from last to first by choosing at each step the one having the minimum number of neighbors in the subproblem where previously ordered variables have been deleted.


To get an idea of the efficiency of these heuristics compared to the naive one, we emulated Montanaro’s algorithm on the graph coloring problem by replacing algorithm [2](https://arxiv.org/html/1908.11291v1#alg2 "Algorithm 2 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") with a backtracking one in algorithm [3](https://arxiv.org/html/1908.11291v1#alg3 "Algorithm 3 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm"). For fixed values of nn and dd, we generated 1000 random graphs for a varying number of edges, ran algorithm [3](https://arxiv.org/html/1908.11291v1#alg3 "Algorithm 3 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") on these graphs and counted the number of calls to the emulated algorithm in average. The same pattern arose when nn took different values between 10 and 20 and dd between 3 and 6 (Fig. [2](https://arxiv.org/html/1908.11291v1#S3.F2 "Figure 2 ‣ 3 Variable ordering heuristics ‣ Practical implementation of a quantum backtracking algorithm")). We observed that the MD heuristic offered the best (and optimal) results and that MC and MW heuristics led to very similar results. Of course, we can not extrapolate for higher values of nn and dd.

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/heuristics.png)Figure 2: Mean number of calls to algorithm [2](https://arxiv.org/html/1908.11291v1#alg2 "Algorithm 2 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") depending on the number of edges in a graph with 15 nodes and 4 colors.

## 4 Generic implementation

Thereafter, we will use the following notations : ν=⌈log⁡((n+1))⌉\\nu=\\lceil\\log{(n+1)}\\rceil, δ=⌈log⁡((d+1))⌉\\delta=\\lceil\\log{(d+1)}\\rceil and μ=⌈log⁡((m+1))⌉\\mu=\\lceil\\log{(m+1)}\\rceil.

The most straightforward way of implementing the predicate 𝒫\\mathcal{P} is to compute a logical A​N​DAND of the result of the evaluation of each constraint over the current variable assignment. This would lead to a circuit using m+1m+1 work qubits. We present another solution, a quantum counter, using only μ\\mu qubits.

In the case of the partial predicate, an index ℓ\\ell stored in a quantum register indicates that the first ℓ+1\\ell+1 variables have been assigned a value.
Therefore, if is sufficient to check the constraints that depends on at least one variable in {xi1,…,xiℓ}\\{x\_{i\_{1}},\\dots,x\_{i\_{\\ell}}\\}. To find out if a constraint has to be checked, we use a system of comparison of values, one of which is quantum and the other classical. The overall process requires 𝒪⁡(m)\\mathcal{O}(m) additions on ν\\nu qubits.

Similarly, if we apply the detection algorithm to a vertex located at the ℓ\\ell-th level of the backtracking tree, it is unnecessary to check the constraints that depend solely on the variables in {xi1,…,xiℓ−1}\\{x\_{i\_{1}},\\dots,x\_{i\_{\\ell-1}}\\}.

Thanks to these optimizations, the deeper we go in the backtracking tree, the more qubits, quantum gates and time are saved.

### 4.1 How to implement a predicate

Let 𝒫=⟨X,D,C⟩\\mathcal{P}=\\langle X,D,C\\rangle be a CSP. For all i∈\[\[1,n\]\]i\\in\[\\!\[1,n\]\\!\], the binary representation of the value assigned to xix\_{i} is denoted by viv\_{i}. The symbol ∗\\ast will be encoded by 0.

The circuit [3a](https://arxiv.org/html/1908.11291v1#S4.F3.sf1 "In Figure 3 ‣ 4.1 How to implement a predicate ‣ 4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm") is used to verify if an assignment is solution to 𝒫\\mathcal{P}, by checking for all i∈\[\[1,m\]\]i\\in\[\\!\[1,m\]\\!\] the constraint Ci∈CC\_{i}\\in C. An ancillary register cc is used as a counter. In order to check CiC\_{i}, a subroutine depending on the set YiY\_{i} of involved variables in CiC\_{i} will be used and will increase the counter if CiC\_{i} is not verified. Once all the constraints have been checked, the counter will be equal to the number of constraints that are violated. Thus, if it is 0, we set an ancillary qubit to 1. Then, we reverse the CiC\_{i} checking operations to reset the counter to 0. At the end of the circuit, we have in the ancillary qubit the wanted value: P⁡(v1,…,vn)P(v\_{1},\\dots,v\_{n}).

We also want to be able to verify if a partial assignment x1=v1,…,xℓ+1=vℓ+1x\_{1}=v\_{1},\\dots,x\_{\\ell+1}=v\_{\\ell+1} is valid for 𝒫\\mathcal{P}. In this aim, we have to check for all i∈\[\[1,m\]\]i\\in\[\\!\[1,m\]\\!\] the constraint CiC\_{i} if maxxi∈Yi⁡{i}−1≤ℓ\\max\_{x\_{i}\\in Y\_{i}}\\{i\\}-1\\leq\\ell. In the following, ∀i∈\[\[1,m\]\]\\forall i\\in\[\\!\[1,m\]\\!\], MiM\_{i} will denote maxxi∈Yi⁡{i}−1\\max\_{x\_{i}\\in Y\_{i}}\\{i\\}-1 and M0=0M\_{0}=0.

In order to compute the comparison operator, we add a bit (most significant one) to \|ℓ⟩\\ket{\\ell} (call it \|a⟩\\ket{a}, initialize it to \|0⟩\\ket{0}) and use the following procedure ( [3b](https://arxiv.org/html/1908.11291v1#S4.F3.sf2 "In Figure 3 ‣ 4.1 How to implement a predicate ‣ 4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm")):

1. 1.


If Mi−Mi−1>0M\_{i}-M\_{i-1}>0, subtract it from \|ℓ−Mi−1⟩\\ket{\\ell-M\_{i-1}}, otherwise, add it to \|ℓ−Mi−1⟩\\ket{\\ell-M\_{i-1}};

2. 2.


If Mi>ℓM\_{i}>\\ell then some overflow will occur and thus, \|a⟩\\ket{a} will be flipped. Use it to control the CiC\_{i} checking operation.


In circuit [3c](https://arxiv.org/html/1908.11291v1#S4.F3.sf3 "In Figure 3 ‣ 4.1 How to implement a predicate ‣ 4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm"), the ancillary qubit \|a⟩\\ket{a} is set to 1. Thus, the comparison operator will flip \|a⟩\\ket{a} if Mi>ℓM\_{i}>\\ell, i.e. if maxxi∈Yi⁡{i}>ℓ+1\\max\_{x\_{i}\\in Y\_{i}}\\{i\\}>\\ell+1. Thanks to \|a⟩\\ket{a} we can control the CiC\_{i} checking operation. For the rest of the circuit, the idea is the same as the one of the circuit [3a](https://arxiv.org/html/1908.11291v1#S4.F3.sf1 "In Figure 3 ‣ 4.1 How to implement a predicate ‣ 4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm").

Within the scope of an optimization of the depth of our implementation, note that constraint checking operations can easily be parallelized (figure [8](https://arxiv.org/html/1908.11291v1#A0.F8 "Figure 8 ‣ Appendix ‣ Practical implementation of a quantum backtracking algorithm")). We just have to divide CC in k∈ℕk\\in\\mathbb{N} sets of mk\\frac{m}{k} constraints and use a copy of the viv\_{i} registers and a counter for checking each one. This involves using 𝒪⁡(k​n​log⁡n)\\mathcal{O}(kn\\log n) qubits but the depth of the predicate would be divided by kk (we just have then to fan-out/fan-in viv\_{i} registers to kk copies, which can be done in depth 𝒪⁡(log⁡k)\\mathcal{O}(\\log k)).

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/circ1.png)(a) (a)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/circ3.png)(b) (c)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/circ2.png)(c) (b)

Figure 3: Circuit (a) computes P(v1⋯vn)P(v\_{1}\\cdots v\_{n}). If the assignment is a solution, then p=1p=1, else p=0p=0. Circuit (b) is a comparison operator. The operation is done modulo 2ν+12^{\\nu+1}. Circuit (c) computes P⁡(v1,…,vℓ+1)P(v\_{1},\\dots,v\_{\\ell+1}). If the partial assignment is not invalid, then p=1p=1, else p=0p=0.

### 4.2 How to check a constraint

The circuit [4a](https://arxiv.org/html/1908.11291v1#S4.F4.sf1 "In Figure 4 ‣ 4.2 How to check a constraint ‣ 4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm") is used to check if the variable xix\_{i} has been assigned a value (e.g. if the ii-th vertex of a graph GG has been colored). It uses the ancillary register \|c⟩\\ket{c} which contains a bit string corresponding to the counter. Since we have chosen that the value 0 means that vi=∗v\_{i}=\\ast, we just have to check that viv\_{i} is different from 0. The counter is increased by 1 if xix\_{i} has not been assigned a value.

The circuit [4b](https://arxiv.org/html/1908.11291v1#S4.F4.sf2 "In Figure 4 ‣ 4.2 How to check a constraint ‣ 4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm") is used to check if the variables xjx\_{j} and xkx\_{k} have different values (e.g. if the coloring of the edge between the jj-th and the kk-th vertices of a graph is well colored). It uses the ancillary register \|c⟩\\ket{c}, which is increased by 1 if vj⊕vk=0v\_{j}\\oplus v\_{k}=0 (i.e. vj=vkv\_{j}=v\_{k}). For that, we apply a bit-wise XOR to the values of the two variables (the result is stocked in the register of the second value).

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/circ4.png)(a)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/circ5.png)(b)

Figure 4: Circuit (a) checks if the ii-th variable has been assigned a value. If vi=0v\_{i}=0, \|c′⟩=\|c+1⟩\\ket{c'}=\\ket{c+1}, otherwise \|c′⟩=\|c⟩\\ket{c'}=\\ket{c}. Circuit (b) checks if the jj-th and the kk-th variables have different values. If vj=vkv\_{j}=v\_{k}, \|c′⟩=\|c+1⟩\\ket{c'}=\\ket{c+1}, otherwise \|c′⟩=\|c⟩\\ket{c'}=\\ket{c}.

For the specific case of boolean variables, we suggest to represent the bit 0 by the quantum state \|10⟩\\ket{10}, the bit 1 by the quantum state \|11⟩\\ket{11} and the unassigned symbol ∗\\ast by \|00⟩\\ket{00}. In the following, we will denote the left qubit by an LL in exponent and the right qubit by an RR in exponent. Our suggestion stems from the fact that thanks to this choice, it will be simpler to manipulate the variables. The left qubit will allow us to do the negation of the boolean variable without having a side effect on the unassigned values. The right qubit will allow us to distinguish 1 from ∗\\ast and 0, which will be useful to check a disjunction of literals.

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/circ6.png)(a)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/circ7.png)(b)

Figure 5: Circuit (a) is the negation of a boolean variable. The value associated with \|v⟩\\ket{v} is the negation of the one associated with \|u⟩\\ket{u}. Circuit (b) checks if the disjunction of the literals xi1,…,xikx\_{i\_{1}},\\dots,x\_{i\_{k}} is True or False. If ⋁j∈\[\[1,k\]\]xij=0\\bigvee\_{j\\in\[\\!\[1,k\]\\!\]}x\_{i\_{j}}=0, \|c′⟩=\|c+1⟩\\ket{c'}=\\ket{c+1}, otherwise \|c′⟩=\|c⟩\\ket{c'}=\\ket{c}.

### 4.3 General structure

Thanks to the precedent subsections, step 2 and most of step 5 of algorithm [4](https://arxiv.org/html/1908.11291v1#alg4 "Algorithm 4 ‣ 3 Variable ordering heuristics ‣ Practical implementation of a quantum backtracking algorithm") can be realized. The rest of the implementation is most straightforward, circuits of the operators RAR\_{A} and RBR\_{B} are given in appendix (resp. Fig. [9](https://arxiv.org/html/1908.11291v1#A0.F9 "Figure 9 ‣ Appendix ‣ Practical implementation of a quantum backtracking algorithm") and [10](https://arxiv.org/html/1908.11291v1#A0.F10 "Figure 10 ‣ Appendix ‣ Practical implementation of a quantum backtracking algorithm")). Note that contrary to what is said in \[ [7](https://arxiv.org/html/1908.11291v1#bib.bib7 "")\], we just need to add one control qubit to three (resp. one) controlled-Z gates in step 6 to control the whole operator RAR\_{A} (resp. RBR\_{B}).

## 5 Simulation results

Now, we present some results of our simulations for the problem of graph coloring. In order to check the constraints, the circuits [4a](https://arxiv.org/html/1908.11291v1#S4.F4.sf1 "In Figure 4 ‣ 4.2 How to check a constraint ‣ 4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm") and [4b](https://arxiv.org/html/1908.11291v1#S4.F4.sf2 "In Figure 4 ‣ 4.2 How to check a constraint ‣ 4 Generic implementation ‣ Practical implementation of a quantum backtracking algorithm") can be used. The colors red (circle), green (square) and blue (triangle) will be denoted by RR, GG and BB. We will denote any partial assignment x1=v1,…,xℓ=vℓx\_{1}=v\_{1},\\dots,x\_{\\ell}=v\_{\\ell} which is not trivially false by aℓa^{\\ell} and if the values are of importance by av1​…​vℓa\_{v\_{1}\\dots v\_{\\ell}}.

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/graph1.png)(a) (a)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/table1.png)(b) (c)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/tree1.png)(c) (b)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/graphic1.png)(d) (d)

Figure 6: Fig. (a): a graph. Fig. (b): its associated classical backtracking tree. Tab. (c): results of our simulations. Fig. (d): some of these results as a graph.

Fig. [6b](https://arxiv.org/html/1908.11291v1#S5.F6.sf2 "In Figure 6 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm") (resp. [7b](https://arxiv.org/html/1908.11291v1#S5.F7.sf2 "In Figure 7 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm")) shows the classical backtracking tree associated to the graph in Fig. [6a](https://arxiv.org/html/1908.11291v1#S5.F6.sf1 "In Figure 6 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm") (resp. [7a](https://arxiv.org/html/1908.11291v1#S5.F7.sf1 "In Figure 7 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm")), assuming, without loss of generality, that the first vertex has been colored in blue.

By applying the algorithm [3](https://arxiv.org/html/1908.11291v1#alg3 "Algorithm 3 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") on the root of the complete tree associated to the graph in Fig. [6a](https://arxiv.org/html/1908.11291v1#S5.F6.sf1 "In Figure 6 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm"), it is supposed to detect that there is no possible coloring for this graph with two colors. Thus, the subtree presented here may not be visited thanks to the quantum part. For the second example, the algorithm [3](https://arxiv.org/html/1908.11291v1#alg3 "Algorithm 3 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") will travel along the dark gray tree (if it outputs all the solutions in Fig. [7b](https://arxiv.org/html/1908.11291v1#S5.F7.sf2 "In Figure 7 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm")).

Tab. [6c](https://arxiv.org/html/1908.11291v1#S5.F6.sf3 "In Figure 6 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm") (resp. [7c](https://arxiv.org/html/1908.11291v1#S5.F7.sf3 "In Figure 7 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm")) presents some probabilities of obtaining eigenvalue 1 depending on the precision used for the phase estimation in the algorithm [2](https://arxiv.org/html/1908.11291v1#alg2 "Algorithm 2 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") and the partial assignment at the root of the subtree on which it is applied. Some of these probabilities (y-axis) depending on the precision (x-axis) are presented in Fig. [6d](https://arxiv.org/html/1908.11291v1#S5.F6.sf4 "In Figure 6 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm") (resp. [7d](https://arxiv.org/html/1908.11291v1#S5.F7.sf4 "In Figure 7 ‣ 5 Simulation results ‣ Practical implementation of a quantum backtracking algorithm")).

For the first example, we look at the results where the algorithm has been applied on a0a^{0}. We can see that for a precision smaller than 4, the algorithm [2](https://arxiv.org/html/1908.11291v1#alg2 "Algorithm 2 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") will fail with high probability, since the threshold probability of acceptance fixed in \[ [22](https://arxiv.org/html/1908.11291v1#bib.bib22 "")\] is 0.3750.375 (blue line). For the second example, we look at the results where the algorithm has been applied on aB​Ba\_{BB} (plus signs) and aB​Ra\_{BR}&\\&aB​Ga\_{BG} (crosses). We can see that for a precision equal to 1, the algorithm [2](https://arxiv.org/html/1908.11291v1#alg2 "Algorithm 2 ‣ 2.2 Montanaro’s algorithm ‣ 2 Preliminaries ‣ Practical implementation of a quantum backtracking algorithm") will fail with high probability.

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/graph2.png)(a) (a)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/table2.png)(b) (c)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/tree2.png)(c) (b)

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/graphic2.png)(d) (d)

Figure 7: Fig. (a): a graph. Fig. (b): a subtree of its associated classical backtracking tree (d=3d=3). Tab. (c): results of our simulations. Fig. (d): some of these results as a graph.

## 6 Conclusion

In this paper, we discussed our implementation of Montanaro’s algorithm, but an improved quantum algorithm for backtracking has been introduced by Ambainis and Kokainis \[ [3](https://arxiv.org/html/1908.11291v1#bib.bib3 "")\], reducing the queries complexity from 𝒪⁡(T​n​log⁡(1δ))\\mathcal{O}(\\sqrt{Tn}\\log{\\frac{1}{\\delta}}) to 𝒪⁡(n3/2​T′​log2​n​log⁡(T)δ)\\mathcal{O}(n^{3/2}\\sqrt{T^{\\prime}}\\log^{2}{\\frac{n\\log{T}}{\\delta}}), where T′T^{\\prime} is the number of vertices of 𝒯\\mathcal{T} actually explored by a classical backtracking algorithm. Nevertheless, Montanaro’s algorithm can not be left out since it is a component of Ambainis-Kokainis’ algorithm.

While Campbell, Khurana and Montanaro \[ [7](https://arxiv.org/html/1908.11291v1#bib.bib7 "")\] assumed access to an extremely large number of physical qubits to propose a depth optimized method to implement Montanaro’s algorithm, we have presented techniques minimizing the space usage. For that, we especially looked at the implementation of the predicate and the heuristic. We have proposed the use of a quantum counter for the former and highlighted the fact that up to a certain point, the latter might not be quantumly implemented. However, these propositions are not asymptotically competitive, although our implementation of the predicate could be parallelized to be efficient and could lead to a trade-off between the space usage and the time usage. As far as the heuristic is concerned, it would be interesting to establish a precise resource estimation and define to what extent a SVO heuristic would present benefits compared to a DVO one.

Acknowledgments. This work was supported by Atos. The implementation was developed in python using Atos’ pyAQASM library. All simulations were performed on the Atos Quantum Learning Machine. We acknowledge support from the French ANR project ANR-18-CE47-0010 (QUDATA), the QuantERA ERA-NET Cofund in Quantum Technologies implemented within the European Union’s Horizon 2020 Program (QuantAlgo project), and the French ANR project ANR-18-QUAN-0017 (QuantAlgo Project).

## References

- \[1\]
A. Ambainis.

Quantum walks and their algorithmic applications.

International Journal of Quantum Information 01(04)
507–518, 2003.

- \[2\]
A. Ambainis.

Quantum walk algorithm for element distinctness.

SIAM J. Comput. 37(1) 210–239, 2007.

- \[3\]
A. Ambainis and M. Kokainis.

Quantum algorithm for tree size estimation, with applications
to backtracking and 2-player games.

ACM, 2017.

- \[4\]
Y. Aono, P. Q. Nguyen, and Y. Shen.

Quantum Lattice Enumeration and Tweaking Discrete Pruning.

Springer, 2018.

- \[5\]
A. Belovs.

Quantum walks and electric networks.

arXiv:1302.3143, 2013.

- \[6\]
A. Belovs, A. M. Childs, S. Jeffery, R. Kothari, and F. Magniez.

Time-efficient quantum walks for 3-distinctness.

Springer, 2013.

- \[7\]
E. Campbell, A. Khurana, and A. Montanaro.

Applying quantum algorithms to constraint satisfaction problems.

Quantum 3(167), 2018.

- \[8\]
L. Chen, S. Jordan, Y.-K. Liu, D. Moody, R. Peralta, R. Perlner,
and D. Smith-Tone.

Report on post-quantum cryptography.

NISTIR 8105, 2016.

- \[9\]
A. M. Childs, R. Cleve, E. Deotto, E. Farhi, S. Gutmann, and D. A.
Spielman.

Exponential algorithmic speedup by a quantum walk.

ACM, 2003.

- \[10\]
M. Davis, G. Logemann, and D. Loveland.

A machine program for theorem-proving.

Communications of the ACM 5(7) 394–397, 1962.

- \[11\]
M. Davis and H. Putnam.

A computing procedure for quantification theory.

JACM 7(3) 201–215, 1960.

- \[12\]
D. de Werra.

An introduction to timetabling.

European Journal of Operational Research 19(2)
151–162, 1985.

- \[13\]
R. Dechter and I. Meiri.

Experimental evaluation of preprocessing techniques in
constraint satisfaction problems.

Morgan Kaufmann Publishers Inc., 1989.

- \[14\]
N. Eén and N. Sörensson.

An extensible SAT-solver.

Springer, 2004.

- \[15\]
E. C. Freuder.

A sufficient condition for backtrack-free search.

JACM 29(1) 24–32, 1982.

- \[16\]
C. P. Gomes, H. Kautz, A. Sabharwal, and B. Selman.

Satisfiability solvers.

Elsevier, 2008.

- \[17\]
J. Gu, P. W. Purdom, J. Franco, and B. W. Wah.

Algorithms for the satisfiability (SAT) problem: a survey.

Amer Mathematical Society, 1997.

- \[18\]
J. Kempe.

Quantum random walks: an introductory overview.

Contemporary Physics 44(4) 307–327, 2003.

- \[19\]
F. T. Leighton.

A graph coloring algorithm for large scheduling problems.

Journal of research of the NBS 84(6), 1979.

- \[20\]
F. Magniez, A. Nayak, J. Roland, and M. Santha.

Search via quantum walk.

Theory of Computing, 2007.

- \[21\]
E. Malaguti and P. Toth.

A survey on vertex coloring problems.

International Transactions in Operational Research 17,
2010.

- \[22\]
A. Montanaro.

Quantum walk speedup of backtracking algorithms.

Theory of Computing 14(15) 1–24, 2015.

- \[23\]
A. Montanaro.

Data from Quantum algorithms for CSPs.

07 2019.

- \[24\]
A. Montanaro.

Quantum speedup of branch-and-bound algorithms.

arXiv:1906.10375, 2019.

- \[25\]
M. Santha.

Quantum walk based search algorithms.

Springer, 2008.

- \[26\]
M. Szegedy.

Quantum speed-up of Markov chain based algorithms.

IEEE, 2004.

- \[27\]
P. van Beek.

Backtracking search algorithms.

Elsevier, 2006.


## Appendix

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/parallelized.png)Figure 8: Example of parallelization of the predicate for k=4k=4. {C(i),i∈\[\[1,4\]\]}\\{C^{(i)},i\\in\[\\!\[1,4\]\\!\]\\} is a partition of CC and \|C(i)\|≤mk​∀i∈\[\[1,4\]\]\\absolutevalue{C^{(i)}}\\leq\\frac{m}{k}\\forall i\\in\[\\!\[1,4\]\\!\]. The checking operation of an element in C(i)C^{(i)} is denoted by Check(i).

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/RA.png)Figure 9: Circuit corresponding to algorithm [4](https://arxiv.org/html/1908.11291v1#alg4 "Algorithm 4 ‣ 3 Variable ordering heuristics ‣ Practical implementation of a quantum backtracking algorithm") for RAR\_{A}. Steps 7 and 8 are not represented since they consist in reversing steps 5, 4, 2 and 1. Step 3 is realized by controlling cZ (controlled Z) operations in step 6 with \|P⟩\\ket{P}. In the same way, it is sufficient to control the three cZ in step 6 to control the whole operator, due to the reversibility of the other steps.

![Refer to caption](https://arxiv.org/html/1908.11291v1/Images/RB.png)Figure 10: Circuit corresponding to algorithm [4](https://arxiv.org/html/1908.11291v1#alg4 "Algorithm 4 ‣ 3 Variable ordering heuristics ‣ Practical implementation of a quantum backtracking algorithm") for RBR\_{B}. Steps 7 and 8 are not represented since they consist in reversing steps 5, 4, 2 and 1. Steps "ℓ=?0\\ell\\stackrel{{\\scriptstyle?}}{{=}}0" and 3 are realized by controlling cZ (controlled Z) operation in step 6 with \|ℓ=?0⟩\\ket{\\ell\\stackrel{?}{=}0} and \|P⟩\\ket{P} respectively. In the same way, it is sufficient to control the cZ operation in step 6 to control the whole operator, due to the reversibility of the other steps.