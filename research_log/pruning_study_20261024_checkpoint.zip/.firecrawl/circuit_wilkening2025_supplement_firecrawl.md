# Supplementary information: A quantum algorithm for solving 0-1 Knapsack problems

Sören Wilkening,<sup>1, 2</sup> Andreea-Iulia Lefterovici,<sup>1</sup> Lennart Binkowski,<sup>1</sup> Michael Perk,<sup>3</sup> Sándor P. Fekete,<sup>3</sup> and Tobias
J. Osborne<sup>1</sup>

<sup>1)</sup>Institut für Theoretische Physik, Leibniz Universität Hannover, Germany

<sup>2)</sup>Volkswagen AG, Berliner Ring 2, 38440 Wolfsburg

<sup>3)</sup>Institut für Betriebssysteme und Rechnerverbund, Technische Universität Braunschweig,
*Germany*

## A. Classical Methods

| size | COMBO (runtime, s) | IP (runtime, s) | CP-SAT (runtime, s) | Greedy (runtime, s) |
| --- | --- | --- | --- | --- |
| 200 | 0.35 | 0.95 | 27 | 0.3 |
| 600 | 0.5 | 85 | 30 | 0.35 |
| 1000 | 0.75 | 130 | 38 | 0.35 |
| 1400 | 0.95 | 130 | 30 | 0.35 |
| 1800 | 1.4 | 130 | 35 | 0.35 |
| 2200 | 1.8 | 120 | 30 | 0.35 |
| 2600 | 2.2 | 105 | 40 | 0.35 |

Supplementary Figure 1. Comparison of several classical
solvers on the *jooken-large* instance set. We observe that
despite COMBO being a single-threaded algorithm, it still
outperforms the exact solvers Gurobi and CP-SAT in terms
of runtime. Note that GUROBI and CP-SAT were not able to
prove optimality for all instances within 300 s despite finding
an optimal solution for all of them.

To compare the QTG-based search with classical methods, we evaluated the capabilities of classical knapsack
solvers on a wide range of benchmark instances. We
use three exact solvers: GUROBI (based on IP), CP-
SAT, and COMBO. EXPKNAP was also tested, but did
not produce results within the given time frame and was
therefore excluded from this evaluation. Moreover, we
also evaluated the performance of Greedy (i.e. an algorithm that iteratively includes the most efficient item
until the capacity is exceeded). The instance set *jookenlarge* consisted of 336 instances with 200,400,...,2800
items that were generated with the algorithm proposed
by Jooken *et al.* [1] using values *g* = *3,4,...,10.* The experiment was carried out with a time limit of 300 s. Note
that the instances are comparable to those in the main
text but not the same, as the benchmark set is sparser
and larger.

$$
g=3,\widetilde{4},\ldots,10
$$

Supplementary Figure 1 presents a comparison between all classical algorithms. Note that although the
simplicity of the Greedy algorithm allows for a short runtime, it produces suboptimal solutions in most cases. On
the other hand, IP and CP-SAT were able to find optimal solutions (within a gap of 10<sup>−5</sup>) for all instances. In
some cases, however, both solvers were unable to prove

$$
CP-SAT
$$

$$
10^{-5})
$$

optimality for found solutions resulting in exceeding the
given time limit. It is clear that COMBO being provably
optimal and several orders faster than its exact counterparts, while only utilising a single core instead of the
available 8 cores serves as the basis for our comparison
to QTG.

## B. Branching strategy

## 1. Biasing Ry gates

First we consider the biasing Ry gates (3) and note
that, for *b* = 0, both variants yield the same gate which
maps *|0⟩* to the uniform superposition of *|0⟩* and *|*1⟩. This
would correspond to including or excluding the items
with equal probability. Accordingly, we numerically observed that the number of elapsed quantum cycles for
obtaining a reasonable success probability would generally not be competitive when using unbiasing Ry gates.

$$
b=0
$$

In comparison, allowing for biasing Ry gates and finetuning the bias *b* can lead to an enormous speed-up during the phase of amplitude amplification: Given an intermediate solution x<sup>′</sup>, whose profit also constitutes the
current threshold for the QMaxSearch, we can actively
favour feasible paths *x* that have a certain Hamming distance ∆ := ∆(x<sup>′</sup>, x) to x<sup>′</sup>. Namely, applying the QTG
and its biasing Ry gates with arbitrary but fixed bias *b,*
we can give the following lower bound on the sampling
probability of *x:*

$$
x^{\prime}
$$

$$
\Delta:=\Delta(\bar{\boldsymbol{x}}',\boldsymbol{x})
$$

$$
\boldsymbol{x}^{\prime}
$$

$$
|a_{\pmb x}|^{2}=\left(\frac{b+1}{b+2}\right)^{n-\Delta}\left(\frac{1}{b+2}\right)^{\Delta}.
$$

(S.1)

This bound is tight if all possible branchings occur
when constructing the path *x.* For each bit in which *x*
and x<sup>′</sup> differ, the application of a biasing Ry gate introduces the prefactor *1/(b* + 2). For each of the remaining
bits, it establishes the prefactor (*b* + 1)/(b + 2).

$$
\boldsymbol{x}^{\prime}
$$

$$
1/(b+2)
$$

$$
(b+1)/(b+2)
$$

Now, we can determine *b* in order to maximise the
sampling probability of *x* within the superposition created by the QTG. Differentiating (S.1) with respect to *b*
and checking for zeros yield the optimal bias

$$
b_{\mathrm{opt}}=\frac{n}{\Delta}-2\approx\frac{n}{\Delta}.
$$

Fine-tuning the bias in order to sample paths with a
certain hamming distance more frequently helps searching the neighbourhood of good intermediate solutions for even better solutions. We observe that for many Knapsack instances the optimal solution and the Greedy result do have a lot of common bit values, corresponding to
items whose efficiency is just too good to not be included
in any optimal assignment. Because we employ Greedy
for obtaining an initial solution in our QMaxSearch
routine, the biasing Ry approach typically results in
highly improved performance.

The time required by QSearch algorithm to find a
state with hamming distance ∆ to a known solution is
O(1/a<sub>x</sub>), where

$$
\Delta
$$

$$
\mathcal{O}(1/a_{x})
$$

$$
\begin{aligned}1/a_{x}&=\left(\frac{b_{\mathrm{opt}}+2}{b_{\mathrm{opt}}+1}\right)^{(n-\Delta)/2}\left(b_{\mathrm{opt}}+2\right)^{\Delta/2}\\&=\left(\frac{n}{n-\Delta}\right)^{(n-\Delta)/2}\left(\frac{n}{\Delta}\right)^{\Delta/2}\approx\left(\frac{n}{\Delta}\right)^{\Delta/2}.\end{aligned}
$$

(S.2)

((<sub>n</sub>))
∆/2
More explicitly, we get a runtime *O.* As
∆
the neighbourhood of distance (<sub>n</sub>) ∆ to a known solution
∆
contains *≈ n* assignments, this runtime can be seen
∆
as a quadratic improvement over local search algorithms.

$$
\mathcal{O}\left(\left(\frac{n}{\Delta}\right)^{\Delta/2}\right)
$$

$$
\Delta
$$

$$
{n\choose\Delta}\approx n^{\Delta}
$$

## 2. Construction of the layer unitaries

As described in Section IV
∏, the QTG is composed ofn
the layer unitaries U<sub>m</sub>: G =m=1U<sub>m</sub>. That is, each U<sub>m</sub>
manages the inclusion/exclusion of an item *m.* The unitaries U<sub>m</sub> are themselves comprised of three components:

$$
U_{m}:\ \mathcal{G}=\prod_{m=1}^{n}\dot{U_{m}}
$$

$$
U_{m}
$$

$$
U_{m}
$$

1. Create a biased superposition of including or excluding item *m* if and only if including the item
does not exceeds the capacity *c,* otherwise do nothing. We achieve this step by applying a multi-

controlled biasing Ry gate to the *m*-th qubit. The
Ry gate itself acts on the *m*-th qubit in the register
*H<sub>1</sub>.* The control runs over the qubits of the second register *H<sub>2</sub>* and checks whether the remaining
capacities cover the weight w<sub>m</sub> of including item
m. Accordingly, we denote the control with C<sup>2</sup>≥w<sub>m</sub>,
because it asks whether the second register’s state,
interpreted as the binary representation of an integer, is greater or equal to the integer w<sub>m</sub>. It then
highly depends on the actual value of w<sub>m</sub> which
qubits in *H<sub>2</sub>* have to be involved into the control
(see Supplementary Section E5). In summary, this
subgate is given by U<sup>1</sup><sub>m</sub>:= C<sup>2</sup> (H<sup>x</sup><sub>b</sub> <sup>m</sup>).
≥w<sub>m</sub>

$$
\mathcal{H}_{1}
$$

$$
\mathcal{H}_{2}
$$

$$
w_{m}
$$

$$
\widehat{C_{\geq w_{m}}^{2}}
$$

$$
\bar{\mathcal{H}}_{2}
$$

$$
w_{m}
$$

$$
w_{m}
$$

$$
U_{m}^{1}:=C_{\geq w_{m}}^{2}\left(\mathrm{H}_{b}^{x_{m}}\right)
$$

2. Update the remaining capacity. For this, we have
to perform an integer subtraction by w<sub>m</sub> in the second register H<sub>2</sub> – denoted by SUB<sub>w</sub><sub>m</sub> – which is,
however, only executed if the main register *H<sub>1</sub>* represents a path for which the *m*-th item is included.
That is, the integer subtraction by w<sub>m</sub> is controlled
by the *m*-th qubit in the main register. The entire
update step therefore reads U<sup>2</sup><sub>m</sub>:= C<sup>1</sup><sub>m</sub>SUB<sub>w</sub><sub>m</sub>.

$$
w_{m}
$$

$$
\mathcal{H}_{2}
$$

$$
\mathrm{SU}\dot{\mathrm{B}}_{w_m}-
$$

$$
\mathcal{H}_{1}
$$

$$
w_{m}
$$

$$
U_{m}^{2}:\stackrel{\circ}{=}C_{m}^{1}\mathrm{SUB}_{w_{m}}
$$

3. Update the total profit. Here, we perform an integer addition by p<sub>m</sub> in the third register H<sub>3</sub> – denoted by ADD<sub>p</sub><sub>m</sub> – which is, analogously to step 2,
controlled by the *m*-th qubit in the main register.
This last update step thus reads U<sup>3</sup><sub>m</sub>:= C<sup>1</sup><sub>m</sub>ADD<sub>p</sub><sub>m</sub>.

$$
p_{m}
$$

$$
\mathcal{H}_{3}\ -
$$

$$
\mathrm{ADD}_{p_{m}}^{t^{-1}}\stackrel{\cdots}{-}
$$

$$
U_{m}^{3}:=C_{m}^{1}\widetilde{\mathrm{ADD}}_{p_{m}}.
$$

To give an explicit example: Let *x* be a feasible path
whose *m*-th bit is set to zero and let *x˜* be the same bit
string, but with its *m*-th bit set to one. Further assume
that the m-th bit of the intermediate solution x<sup>′</sup> has the
value one. The action of U<sub>m</sub> on a the feasible product
state |x⟩<sup>1</sup> |c<sub>x</sub>⟩<sup>2</sup> |P<sub>x</sub>⟩<sup>3</sup> then reads

$$
\boldsymbol{x}^{\prime}
$$

$$
U_{m}
$$

$$
\left|\boldsymbol{x}\right\rangle^{1}\left|c_{\boldsymbol{x}}\right\rangle^{2}\left|P_{\boldsymbol{x}}\right\rangle^{3}
$$

$$
U_{m}\left|\pmb{x}\right\rangle^{1}\left|c_{\pmb{x}}\right\rangle^{2}\left|P_{\pmb{x}}\right\rangle^{3}=\left\{\begin{aligned}&\left|\pmb{x}\right\rangle^{1}\left|c_{\pmb{x}}\right\rangle^{2}\left|P_{\pmb{x}}\right\rangle^{3},&&\mathrm{i f~}c_{\pmb{x}}<w_{m}\\ &\sqrt{\frac{1}{b+2}}\left|\pmb{x}\right\rangle^{1}\left|c_{\pmb{x}}\right\rangle^{2}\left|P_{\pmb{x}}\right\rangle^{3}+\sqrt{\frac{b+1}{b+2}}\left|\tilde{\pmb{x}}\right\rangle^{1}\left|c_{\pmb{x}}-w_{m}\right\rangle^{2}\left|P_{\pmb{x}}+p_{m}\right\rangle^{3},&&\mathrm{e l s e.}\end{aligned}\right.
$$

(S.3)

## C. Quantum maximum finding

Here, we recap the known quantum algorithms Amplitude Amplification/QSearch and QMaxSearch and
detail our adjustments for application to the 0-1-KP.

QSearch is a direct generalisation of Grover’s famous
algorithm [2]. More precisely, Grover’s algorithm was initially proposed for finding a unique marked state within
a uniform superposition. It was then generalised to instances with multiple marked states in the form of the
*quantum exponential searching algorithm* [3]. The two
central building blocks of these algorithms are the *phase
oracle*

$$
\mathcal{S}_{f}\left|\boldsymbol{x}\right\rangle:=(-1)^{f(\boldsymbol{x})}\left|\boldsymbol{x}\right\rangle,
$$

$$
f(\boldsymbol{x})=1
$$

(S.4)

which flips the phase of all states corresponding to bit
strings *x* that fulfil the Boolean trait *f* (x) = 1, and the
*diffusion operator*

$$
D=\mathrm{H}^{\otimes n}\mathcal{S}_0\mathrm{H}^{\otimes n}.
$$

(S.5)

In the more general QSearch routine, H<sup>⊗n</sup> – which
creates a uniform superposition of all computational basis
states – is replaced by any other superposition-creating
unitary *A,* in our case by the QTG *G.* Fixing the Boolean
function *f* and the state preparation unitary *A,* the Amplitude Amplification operator is given by

$$
H^{\otimes n}-
$$

$$
\mathcal{A},
$$

$$
\mathcal{Q}:=\mathcal{A}\mathcal{S}_{0}\mathcal{A}^{\dagger}\mathcal{S}_{f}.
$$

(S.6)

---

In the original proposal [4], the QSearch algorithm
runs forever if there is no state *x* fulfilling *f* (x). In our
case, however, this situation naturally occurs at the end
of an entire QMaxSearch routine (see remainder of this
section) which is why we additionally introduce a cutoff to prevent an endless loop. With this extension, our
version of QSearch reads

Algorithm 1: QSearch (G, *f, M*)
1 Set l = 0, m<sub>tot</sub> = 0, and let d be any constant such
that 1 < *d* < 2;
2 Increase l by 1 and set m = ⌈d<sup>l</sup>⌉;
3 Apply G to the initial state |0⟩<sup>1</sup> |c⟩<sup>2</sup> |0⟩<sup>3</sup>;
4 Choose *j ∈* [1, *m*] uniformly at random and increase
m<sub>tot</sub> by 2j + 1;
5 Apply Q<sup>j</sup> to the superposition |s⟩<sup>123</sup> = G|0⟩<sup>1</sup> |c⟩<sup>2</sup> |0⟩<sup>3</sup>;
6 Measure the register 1 and 3, and get the outcome
|x⟩<sup>1</sup> |P<sub>x</sub>⟩<sup>3</sup>;
7 if f (P<sub>x</sub>) = 1 or m<sub>tot</sub> ≥ M then
8 return x, P<sub>x</sub>;
9 else
10 go to step 2;
11 end

$$
(\mathcal{G},f,M)
$$

$$
l=0,m_{tot}=0
$$

$$
1<d<2;
$$

$$
m=\left\lceil d^{l}\right\rceil
$$

$$
\left|\mathbf{0}\right\rangle^{1}\left|c\right\rangle^{2}\left|0\right\rangle^{3};
$$

$$
j\in[1,m]
$$

$$
m_{tot}
$$

$$
2j+1;
$$

$$
\left|s\right\rangle^{123}=\mathcal{G}\left|\mathbf{0}\right\rangle^{1}\left|c\right\rangle^{2}\left|0\right\rangle^{3};
$$

$$
\mathcal{Q}^{j}
$$

$$
\left|\boldsymbol{x}\right\rangle^{1}\left|P_{\boldsymbol{x}}\right\rangle^{3}
$$

$$
f(\dot{P}_x)=1
$$

$$
\geq M
$$

$$
P_{x};
$$

Because we are interested in maximising the total
profit among all feasible paths, we have to choose the
Boolean function *f* accordingly. The apt method in question is provided by Quantum Maximum Finding. While
initially proposed as an extension to Grover’s algorithm,
its principle is directly transferable to QSearch.

The key idea is to introduce the comparison “P<sub>x</sub> > T”
as Boolean function which marks all paths *x* whose total
profit P<sub>x</sub> exceeds a given threshold T. Starting with an
initial threshold T<sub>0</sub>, QSearch(G,P<sub>x</sub> > T<sub>0</sub>,M) yields an
intermediate solution (x<sub>1</sub>,P<sub>x</sub><sub>1</sub>). If P<sub>x</sub><sub>1</sub> > T<sub>0</sub>, we can call
QSearch again with the updated threshold T<sub>1</sub> := P<sub>x</sub><sub>1</sub>
and so on. However, if we obtain an output (x<sub>i</sub>,P<sub>x</sub><sub>i</sub>) with
P<sub>x</sub><sub>i</sub> ≤ T<sub>i−1</sub> throughout this routine, we can conclude –
within a certain probability – that no valid path exists
with a higher total profit than T<sub>i−1</sub>; hence we declare the
previous intermediate solution (x<sub>i−1</sub>,T<sub>i−1</sub>) the optimal
solution. Because this case eventually occurs for every
instance, we have introduced the additional termination
condition in QSearch. Finally, for the initial threshold
we employ the very efficient Integer Greedy method.

$$
``P_{\boldsymbol{x}}>T''
$$

$$
P_{\boldsymbol{x}}
$$

$$
T_{0},
$$

$$
P_{\underline{{x}}}>T_{0},M)
$$

$$
\left(\boldsymbol{x}_{1},P_{\boldsymbol{x}_{1}}\right)
$$

$$
P_{x_1}>T_0.
$$

$$
T_{1}:=P_{\boldsymbol{x}_{1}}
$$

$$
\left(\boldsymbol{x}_{i},P_{\boldsymbol{x}_{i}}\right)
$$

$$
P_{\mathbf{x}_{i}}\leq T_{i-1}
$$

$$
T_{i-1};
$$

$$
\left(\boldsymbol{x}_{i-1},T_{i-1}\right)
$$

Algorithm 2: QMaxSearch(G, *M, p, w, c*)
1 Calculate initial threshold T using Greedy: x<sub>out</sub>,

*T* = intGr(p, *w, c*) ;

2 while True do
3 x, P<sub>x</sub> = QSearch(G, P<sub>x</sub> > T, M);
4 if P<sub>x</sub> > T then

$$
P_{x}>T
$$

5 set T = P<sub>x</sub> and x<sub>out</sub> = x;
6 else
7 return x<sub>out</sub>, T;
8 end
9 end

$$
\boldsymbol{x}_{out}=\boldsymbol{x};
$$

## D. Runtime calculator

The instance sizes considered in Figure 2 and Figure 3
are way too large for any conventional simulator which is
based on evaluating the action of general quantum gates
on general quantum states. Even with the most sophisticated simulation technique and with the aid of the largest
available super computer, these approaches could only
tackle up to 49 qubits [5]. Instead, we developed a completely different runtime calculator tailored explicitly to
the application of the QTG and QMaxSearch. The calculator consists of two main parts:

1. calculate the QTG’s action only on computational
basis states whose objective value surpasses the
current threshold imposed by QMaxSearch.

2. calculate the effect of Amplitude Amplification operator via analytical formulas.

## 1. QTG as a state sieve

$$
\tilde{c},
$$

$$
w_{m+1}\;>\;\tilde{c},
$$

We classically mimic the QTG by exploring the classical binary decision tree for a given knapsack instance
using *breadth-first search* (BFS) and, in doing so, keep
track of the remaining capacities, the total profit, and the
sampling probabilities of the computational basis states
after each application of one layer operator U<sub>m</sub>. The sampling probabilities are propagated as follows: Assume a
node in the *m*-th layer carries a remaining capacity of
c˜, a total profit of *p,* and a sampling probability of *q.*
If w<sub>m+1</sub> > c˜, no branching occurs and the only child
node inherits its data from its parent node. If instead
w<sub>m+1</sub> ≤ c˜, a branching produces two child nodes corresponding to either excluding (left) or including (right)
the (*m* + 1)-th item. The child nodes’ metadata are:

$$
U_{m}.
$$

$$
\boldsymbol{x}_{out}
$$

(˜c<sub>left</sub>, c˜right
(p<sub>left</sub>,pright
(q<sub>left</sub>,qright

$$
p,
$$

) = (˜c, c˜− w<sub>m+1</sub>
) = (p,p + p<sub>m+1</sub>
{(
q
<sup>q(b+1)</sup>,
(b+2 <sub>q(b+1)</sub><sup>b+2</sup>
) =
q
<sub>b+2</sub>,
*b+2*

)
)
)
, if x<sub>m+1</sub> = 0
)
*,* else.

$$
w_{m+1}\:\leq\:\tilde{c},
$$

The update rule for the child nodes’ sampling probability directly results from the definition of the biasing
Ry gate (3).

During the BFS, we prune infeasible subtrees as the
QTG would do anyway on a real quantum device, thereby
massively reducing the final number of states. Furthermore, we also discard subtrees which do not admit
any path with an objective value surpassing the current
threshold. For this, we execute COMBO on the Knapsack subinstance that remains when fixing the first *m*
decision variables x<sub>1</sub>,...,x<sub>m</sub> with the values corresponding to the current node in the decision tree. This yields
a tight upper bound for the optimal profit achievable
within the respective subtree. This second pruning step,
although computationally sumptuous, reduces the final
number of states in such a drastic way that even for large
instances up to 600 variables, only a few million – instead
of 2<sup>600</sup> – states remain.

$$
x_{1},\ldots,x_{m}
$$

$$
2^{600}
$$

---

The result of this runtime calculator, given a threshold
*T,* is an array of paths (bit strings) together with their
remaining capacity, total profit, and the theoretical sampling probability of the associated computational basis
state. All these paths are feasible and admit, by construction, a respective total profit above the threshold
*T.* This final array of states now serves as the input for
Amplitude Amplification.

$$
T,
$$

$$
T
$$

We denote this set of paths by *FT* and have therefore
gained a representation of the superposition

$$
\mathcal{F}^{T}
$$

$$
\begin{align*}\left|s\right\rangle^{123}&=\mathcal{G}\left|\mathbf{0}\right\rangle^1\left|c\right\rangle^2\left|0\right\rangle^3\\&=\sum_{\boldsymbol{x}\in\mathcal{F}^T}a_{\boldsymbol{x}}\left|\boldsymbol{x}\right\rangle^1\left|c_{\boldsymbol{x}}\right\rangle^2\left|P_{\boldsymbol{x}}\right\rangle^3+a_R\left|R\right\rangle\\&=a_T\left|\mathcal{F}^T\right\rangle+a_R\left|R\right\rangle,\end{align*}
$$

(S.7)

where

$$
\left|a_{T}\right|^{2}:=\sum_{\pmb{x}\in\mathcal{F}^{T}}\left|a_{\pmb{x}}\right|^{2}\mathrm{and}\left|a_{R}\right|^{2}=1-\left|a_{T}\right|^{2}.
$$

All other feasible paths, but with a total profit below
or equal to *T,* are thus collectively represented by the
remainder state *|R⟩.* In most cases, the remainder state’s
amplitude is nonzero, such that the cumulative sampling
probability q<sub>T</sub>:= |a<sub>T</sub> |<sup>2</sup> of all the paths in FT is not given
by one.

$$
T,
$$

$$
|R\rangle
$$

$$
q_{T}:=\left|a_{T}\right|^{2}
$$

$$
\mathcal{F}^{T}
$$

## 2. Amplitude Amplification

Beside the QTG, we also have to account for the action of the Amplitude Amplification operator *Q* (step
5 in QSearch) and quantum measurements (step 6 in
QSearch). Choosing some power *j ∈* N, the action of
Q<sup>j</sup> on |s⟩<sup>123</sup> is explicitly given[4] by

$$
\mathcal{Q}^{j}
$$

$$
j\in\mathbb{N}
$$

$$
\left|s\right\rangle^{\overset{\cdot}{1}23}
$$

$$
\begin{aligned}\mathcal{Q}^{j}\left|s\right\rangle^{123}=&\frac{\sin\left(\left(2j+1\right)\arcsin\left(\sqrt{q_{T}}\right)\right)}{\sqrt{q_{T}}}\left|\mathcal{F}^{T}\right\rangle\\&+\frac{\cos\left(\left(2j+1\right)\arcsin\left(\sqrt{q_{T}}\right)\right)}{\sqrt{1-q_{T}}}\left|R\right\rangle.\end{aligned}
$$

(S.8)

The crucial aspect lies in the amplification of the amplitudes of the all the states contributing to the superposition *|FT ⟩* – although being nonuniformly distributed –
by the same factor. Therefore, the entire the action of Q<sup>j</sup>
consists of merely multiplying each probability handed
over by the QTG sieve with the common amplification
factor

$$
\left|\mathcal{F}^{T}\right\rangle
$$

$$
\mathcal{Q}^{j}
$$

(S.9)

$$
\frac{\sin^{2}\left((2j+1)\operatorname{arcsin}\left(\sqrt{q_{T}}\right)\right)}{q_{T}}.
$$

Finally, simulating a quantum measurement in this
framework is straightforward: Uniformly draw a random
number from the interval [0,1] (we use GNU Scientific Library’s implementation of the MT19937 algorithm [6]).

Then iteratively sum up the sampling probabilities of all
the paths in *FT* until the cumulative probability surpasses the random number. If this occurs before the
loop ends, the last added path is considered to have been
measured and is returned (lines 7 and 8 in QSearch).
Otherwise, that is if the random number exceeds q<sub>T</sub>, we
consider the remainder state being sampled (lines 9 and
10 in QSearch). Because in the latter case, we simply
omit the result and restart the entire procedure with a
new value for *j,* no further information is necessary. This
completely justifies our approach of neglecting all the information about feasible states that admit a total profit
below the given threshold.

$$
\mathring{\mathcal{F}}^{T}
$$

$$
q_{T}
$$

$$
j,
$$

## E. Resource estimation

This section contains detailed resource estimations
for the subcircuits required for implementing the QTGbased search, specifically, the costs associated with implementing the exploration unitaries U<sub>m</sub> = U<sup>3</sup><sub>m</sub>U<sup>2</sup><sub>m</sub>U<sup>1</sup><sub>m</sub>,
*m* = *1,...,n.* A crucial aspect of evaluating the efficiency of our quantum algorithm is to determine the total
number of qubits Q, gates G, and cycles C required for
its implementation. Here, a cycle refers to a collection of
gates that can be executed in parallel. In the context of
resource estimation, we make the following assumptions:

$$
m=1,\ldots,n
$$

$$
U_{m}=U_{m}^{3}U_{m}^{2}U_{m}^{1},
$$

$$
\mathbf{Q},
$$

$$
\mathbf{G},
$$

(i) Any *n*-controlled single-qubit gate can be decomposed into 2(n *−* 1) Toffoli gates and a singlecontrolled single-qubit gate. This decomposition
utilises *n −* 1 ancilla qubits.

$$
2(n-1)
$$

(ii) All multi-controlled single-qubit gates have access
to the same ancilla qubits arising from (i). This
corresponds to taking the maximum instead of the
sum of all additionally introduced ancilla qubits.

(iii) It is equally expensive to have a controlled gate on
the logical state 0 or 1.

## 1. Qubit count

The total number of qubits is given by the sum of the
main registers’ sizes (2) and the number of ancilla qubits
for decomposing multi-controlled gates according to (i).
Specifically, the size of the path register corresponds to
the number of items involved in the Knapsack problem

$$
\mathbf{Q}_{\mathrm{PATH}}=n.
$$

(S.10)

The size of the capacity register is determined by the
length of the capacity’s binary representation, i.e.,

$$
\overline{\mathbf{Q}}_{CAPACITY}=|c_{bin}|.
$$

(S.11)

Analogously, given an upper bound *P* for the optimal
profit, the size of the profit register is given by the length
of P’s binary representation, that is

$$
P^{\mathrm{v}}\mathrm{s}
$$

---

| $\|q_{n}\rangle$ | H | R_{2}$ | $R_{3}$ | $\cdots$ | R_{n}$ | $\|\phi_{n}\rangle$ |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $\|q_{n-1}\rangle$ |  |  |  | H | $\cdots$ | R_{n-2}$ | $R_{n-1}$ | $\cdots$ | $\phi_{n-2}\rangle$ | $\phi_{n-1}\rangle$ |
| $\|q_{n-2}\rangle$ |  |  |  |  |  | $\vdots$ |  |  |  |  |
| $\vdots$ |  |  |  |  |  | $\vdots$ |  |  |  |  |
| $\|q_{3}\rangle$ |  |  |  |  |  | $\vdots$ |  |  |  |  |
| $\|q_{2}\rangle$ |  |  |  |  |  | H | R_{2}$ | $H | $\phi_{2}\rangle$ |  |
| $\|q_{1}\rangle$ |  |  |  |  |  | H | $\phi_{1}\rangle$ |  |  |  |

| $\|\phi_n\rangle$ | $\|q_n\rangle$ | H | R_2 | R_3 | ... | R_{n-1}$ | $R_n$ | $\|\phi_n\rangle$ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $\|\phi_{n-1}\rangle$ | $\|q_{n-1}\rangle$ | H | ... | ... | R_{n-3}$ | $R_{n-2}$ | $\|\phi_{n-1}\rangle$ |  |
| $\|\phi_{n-2}\rangle$ | $\|q_{n-2}\rangle$ | ... | ... | ... | R_{n-5}$ | $R_{n-4}$ | $\|\phi_{n-2}\rangle$ |  |
| $\|\phi_3\rangle$ | $\vdots$ | $\vdots$ | ... | ... | ... | ... | $\|\phi_3\rangle$ |  |
| $\|\phi_2\rangle$ | $\|q_3\rangle$ | ... | ... | ... | H | R_2 | $\|\phi_2\rangle$ |  |
| $\|\phi_1\rangle$ | $\|q_1\rangle$ | ... | ... | ... | H | H | $\|\phi_1\rangle$ |  |

Supplementary Figure 2. a) The standard, non-parallelised QFT circuit. b) The optimally parallelised QFT circuit. For
all i = 3, . . . , n, the gates in the |q<sub>i−1</sub>⟩-level are shifted to the left until the leftmost gate, the Hadamard gate, is executed in
parallel with the R<sub>3</sub> gate in the |q<sub>i</sub>⟩-level. As the |q<sub>2</sub>⟩-level does not admit an R<sub>3</sub> gate, the Hadamard gate in the |q<sub>1</sub>⟩-level
is executed alone. Therefore, for all i = 2, . . . , n, the |q<sub>i−1</sub>⟩-level gate sequence with its i − 1 gates starts two layers after the
|q<sub>i</sub>⟩-level’s sequence which is comprised of i gates. Starting from the |q<sub>n</sub>⟩-level, each additional level thus introduces only one
additional layer to the circuit.

$$
i=3,\ldots,n,
$$

$$
\left|q_{i-1}\right\rangle
$$

$$
|q_{i}\rangle.
$$

$$
\mathrm{R_3}
$$

$$
|q_{2}\rangle.
$$

$$
R_{3}
$$

$$
i=2,\ldots,n.
$$

$$
\left|{{q_{i-1}}}\right\rangle
$$

$$
\left|q_{1}\right\rangle
$$

$$
i-1
$$

$$
|q_{i}\rangle
$$

$$
\left|q_{n}\right\rangle-level
$$

|  | $\|x\rangle^1$ | $\|x\rangle^1$ | $\|x\rangle^1$ |
| --- | --- | --- | --- |
|  | $\|1\rangle_a$ | $\|1\rangle_a$ | $\|1\rangle_a$ |
|  | $\|0\rangle_a$ | $\|0\rangle_a$ | $\|0\rangle_a$ |
|  | $\|1\rangle_a$ | $\|1\rangle_a$ | $\|1\rangle_a$ |
| $\|\phi_4(P)\rangle^3$ | $R_2$ | $R_3$ | $R_4$ |
| $\|\phi_3(P)\rangle^3$ |  | $R_1$ | $R_2$ |
| $\|\phi_2(P)\rangle^3$ |  |  | $R_1$ |
| $\|\phi_1(P)\rangle^3$ |  |  | $R_1$ |

| Category | R1 | R2 | R3 | R4 |
| --- | --- | --- | --- | --- |
|  | 0 | 0 | 1 | 1 |
|  | 1 | 0 | 0 | 0 |
|  | 0 | 1 | 0 | 0 |
|  | 0 | 0 | 0 | 1 |

Supplementary Figure 3. Addition of the item profit p<sub>m</sub> = 5 to the QFT-ed profit register, controlled on the m-th qubit in
the path register. a) Draper method. The binary representation of the integer 5 is encoded into the three-qubit ancilla state
|101⟩<sub>a</sub> whose qubits control the application of the rotations R<sub>k</sub> on the profit register. b) Direct method. The rotations for
which the controlling ancilla qubit in Draper’s method would be in the |1⟩<sub>a</sub> state are directly implemented, the remaining ones
simply omitted. In comparison to Draper’s method, this saves several gates and the overall ancilla state preparation.

$$
p_{m}=5
$$

$$
\left|101\right\rangle_{a}
$$

$$
R_{k}
$$

$$
\bar{|1\rangle}_{a}
$$

$$
\mathbf{Q}_{\mathrm{PROFIT}}=|P_{\mathrm{bin}}|.
$$

(S.12)

Additionally, the QTG contains the comparisons “c˜ *≥*
w<sub>m</sub>” for all the item weights w<sub>m</sub>, m = 1,...,n, which
constitute multi-controlled single-qubit gates (see Supplementary Section E5). Applying (i), the decomposition of those gates introduces up to |c<sub>bin</sub>|− 1 ancilla
qubits. For simplicity, we assume that this upper bound
is actually achieved by at least one of the comparisons.
Due to assumption (ii), this number of ancilla qubits
then suffices to implement all the comparisons. Analogously, the Amplitude Amplification operator *Q* contains
the phase oracles *S<sub>0</sub>* and *SP*<sup>x>T</sup>which we realise using
n-controlled and |P<sub>bin</sub>|-controlled single-qubit gates, respectively (see Supplementary Section E5). Hence, following (i) and (ii), max(n, |c<sub>bin</sub>|, |P<sub>bin</sub>|) − 1 additional
ancilla qubits have to be introduced. Utilising (ii) again,
these ancilla qubits then even suffice to execute *Q* several times with different thresholds *T.* Lastly, we use one
additional qubit to store the potential phase flip applied
by *Q.* In total, we obtain an amount of

$$
``\tilde{c}\geq
$$

$$
w_{m}\text{"}
$$

$$
w_{m},m=1,\ldots,n,
$$

$$
|c_{\mathrm{bin}}|-1
$$

$$
\mathcal{S}_{P_{\mathbf{x}>T}}
$$

$$
\mathcal{S}_{0}
$$

$$
\left|P_{bin}\right|
$$

$$
\mathrm{k}(n,|c_{\mathrm{bin}}|,|P_{\mathrm{bin}}|)-1
$$

(S.13)

$$
\mathbf{Q}_{\mathrm{ANC}}=\max(n,\left|c_{\mathrm{bin}}\right|,\left|P_{\mathrm{bin}}\right|)
$$

ancilla qubits. In summary, our methods requires the
following number of qubits:

$$
\begin{aligned}{\mathbf{Q}_{\operatorname{TOTAL}}}&{{}=\mathbf{Q}_{\operatorname{PATH}}+\mathbf{Q}_{\operatorname{CAPACITY}}+\mathbf{Q}_{\operatorname{PROFIT}}+\mathbf{Q}_{\operatorname{ANC}}}\\ {}&{{}=n+|c_{\operatorname{bin}}|+|P_{\operatorname{bin}}|}\\ {}&{{}\quad+\operatorname*{m a x}(n,|c_{\operatorname{bin}}|,|P_{\operatorname{bin}}|).\quad\operatorname{(S.14)}}\\ \end{aligned}
$$

(S.14)

***2.***

## QFT

Crucial for the efficient implementation of quantum
adders (see Supplementary Section E3 and Supplementary Section E4) is the well-known Quantum Fourier
Transform [7] (QFT). Supplementary Figure 2 shows the
general circuit representation of the QFT – unparallelised
and parallelised – with shorthand notation

$$
\mathrm{R}_{k}:=\begin{bmatrix}1\quad0\\ 0\quad e^{2\pi i/2^{k}}\end{bmatrix}.
$$

*Gate count.* The number of gates involved in the
QFT is fully determined by the underlying register’s size.
Namely, to perform the QFT on the capacity register, the
total number of gates required is given by

$$
\mathbf{G}_{QFT-CAPACITY}=\frac{|c_{bin}|(|c_{bin}|+1)}{2}.
$$

(S.15)

---

|  | parallel | parallel | parallel |
| --- | --- | --- | --- |
| $\|\boldsymbol{x}\rangle^{1}$ |  |  | $\|\boldsymbol{x}\rangle^{1}$ |
| $\|0\rangle_{a}$ |  |  | $\|0\rangle_{a}$ |
| $\|0\rangle_{a}$ |  |  | $\|0\rangle_{a}$ |
| $\|0\rangle_{a}$ |  |  | $\|0\rangle_{a}$ |
| $\|\phi_{4}(P)\rangle^{3}$ | $R_{2} + R_{4}$ |  | $\|\phi_{4}(P+5)\rangle^{3}$ |
| $\|\phi_{3}(P)\rangle^{3}$ | $R_{1} + R_{3}$ |  | $\|\phi_{3}(P+5)\rangle^{3}$ |
| $\|\phi_{2}(P)\rangle^{3}$ | $R_{2}$ |  | $\|\phi_{2}(P+5)\rangle^{3}$ |
| $\|\phi_{1}(P)\rangle^{3}$ | $R_{1}$ |  | $\|\phi_{1}(P+5)\rangle^{3}$ |

Supplementary Figure 4. Optimised parallelisation of addition. The consecutive rotations gates, controlled by the same
qubits, can be further merged into a single rotation gate. By
introducing 3 ancilla qubits, we can further execute the addition gates within a single cycle. This comes at the expense of
requiring four additional cycles that are given by duplicating
the path register.

Similarly, for the profit register, the total number of
gates needed for the QFT is

$$
\mathbf{G}_{\mathrm{QFT-PROFIT}}=\frac{|P_{\mathrm{bin}}|(|P_{\mathrm{bin}}|+1)}{2}.
$$

(S.16)

*Cycle count.* Following the parallelisation strategy
depicted in Supplementary Figure 2, the number of cycles
can be significantly reduced: The level-specific gate sequences can be shifted such that each level merely introduces one additional cycle to the nonparallelisable gate
sequence in the highest level. As the length of the latter
is given by the underlying register’s size, we derive the
following formulas for the optimised QFT cycle count:

$$
\mathrm{C_{QFT-CAPACITY}}=2|c_{\mathrm{bin}}|-1
$$

(S.17)

$$
\mathrm{C_{QFT-PROFIT}}=2|P_{bin}|-1.
$$

(S.18)

## 3. QFT Adder

Our version of the QFT adder is derived from the original proposal by Draper [8]. The latter is designed to
add together two integers *n<sub>1</sub>* and *n<sub>2</sub>* which are encoded
into quantum states *|n<sub>1</sub>⟩* and *|n<sub>2</sub>⟩* on two different registers. The result *|n<sub>1</sub>* + *n<sub>2</sub>⟩* is then stored in, say, the
first register. The entire QFT adder circuit consists of
applying the QFT to the first register, then performing
a cascade of rotations on the first register, controlled on
the qubits of the second register, and finally applying
the inverse QFT to the first register (see Supplementary
Figure 3 for an example on the profit register with additional control on some qubit in the path register). Because the items’ profits that we wish to add are known in
advance, we can instead remove the controls and implement all the rotations, controlled on qubits which would
have been initialised in the *|*1⟩, directly. In a second optimisation step, we merge all the rotations acting on the

$$
\left|n_{1}\right\rangle
$$

$$
n_{1}
$$

$$
\left|n_{1}+n_{2}\right\rangle
$$

$$
n_{2}
$$

$$
\left|n_{2}\right\rangle
$$

same qubits, thus reducing the overall gate count. Furthermore, by copying the control qubit’s state multiple
times on ancilla qubits, we substitute the shared control
with controls on distinct qubits. This allows us to entirely
parallelise the the actual addition while introducing only
logarithmically many additional copying cycles. Supplementary Figure 4 shows an example of the direct addition
method and its parallelised version which, in comparison
to Draper’s method, requires fewer gates and cycles.

*Gate count.* The number of actually implemented
gates in the addition step depends on the main register’s size and the number we wish to add, more precisely,
on the position of the least significant one in its binary
representation: In the original proposal of Draper, the
*i*-th qubit in the summand’s register controls *S − i* + 1
rotations in the main register, where *S* is the size of the
main register. In the direct method, those *S − i+* 1 gates
are implemented if and only if the *i*-th qubit is in the
*|1⟩* state, that is if and only if the classical *i*-th bit is
one. We can see that the least significant one in the bit
string introduces the most rotation gates. As all rotations arising from higher bit positions are merged with
the rotations stemming from this least significant one, already giving the number of rotations in the pure addition
step. The number of states copied beforehand requires
one less qubit than the number of qubits acted on in the
addition step; the same amount of gates have to be applied after the addition in order to uncompute the ancilla
qubits.

$$
S-i+1
$$

$$
S-i+1
$$

For a given profit p<sub>m</sub>, let LSO(p<sub>m</sub>) denote the index/position of its least significant one; the gate count
for adding p<sub>m</sub> to the QFT-ed profit register is then given
by

$$
p_{m},
$$

$$
\mathrm{LSO}(p_m)
$$

$$
p_{m}
$$

$$
\mathbf{G}_{\operatorname{DIRECT}_{p_{m}}}=3(|P_{\operatorname{bin}}|-\operatorname{LSO}(p_{m}))+1.
$$

(S.19)

Including the QFT and its inverse in the overall gate
count for the additions, we obtain the following gate
count for the QFT adder which adds the number p<sub>m</sub> to
the profit register:

$$
p_{m}
$$

$$
\begin{aligned}{\mathbf{G}_{\operatorname{ADD}_{p_{m}}}}&{{}=2\mathbf{G}_{\operatorname{Q F T-P R O F I T}}+\mathbf{G}_{\operatorname{DIRECT}_{p_{m}}}}\\ {}&{{}=|P_{\operatorname{bin}}|(|P_{\operatorname{bin}}|+1)}\\ {}&{{}\quad+3(|P_{\operatorname{bin}}|-\operatorname{LSO}(p_{m}))+1.}\\ \end{aligned}
$$

(S.20)

In the QTG circuit, all the additions on the profit registers are consecutive (see Supplementary Figure 5) which
allows for cancelling the inverse QFT within ADD<sub>p</sub><sub>m</sub> and
the QFT in ADD<sub>p</sub><sub>m+1</sub> for all m = 1,...,n − 1. As a result, only one QFT and one inverse QFT are applied to
the profit register in total. The overall gate count for the
addition of all item profits therefore reads

$$
\mathrm{ADD}_{p_m}
$$

$$
\mathrm{ADD}_{p_{m+1}}^{\stackrel{\sim}{}}
$$

$$
m=1,\ldots,n-1
$$

$$
Q F\overset{...}{T}
$$

$$
\begin{aligned}\mathbf{G}_{\mathrm{ADD}_{p}}&=2\mathbf{G}_{\mathrm{QFT-PROFIT}}+\sum_{m=1}^{n}\mathbf{G}_{\mathrm{DIRECT}_{p_{m}}}\\&=|P_{\mathrm{bin}}|(|P_{\mathrm{bin}}|+1)\\&\quad+\sum_{m=1}^{n}(3(|P_{\mathrm{bin}}|-\mathrm{LSO}(p_{m}))+1).\end{aligned}
$$

(S.21)

---

| $\|x_{1}\rangle^{1}$ | $\|x_{1}\rangle^{1}$ |
| --- | --- |
| $\|x_{2}\rangle^{1}$ | $\|x_{2}\rangle^{1}$ |
| $\vdots$ |  |
| $\|x_{n}\rangle^{1}$ | $\|x_{n}\rangle^{1}$ |
| $\|0\rangle^{3}$ | $\|P_{n}\rangle^{3}$ |
| $\|0\rangle^{3}$ | $\|P_{n-1}\rangle^{3}$ |
| $\vdots$ |  |
| $\|0\rangle^{3}$ | $\|P_{2}\rangle^{3}$ |
| $\|0\rangle^{3}$ | $\|P_{1}\rangle^{3}$ |

|  | $\|x_1\|^1$ | $H'$ | $\|x_1\|^1$ | $\|x_2\|^1$ | $\|x_2\|^1$ |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| $\vdots$ |  |  | $\vdots$ |  |  |  |  |
| $\|x_{n-1}\|^1$ |  |  | $\|x_{n-1}\|^1$ |  |  |  |  |
| $\|x_n\|^1$ |  |  | $\|x_n\|^1$ |  |  |  |  |
| $\|c_n\|^2$ | COMP | QFT | DIRECT | QFT^{\dagger}$ | $DIRECT | QFT^{\dagger}$ | COMP |
| $\|c_{n-1}\|^2$ |  |  |  |  |  |  |  |
| $\vdots$ |  |  |  |  |  |  |  |
| $\|c_2\|^2$ |  |  |  |  |  |  |  |
| $\|c_1\|^2$ |  |  |  |  |  |  |  |

Supplementary Figure 5. a) The subcircuit performing all the profit additions. The profit register is QFT-ed in the beginning.
Subsequently, the respective item profits are added via the direct method. The controlled Ry gates and the weight subtraction
between the single additions are not depicted. After all item profits are added, the register is transformed back. b) The
subtraction circuit including the comparison part. The biasing Ry gates on the path register are controlled on the capacity
register by integer comparisons. After the comparison the item weights are subtracted from the capacity register, controlled on
the qubit just affected by the biasing Ry gate. Because of this alternating involvement of the capacity register, the intermediate
QFTs and their inverses do not cancel each other.

*Cycle count.* Due to the distributed control onto several ancilla qubits all rotational gates can be executed in
parallel. The control on the QFT and inverse QFT can
be dropped completely. The update of the ancilla qubits
as well as the reverse operation can be parallelised into
logarithmically many cycles, respectively. In summary,
we obtain here

$$
\begin{aligned}{\mathbf{C}_{\operatorname{ADD}_{\mathbf{p}}}}&{{}=2\mathbf{C}_{\operatorname{Q F T-P R O F I T}}}\\ {}&{{}\quad+\sum_{m=1}^{n}\big(2\lceil\log_{2}(|P_{\operatorname{bin}}|-\operatorname{LSO}(p_{m}))\rceil+1\big)}\\ {}&{{}=4|P_{\operatorname{bin}}|-2}\\ {}&{{}\quad+\sum_{m=1}^{n}\big(2\lceil\log_{2}(|P_{\operatorname{bin}}|-\operatorname{LSO}(p_{m}))\rceil+1\big).}\\ \end{aligned}
$$

(S.22)

## 4. QFT Subtractor

By flipping all the rotations’ signs, the QFT adder circuit can be used to subtract a given integer. Therefore,
adding and subtracting both yield the same gate count.

Gate count. For a given profit w<sub>m</sub>, let LSO(w<sub>m</sub>) denote its least significant one’s position; the gate count
for subtracting w<sub>m</sub> from the QFT-ed capacity register is
then given by

$$
w_{m}
$$

$$
\mathrm{LSO}(w_m)
$$

$$
w_{m}
$$

(S.23)

$$
\mathbf{G}_{\operatorname{DIRECT}_{w_{m}}}=3(|c_{\operatorname{bin}}|-\operatorname{LSO}(w_{m}))+1.
$$

Analogous to the QFT adder, including the QFT and
its inverse in the overall gate count for the subtractions,
we obtain the following gate count for the QFT subtractor which subtracts the number w<sub>m</sub> from the capacity
register

$$
w_{m}
$$

$$
\begin{aligned}{\mathbf{G}_{\operatorname{SUB}_{w_{m}}}}&{{}=2\mathbf{G}_{\operatorname{Q F T-C A P A C I T Y}}+\mathbf{G}_{\operatorname{DIRECT}_{w_{m}}}}\\ {}&{{}=|c_{\operatorname{bin}}|(|c_{\operatorname{bin}}|+1)}\\ {}&{{}\quad+3(|c_{\operatorname{bin}}|-\operatorname{LSO}(w_{m}))+1.}\\ \end{aligned}
$$

(S.24)

Unlike the profit additions, the weight subtractions in
the QTG circuit are followed by a comparison procedure, respectively, hence the intermediate QFT and inverse QFT do not cancel each other (see Supplementary
Figure 5). To reduce the number of gates, however, we
omit the last subtraction SUB<sub>w</sub><sub>n</sub>, because the capacity
register is not checked again after the last item inclusion.
All together, this leads to a total gate count of

$$
\mathrm{SUB}_{w_n}
$$

$$
\begin{aligned}{\mathbf{G}_{\operatorname{SUB}_{w}}}&{{}=2(n-1)\mathbf{G}_{\operatorname{Q F T-C A P A C I T Y}}+\sum_{m=1}^{n-1}\mathbf{G}_{\operatorname{DIRECT}_{w_{m}}}}\\ {}&{{}=(n-1)|c_{\operatorname{bin}}|(|c_{\operatorname{bin}}|+1)}\\ {}&{{}\quad+\sum_{m=1}^{n-1}(3(|c_{\operatorname{bin}}|-\operatorname{LSO}(w_{m}))+1).\quad(\operatorname{S.25})}\\ \end{aligned}
$$

(S.25)

*Cycle count.* In analogy to the QFT adder, we obtain
a total cycle count of

$$
\begin{aligned}{\mathbf{C}_{\operatorname{SUB}_{w}}}&{{}=2(n-1)\mathbf{C}_{\operatorname{Q F T-C A P A C I T Y}}}\\ {}&{{}\quad+\sum_{m=1}^{n-1}\big(2\lceil\log_{2}(|c_{\operatorname{bin}}|-\operatorname{LSO}(w_{m}))\rceil+1\big)}\\ {}&{{}=4(n-1)|c_{\operatorname{bin}}|-2(n-1)}\\ {}&{{}\quad+\sum_{m=1}^{n-1}\big(2\lceil\log_{2}(|c_{\operatorname{bin}}|-\operatorname{LSO}(w_{m}))\rceil+1\big).}\\ \end{aligned}
$$

(S.26)

## 5. Comparison

Within the QTG-based search, there are three subcircuits requiring the comparison of two integers: First, the
biasing Ry gates within the QTG should only be executed
if the remaining capacity in the second register is at least
as large as the respective item weight. Therefore, we have
to implement the integer comparisons “c˜≥ w<sub>m</sub>” with unknown c˜, but known w<sub>m</sub>, m = 1,...,n − 1. Second,

$$
``\tilde{c}\geq w_{m}''
$$

$$
w_{m},m=1,\ldots,n-1
$$

---

| $\|q_1\rangle$ | $\|q_2\rangle$ | $\|q_3\rangle$ | $\|q_4\rangle$ | $\|q_5\rangle$ | $\|q_6\rangle$ | $\|q_7\rangle$ |
| --- | --- | --- | --- | --- | --- | --- |
| $\|0\rangle_a$ | $\|0\rangle_a$ | $\|0\rangle_a$ | $\|0\rangle_a$ | $\|0\rangle_a$ | $\|0\rangle_a$ | $\|0\rangle_a$ |
| $\|t\rangle$ | $U$ |  |  |  |  |  |

Supplementary Figure 6. The optimal decomposition of a
7-qubit-controlled unitary *U.* In contrast to the standard decomposition method (see [9])which lacks gate parallelisation,
our approach reduces the cycle count from 13 to 7 .

the Amplitude Amplification operator *Q* contains the reflection *S<sub>0</sub>,* which flips the ancilla qubit’s state if and
only if the path register is in the |0⟩<sup>1</sup> state. Third, the
threshold-dependent phase oracle within the Amplitude
Amplification operator flips the ancilla state, if and only
if the third register enables a profit larger than the current threshold. That is, for known thresholds *T* and unknown *p,* we have to implement the comparisons “*p >* T”.

$$
\mathcal{S}_{0}
$$

$$
\left|\mathbf{0}\right\rangle^{1}
$$

$$
``p>T''
$$

We realise all the above operations as multi-controlled
single-target gates. In Supplementary Figure 6 we provide an example of the optimal decomposition of a multicontrolled unitary *U.* The control circuit is derived from
the classical digital comparator [10]: Given two binary
represented integers a = a<sub>ℓ</sub>...a<sub>1</sub> and b = b<sub>ℓ</sub>...b<sub>1</sub>, introduce the Boolean variables

$$
a=a_{\ell}\ldots a_{1}
$$

$$
b=b_{\ell}\ldots b_{1}
$$

$$
c_{i}:=a_{i}b_{i}\vee\overline{{a}}_{i}\overline{{b}}_{i},
$$

(S.27)

which are 1 if and only if a<sub>i</sub> = b<sub>i</sub>, respectively. Then
equality and strict inequalities in both directions can be
expressed as

$$
a_{i}=b_{i},
$$

$$
(a=b)=\bigwedge_{i=1}^{\ell}c_{i},
$$

(S.28)

(S.29)

$$
(a>b)=\bigvee_{i=1}^{\ell}\bigg(a_{i}\overline{{b}}_{i}\bigwedge_{j=i+1}^{\ell}c_{j}\bigg),
$$

(S.30)

$$
(a<b)=\bigvee_{i=1}^{\ell}\bigg(\overline{{a}}_{i}b_{i}\bigwedge_{j=i+1}^{\ell}c_{j}\bigg).
$$

If the integer *b* is known, the variables (S.27) can be
reduced to a single literal, leaving (S.28)–(S.30) in orthogonal disjunctive normal form (ODNF). In addition,

for (a > b) only those clauses contribute for which b<sub>i</sub> is
1, i.e., b<sub>i</sub> is 0. Analogously, for (a < b) only those clauses
contribute for which b<sub>i</sub> is 1.

$$
(a>b)
$$

$$
b_{i}
$$

$$
\overline{b}_{i}
$$

$$
\left(a<b\right)
$$

$$
b_{i}
$$

There are now two possibilities when implementing an
operation *U* which is controlled by a Boolean expression.

1. *U* is applied if and only if the Boolean expression
is fulfilled.

2. *U* is first applied unconditionally. Then its inverse
is applied if and only if the Boolean expression is
not fulfilled.

In any case, an ODNF that is checked for is beneficial as
its quantisation is straightforward: Each clause *C* translates into a multi-controlled-U (resp. U<sup>−1</sup>) where the control runs over all the qubits representing Boolean variables in *C.* If the classical literal is positive, we control
on whether the corresponding qubit is in the *|1⟩* state,
otherwise whether it is in the *|0⟩* state. Because we assume an ODNF, we can ensure that U (resp. U<sup>−1</sup>) is applied at most once when translating all the clauses into
consecutive multi-controlled operations.

$$
U^{-1})
$$

$$
U^{-1})
$$

Gate count. For a given item weight w<sub>m</sub>, we can
now calculate the gate count for implementing the multicontrolled Ry gate C<sup>2</sup>≥w<sub>m</sub>(H<sup>x</sup><sub>b</sub> <sup>m</sup>). Following the first strategy of applying H<sup>x</sup><sub>b</sub> <sup>m</sup> if and only if the remaining capacity
covers w<sub>m</sub> (that is if c > w ˜ <sub>m</sub> − 1) and assuming (i) as
well as (iii), we obtain the count

$$
w_{m}
$$

$$
C_{\geq w_{m}}^{2}(\mathrm{H}_{b}^{x_{m}})
$$

$$
\mathrm{H}_{b}^{x_{m}}
$$

$$
w_{m}
$$

$$
\tilde{c}>w_m-1)
$$

$$
\mathbf{G}_{\geq w_{m}}^{(1)}=\sum_{i=1}^{|w_{m_{\operatorname{bin}}}|}(1-(w_{m}-1)_{i})(2(|c_{\operatorname{bin}}|-i)+1).
$$

(S.31)

This implementation is favourable for weights w<sub>m</sub> with
comparatively many ones in the less significant bits of the
binary representation of the number w<sub>m</sub> − 1. Alternatively, following the second strategy, H<sup>x</sup><sub>b</sub> <sup>m</sup> is first applied
unconditionally (adding one to the gate count); then its
inverse is applied if and only if the remaining capacity is
strictly smaller than w<sub>m</sub>. Again assuming (i) and (iii),
this yields a total gate count of

$$
w_{m}
$$

$$
w_{m}-1
$$

$$
\mathrm{H}_{b}^{x_{m}}
$$

$$
w_{m}
$$

$$
\mathbf{G}_{\geq w_{m}}^{(2)}=1+\sum_{i=1}^{|w_{m_{\mathrm{bin}}}|}(w_{m})_{i}(2(|c_{\mathrm{bin}}|-i)+1).
$$

(S.32)

For the concrete circuit construction, we can then simply pick the implementation that requires fewer gates,
i.e.,

$$
\mathbf{G}_{\geq w_{m}}=\operatorname*{m i n}\left(\mathbf{G}_{\geq w_{m}}^{(1)},\mathbf{G}_{\geq w_{m}}^{(2)}\right).
$$

(S.33)

The implementation of the reflection *S<sub>0</sub>* is even more
straightforward: We simply have to check whether the
path register is in the state |0⟩<sup>1</sup> and control the ancilla
flip on the outcome. According to (i) and (iii), this yields
a gate count of

$$
\mathcal{S}_{0}
$$

$$
\left|\mathbf{0}\right\rangle^{1}
$$

$$
\mathbf{G}_{=0}=2n-1.
$$

(S.34)

---

Lastly, the phase oracle is also realised as a singlequbit operation controlled on the truth value of a Boolean
expression. The derivation of the gate count follows the
same construction as for the multi-controlled Ry gate,
with the only exception being that the phase oracle asks
for a strict inequality “*p >* T”. Hence we obtain

$$
``p>T''
$$

$$
\mathbf{G}_{>T}^{(1)}=\sum_{i=1}^{|T_{\mathrm{bin}}|}(1-(T)_{i})(2(|P_{\mathrm{bin}}|-i)+1),
$$

(S.35)

$$
\mathbf{G}_{>T}^{(2)}=1+\sum_{i=1}^{|T_{\operatorname{bin}}|}(T+1)_{i}(2(|P_{\operatorname{bin}}|-i)+1),
$$

(S.36)

$$
\mathbf{G}_{>T}=\min\left(\mathbf{G}_{>T}^{(1)},\mathbf{G}_{>T}^{(2)}\right).
$$

(S.37)

*Cycle count.* Via the parallelised decomposition of
multi-controlled gates exemplified in Supplementary Figure 6, the respective cycle counts improve logarithmically
over the gate counts. More precisely, we obtain

$$
\mathbf{C}_{\geq w_{m}}^{(1)}=\sum_{i=1}^{\left|w_{m\text{bin}}\right|}(1-(w_{m}-1)_{i})(2\left\lceil\log_{2}(\left|c_{\text{bin}}\right|-i)\right\rceil+1)
$$

(S.38)

for the first comparison strategy,

$$
\mathbf{C}_{\geq w_{m}}^{(2)}=1+\sum_{i=1}^{|w_{m\operatorname{bin}}|}(w_{m}-1)_{i}(2\lceil\log_{2}(|c_{\operatorname{bin}}|-i)\rceil+1)
$$

(S.39)

for the second comparison method, and thus lastly

$$
\mathbf{C}_{\geq w_{m}}=\operatorname*{m i n}\left(\mathbf{C}_{\geq w_{m}}^{(1)},\mathbf{C}_{\geq w_{m}}^{(2)}\right).
$$

(S.40)

Meanwhile, the cycle cost for the reflection circuit *S<sub>0</sub>*
computes to

$$
\mathcal{S}_{0}
$$

$$
\hat{C}_{=0}=2\left\lceil\log_{2}(n-1)\right\rceil+1.
$$

(S.41)

For the phase oracle, we also list both implementation
strategies together with their corresponding cycle count:

$$
\mathbf{C}_{>T}^{(1)}=\sum_{i=1}^{|T_{\operatorname{bin}}|}(1-(T)_{i})(2(\lceil\log_{2}(|P_{\operatorname{bin}}|-i)\rceil+1),
$$

(S.42)

$$
\mathbf{C}_{>T}^{(2)}=1+\sum_{i=1}^{|T_{\mathrm{bin}}|}(T+1)_i(2\lceil\log_2(\lceil|P_{\mathrm{bin}}|-i)\rceil+1),
$$

(S.43)

$$
\begin{array}{r}{\mathbf{C}_{>T}=\operatorname*{m i n}\left(\mathbf{C}_{>T}^{(1)},\mathbf{C}_{>T}^{(2)}\right).}\\ {\mathbf{\underline{{\theta}}}.\quad\mathbf{Q}^{}{T}\mathbf{G}}\end{array}
$$

(S.44)

After having detailed the resource estimations for all
crucial subcircuits, we discuss now the overall gate and
cycle count for the entire QTG. We assume here the more
resource-efficient version of the QTG that does not contain the last capacity update U<sub>n</sub><sup>2</sup>. Furthermore, because
the ancilla qubits are used for controlling both the subtractions in the capacity register and the additions in the
profit register, we may fuse the copy processes (and their
inverses) that are used before applying the arithmetic rotation gates. The gate and cycle count then is dominated
by the operation that demands more rotations.

$$
U_{n}^{2}
$$

*Gate count.* The total gate count for QTG arises as
the sum of the gates counts for the *n* controlled Ry gates
U<sup>1</sup><sub>m</sub> and for the capacity/profit updates with their copying steps merged as already mentioned.

$$
U_{m}^{1}
$$

$$
\begin{aligned}{\mathbf{G}_{\operatorname{QTG}}}&{{}=\sum_{m=1}^{n}\mathbf{G}_{\geq w_{m}}+2\mathbf{G}_{\operatorname{Q F T-P R O F I T}}+2(n-1)\mathbf{G}_{\operatorname{Q F T-C A P A C I T Y}}}\\ {}&{{}\quad+2\sum_{m=1}^{n-1}\big(\operatorname*{m a x}(|P_{\operatorname{bin}}|,|c_{\operatorname{bin}}|)-\operatorname*{m i n}(\operatorname{LSO}(p_{m}),\operatorname{LSO}(w_{m}))\big)+2(|P_{\operatorname{bin}}|-\operatorname{LSO}(p_{n}))}\\ {}&{{}\quad+\sum_{m=1}^{n-1}\big(|P_{\operatorname{bin}}|-\operatorname{LSO}(p_{m})+|c_{\operatorname{bin}}|-\operatorname{LSO}(w_{m})+2\big)+|P_{\operatorname{bin}}|-\operatorname{LSO}(p_{n})+1.}\\ \end{aligned}
$$

(S.45)

*Cycle count.* Up to this point, we have explored various methodologies to optimise the efficiency of gate and
cycle counts for each component of the QTG. Now our
focus shifts towards improving its overall cycle count. We
take into account the following considerations:

I. Copying qubit information from the path register

into the ancilla register as well as the reversed operation can both be run in parallel with all the QFT<sub>c</sub>
and QFT<sup>†</sup><sub>c</sub> on the capacity register.

$$
\mathrm{QFT}_{\mathrm{c}}^{\dagger}
$$

$$
\mathrm{QFT_{c}}
$$

II. The number of cycles within the QFT<sub>c</sub> (logarithmic
in *c*) always exceeds the number of cycles involved
in copying the control qubit onto the ancilla qubits

$$
\mathrm{QFT_{c}}
$$

$$
c)
$$

---

(doubly-logarithmic in *c* and P).

III. The QFT<sub>p</sub> on the profit register can be run in parallel with all the gates in the capacity register, as
it does not involve any controlled operations.

$$
\mathrm{QFT_{p}}
$$

Our first observation is, however, that the different layers U<sub>m</sub> = U<sup>3</sup><sub>m</sub>U<sup>2</sup><sub>m</sub>U<sup>1</sup><sub>m</sub> have to be executed mutually disjointly as the subtraction in U<sup>2</sup><sub>m</sub> and the addition in U<sup>3</sup><sub>m</sub>
are controlled by the qubits that the biasing Ry gates in
U<sup>1</sup><sub>m</sub> act on. Therefore, no components commute across
different layers, and we obtain

$$
U_{m}=U_{m}^{3}U_{m}^{2}U_{m}^{1}
$$

$$
U_{m}^{2}
$$

$$
U_{m}^{3}
$$

$$
U_{m}^{1}
$$

$$
\mathbf{C}_{\mathrm{QTG}}=\sum_{m=1}^{n}\mathbf{C}_{m},
$$

(S.46)

where C<sub>m</sub> denotes the cycle count per layer unitary
U<sub>m</sub>. Furthermore, there cannot be any parallelisation
between U<sup>1</sup><sub>m</sub> and the rest of the layer; though other parallelisation techniques are definitely applicable.

$$
\mathbf{C}_{m}
$$

$$
U_{m}
$$

$$
U_{m}^{1}
$$

In the first layer we parallelise, according to III, QFT<sub>p</sub>
and QFT<sub>c</sub> as much as possible. Due to I and II, we
can also fit in the subcircuit copying the control qubit’s
information on the ancilla register. If |P<sub>bin</sub>| > |c<sub>bin</sub>|,
meaning that the CQFT-PROFIT > CQFT-CAPACITY, we
can absorb the subtraction cycle, again due to III, into
the profit QFT. The remaining addition cycle as well as
uncomputing the ancilla qubits can be absorbed into the
subsequent QFT<sup>†</sup><sub>c</sub>. In this first case we obtain

$$
\mathrm{QFT}_{p}
$$

$$
\mathrm{QFT}_{c}
$$

$$
|P_{\mathrm{bin}}|>|c_{\mathrm{bin}}|,
$$

$$
\mathbf{C}_{1}^{(1)}=\mathbf{C}_{\geq w_{1}}+\mathbf{C}_{QFT-CAPACITY}+\mathbf{C}_{QFT-PROFIT_{/Q}}
$$

(S.47)

Otherwise the subtraction cycle has to be carried out
unparallelised, yielding

$$
\mathbf{C}_{1}^{(2)}=\mathbf{C}_{\geq w_{1}}+2\mathbf{C}_{QFT-CAPACITY}+1.
$$

(S.48)

The other layer unitaries, except for the last one, are
similarly constructed, but do not include any (inverse)
QFT on the profit register. In terms of cycles we are
thus in the same situation as (S.48), that is

$$
\mathbf{C}_{m}=\mathbf{C}_{\geq w_{m}}+2\mathbf{C}_{\operatorname{Q F T-C A P A C I T Y}}+1.
$$

(S.49)

The last layer unitary contains the inverse QFT for the
profit register, but no weight subtraction in the capacity
register. Here, the copy subcircuit as well as the addition cycle cannot be executed in parallel with any other
operation. Therefore, we obtain

(S.50)

$$
\begin{aligned}\mathbf{C}_{n}&=\mathbf{C}_{\geq w_{n}}+\lceil\log_{2}(|P_{bin}|-LSO(p_{n}))\rceil\\&\quad+\mathbf{C}_{QFT-PROFIT}+1.\end{aligned}
$$

## 7. QMaxSearch

In contrast to the QTG whose gate and cycle count can
be determined in advance the QMaxSearch routine has

to be simulated to infer its total resource requirement. In
order to derive a symbolic expression we assume that a
run of QMaxSearch produces a sequence (T<sub>k</sub>)<sup>R</sup><sub>k</sub>=1of intermediate thresholds with *T<sub>1</sub>* being the result of Integer
Greedy. The search method is therefore not able to find
a better total profit than *TR* which might indicate that
an optimal solution has been found. For each of these
thresholds T<sub>k</sub>, QSearch is executed, incorporating the
comparison “P<sub>x</sub> > T<sub>k</sub>” as phase oracle. Within a given
instance of QSearch a sequence (j<sub>ℓ</sub><sup>(k)</sup>)<sup>S(k)</sup><sub>ℓ</sub> of powers is
=1
constructed such that the termination condition

$$
(T_{k})_{k=1}^{R}
$$

$$
T_{1}
$$

$$
T_{R}
$$

$$
T_{k}
$$

$$
``\dot{P}_{x}>T_{k}''
$$

$$
(j_{\ell}^{(k)})_{\ell=1}^{S(k)}
$$

$$
\sum_{\ell=1}^{S(R)-1}2j_{\ell}^{(R)}+1<M\leq\sum_{\ell=1}^{S(R)}2j_{\ell}^{(R)}+1.
$$

(S.51)

holds in the last application of QSearch. For all prior
iterations the termination condition is never triggered,
because an improved threshold is found, respectively.

*Gate count.* From the knowledge about the threshold
T<sub>k</sub> and the corresponding power sequence we can now determine the gate count of the *k*-th iteration of QSearch:
Before applying *Q* with a given power *j* the QTG is applied once to create the initial superposition of feasible
states. The definition (S.6) of the Amplitude Amplification operator immediately gives rise to its gate count

$$
T_{k}
$$

$$
\mathrm{G}_{Q_k}=2\mathrm{G}_{\mathrm{QTG}}+\mathrm{G}_{=0}+\mathrm{G}_{>T_k}.
$$

Multiplying the latter with the respective power and
summing over all powers we obtain for the *k*-th iteration
of QSearch a gate count of

(S.52)

$$
\mathbf{G}_{\operatorname{QSearch}_{k}}=\sum_{\ell=1}^{S(k)}(2j_{\ell}^{(k)}+1)\mathbf{G}_{\operatorname{QTG}}+j_{\ell}^{(k)}(\mathbf{G}_{=0}+\mathbf{G}_{>T_{k}}).
$$

(S.53)

The total gate count of QMaxSearch is then given
by

$$
\mathbf{G}_{\mathrm{QMaxSearch}}=\sum_{k=1}^{R}\mathbf{G}_{\mathrm{QSearch}_k}.
$$

(S.54)

Cycle count. Because the operators S<sub>0</sub> and S<sub>P</sub><sub>x</sub>>T<sub>k</sub>
are controlled on the profit register’s qubits no further
parallelisation within *Q* is possible. Therefore, we obtain
for the QSearch cycle count

$$
\mathcal{S}_{0}
$$

$$
\mathcal{S}_{P_{\mathbf{x}}>T_{k}}
$$

$$
\mathbf{C}_{\mathrm{QSearch}_{k}}=\sum_{\ell=1}^{S(k)}(2j_{\ell}^{(k)}+1)\mathbf{C}_{\mathrm{QTG}}+j_{\ell}^{(k)}\left(\mathbf{C}_{=0}+\mathbf{C}_{>T_{k}}\right)
$$

(S.55)

and, analogously, for the final cycle count of the entire
QMaxSearch routine

$$
\mathbf{C}_{\mathrm{QMaxSearch}}=\sum_{k=1}^{R}\mathbf{C}_{\mathrm{QSearch}_k}.
$$

(S.56)

---

The formula (S.56) is precisely what is being used for
calculated the elapsed quantum cycles in Figure 3.

## F. Benchmarking of competitive quantum methods

This section contains a brief overview and runtime estimations of the nested quantum search [11] and quantum
branch-and-bound [12, 13] algorithms, together with our
benchmarking reasoning.

## 1. Nested Quantum Search

Nested quantum search (NQS) is a nested version of
Grover’s algorithm specifically tailored to constraint satisfaction problems, where the search Hilbert space is decomposed into two factors H<sub>S</sub> = H<sub>A</sub> ⊗H<sub>B</sub>, corresponding to a decomposition S = A *∪* B of the set of classical
variables. The algorithm itself is a variant of QSearch,
where the superposition-creating unitary *A* consists of
the following two steps:

$$
\mathcal{H}_{\mathrm{S}}=\mathcal{H}_{\mathrm{A}}\otimes\mathcal{H}_{\mathrm{B}}
$$

$$
S=A\cup B
$$

1. Grover’s search in the first tensor factor H<sub>A</sub> to
(nearly) obtain a uniform superposition of *could-be*
solutions, i.e. partial assignments (only variables
in A are assigned) that fulfill all constraints that
are testable on these variables. Accordingly, these
are precisely the partial assignments that *could be*
extended to a full solution of the problem. The employed oracle checks whether a partial assignment
is a could-be solution and is assumed to only act
on H<sub>A</sub>.

$$
\mathcal{H}_{\mathrm{A}}
$$

$$
\mathcal{H}_{\mathrm{A}}
$$

2. Subsequent Grover’s search on the second tensor
factor H<sub>B</sub>, but with an oracle that acts on the entire
space H<sub>S</sub> and marks full (and not partial) solutions.

$$
\mathcal{H}_{\mathrm{B}},
$$

$$
\mathcal{H}_{\mathrm{S}}
$$

The first step of NQS creates a superposition of all,
say t<sub>A</sub>, could-be solutions plus a vanishing amount of
√
non could-be solutions; this step involves ∼ 2|<sup>A</sup>|/t<sub>A</sub>
Grover iterations. Second, assume that each could-be
solution gives rise to at most one full solution and let
t<sub>B</sub> ∈ [0,1] be the average number of full solutions per
partial solution. Then the total number of solutions is
given by t<sub>AB</sub> = t<sub>A</sub>t<sub>B</sub> ≤ t<sub>A</sub>. Executing the second step
produces a superposition of all solutions with amplitude
*√*
∼ 1 t<sub>A</sub> and all infeasible solutions, which extend from
could-be solutions that did not give rise to any solution,
√
with amplitude ∼ 1/ t<sub>A</sub>2|<sup>B</sup>|, plus a vanishing amount
√
of other infeasible solutions after ∼ 2|<sup>B</sup>|/t<sub>B</sub> steps. The
total number of Grover iterations per state preparation
is

$$
t_{\mathrm{A}}
$$

$$
\sim\sqrt{2^{|A|}/t_{A}}
$$

$$
t_{\mathrm{B}}\in[0,\stackrel{\mathrm{e}}{1}]
$$

$$
t_{\mathrm{AB}}=t_{\mathrm{A}}t_{\mathrm{B}}\leq t_{\mathrm{A}}
$$

$$
\sim1\sqrt{t_{A}}
$$

$$
\sim1/\sqrt{t_{A}2^{|B|}}
$$

$$
\sim\sqrt{2^{|B|}/t_{B}}
$$

$$
T\sim\sqrt{2^{|\mathrm{A}|}/t_{A}}+\sqrt{2^{|\mathrm{B}|}/t_{B}}.
$$

Because there are now t<sub>AB</sub> solution states each having
*√*
an amplitude of ∼ 1/ t<sub>A</sub>, they can be amplified to yield
√
a positive outcome upon measuring after ∼ t<sub>A</sub>/t<sub>AB</sub>
iterations within QSearch. In total this yields

$$
t_{AB}
$$

$$
\sim1/\sqrt{t_{A}}
$$

$$
\sim\sqrt{t_{A}/t_{AB}}
$$

$$
T_{\mathrm{{\bf NQS}}}=T\sqrt{t_{\mathrm{A}}/t_{\mathrm{AB}}}\sim\sqrt{2^{|\mathrm{A}|}/(t_{\mathrm{A}}t_{\mathrm{B}})}+\sqrt{2^{|\mathrm{B}|}}.
$$

(S.57)

Grover iterations.

NQS can also be used for constrained optimisation
problems by employing it as a feasible state preparation
subroutine (i.e. the measurement is omitted), on top of
which QMaxSearch is executed. For the KP, we can
utilise the constraint checking techniques from the QTG
also within NQS. To derive the trend of Grover iterations required to find an optimum, we first find the best
decomposition of the *n* decision variables into variable
sets A and B: Following [14], we define a *break item*

$$
h=\max\left\{m':\sum_{m=1}^{m'}w_{m'}\leq c\right\},
$$

(S.58)

where every partial assignment up to this item is
feasible. The first set of variables will be A =
*{1,...,h,...,h* + *k}* with 0 *≤ k ≤ n − h}* yet to
be determined; accordingly, B will be given as B =
*{h+ k* + *1,...,n}.* Furthermore, note that every feasible
partial assignment can always be extended to a feasible
full assignment and that any lower bound on the number of feasible solutions also gives a lower bound on the
runtime of QMaxSearch as fewer elements have to be
searched through for the optimum. Thus, assuming that
each partial assignment has exactly one feasible solution
and therefore that t<sub>B</sub> = 1 and t<sub>AB</sub> = t<sub>A</sub> gives an optimistic lower bound on the runtime of QMaxSearch.

$$
\left\{1,\ldots,\mathit{h},\ldots,\mathit{h}\text{+}\mathit{k}\right\}
$$

$$
A\quad=
0\leq k\leq n-h
$$

$$
B=
\{h+k+1,\ldots,n\}
$$

$$
t_{\mathrm{B}}=1
$$

$$
t_{\mathrm{AB}}=t_{\mathrm{A}}
$$

Using our assumption and the structure of A and B,
(S.57) gives rise to an NQS-runtime of

$$
T_{\mathbf{NQS}}\sim\sqrt{2^{h+k}/2^{h}}+\sqrt{2^{n-h-k}}=\sqrt{2^{k}}+\sqrt{2^{n-h-k}}
$$

This produces an equal superposition of 2<sup>h</sup> feasible solutions upon which we now have to find the maximum
*√*
which therefore requires ∼ 2<sup>h</sup> iterations of NQS within
QMaxSearch, yielding a total number of Grover iterations

$$
2^{h}
$$

$$
\sim\sqrt{2^{h}}
$$

$$
T_{\mathrm{NQS}}\sqrt{2^{h}}\sim\sqrt{2^{h+k}}+\sqrt{2^{n-k}}.
$$

This expression is minimal for k = <sup>n−h</sup>, leading to a
2
number of Grover iterations of order

$$
k=\frac{n-h}{2}
$$

$$
\sqrt{2^{(n+h)/2}}+\sqrt{2^{n-h-(n-h)/2}}=2^{(n+h)/4}.
$$

(S.59)

It is important to notice that setting t<sub>B</sub> = 1 is a very
strong assumption (it makes the 0-1-KP instance trivial),
and we use it only to gain insights into the performance
of NQS. The benchmark results on real instances are
presented in Supplementary Figure 7.

$$
t_{\mathrm{B}}=1
$$

---

**QTG QTG non-biased**

| size | QTG | QTG non-biased | Grover | Nested Q Search |
| --- | --- | --- | --- | --- |
| 100 | 2 | 4 | 10000000000 | 7000000000 |
| 200 | 2 | 12 | 300000000000 | 140000000000 |
| 300 | 2 | 22 | 10000000000000 | 2600000000000 |
| 400 | 2 | 30 | 1000000000000000 | 42000000000000 |
| 500 | 2 | 40 | 100000000000000000 | 550000000000000 |
| 600 | 2 | 50 | 1000000000000000000000 | 600000000000000000 |

Supplementary Figure 7. Comparison between the number
of Grover iterations required by QTG-based search with and
without bias, Grover’s algorithm, and NQS. We observe that
the number of Grover iterations is almost constant for the
biased QTG-based search. For the other methods, we have a
linear increase with the problem size: for Grover’s search for
problems of size 400 the algorithm already requires more than
10<sup>50</sup> oracle calls; non-biased QTG-based search and NQS
perform better, but still requiring more than 10<sup>20</sup> oracle calls.
Interestingly, the optimistic lower bound on the runtime of
NQS seems to match the worst-case behaviour of the nonbiased QTG-based search.

$$
\overset{\cdot}{1}0^{50}
$$

$$
10^{20}
$$

## 2. Quantum branch-and-bound

Quantum branch-and-bound (QBnB) [12, 13] is one of
the most promising candidates for solving ILPs, having a
provable worst-case asymptotic near-quadratic speedup
over its classical counterpart. The near-quadratic speedup is achieved by using quantum walks [15] on the tree
explored by the classical algorithm. The method has two
main ingredients:

1. Quantum tree size estimation [16] to get an upper
bound on the size of the tree. This implementation
shows how to get a quadratic improvement over a
classical backtracking algorithm which evaluates *T*
nodes of a search tree.

$$
T
$$

2. Quantum tree search [15] to return the label of
the marked node if the tree contains at least one
marked node, or “not found” if there is no marked
node.

In general, the QBnB routine requires multiple applications of quantum tree size estimation and quantum tree
search. At the core of these subroutines lies quantum
backtracking [16–18]. In the following, we give an optimistic runtime estimation of the QBnB method. We
benchmark the QBnB for the 0-1-KP under the following assumptions:

1. The optimal solution and the respective tree size *T*
are known, hence quantum tree size estimation has
to be applied only once.

2. The success probability of the quantum subroutines
is 1.

3. The most expensive part of the algorithm is the
backtracking, hence we consider all the other quantum subroutines to be queried once.

In general, in order to find the optimal solution, the
*√*
expected number of oracles calls is at least *Tn,* where
*T* represents the number of nodes that are actually explored by the corresponding classical BnB algorithm, and
*n* is the number of items. To justify this value, we give
a summary of the backtracking algorithm together with
our reasoning. Consider a rooted tree with *T* vertices
*r,1,...,T −* 1, where *r* is the root. *A* denotes the set
of vertices at an even distance from *r,* and *B* the set of
vertices at an odd distance from *r. x → y* signifies that
*y* is a child of *x* in the tree. The quantum walk operates
in the space spanned by *{|x⟩* : *x ∈ {r,1,...,T − 1}}*
and starts in the state *|r⟩.* This quantum walk utilises
a set of diffusion operators D<sub>x</sub>, where D<sub>x</sub> is the identity
operator if *x* is a solution; otherwise, it diffuses on the
subspace spanned by *{|x⟩}∪{|y⟩* : *x → y}.* A step of
the quantum walk involves applying the operator R<sub>B</sub>R<sub>A</sub>,
where

$$
\sqrt{T n}
$$

$$
r,1,\ldots,T-1
$$

$$
r,
$$

$$
x\to y
$$

$$
x\in\{r,1,\ldots,T-1\}
$$

$$
|r\rangle
$$

$$
D_{x},
$$

$$
D_{x}
$$

$$
\{|x\rangle\}\cup\{|y\rangle\;:\;x\to y\}
$$

$$
R_{B}R_{A}
$$

$$
R_{A}=\bigoplus_{x\in A}D_{x}\mathrm{and}|r\rangle\langle r|+R_{B}=\bigoplus_{x\in B}D_{x}.
$$

Using these operators, a marked vertex is detected, because the phase estimation operator R<sub>B</sub>R<sub>A</sub> enables the
traversing of paths leading to a solution in the tree. According to [17] the operator *RB RA* is applied to precision
*β/√Tn.*

$$
R_{B}R_{A}
$$

$$
R_{B}R_{A}
$$

$$
\beta/\sqrt{T n}
$$

For our benchmarking results, we assume that *β* = 1,
implying that the application of the phase estimation op-
*√*
erator has to be applied exactly *Tn* times. We execute
the classical algorithm and record the tree size *T.*

$$
\beta=1
$$

$$
\sqrt{T n}
$$

Within the BnB routine, we use the commonly used
upper bound heuristic *Fractional Greedy* [19] which, similar to (Integer) Greedy, sorts all items by decreasing density and then greedily packs items into the knapsack until
an item does not fit into the knapsack (by definition the
successor of the break item h). It then returns the sum
of all the profits of contained items plus the profit of the
fraction of the item that could be included additionally,
i.e.

$$
\sum_{m=1}^{h}p_{m}+p_{h+1}\frac{c-\sum_{m=1}^{h}w_{m}}{w_{h+1}}.
$$

Because this routine is very similar to the (Integer)
Greedy method, all the previous calculations for the cycle
count of the QTG circuit can be used to calculate the
costliness of the quantum implementation of Fractional
Greedy.

## REFERENCES

<sup>1</sup>J. Jooken, P. Leyman, and P. De Causmaecker, Eur. J.
Oper. Res. 301, 841 (2022).

---

<sup>2</sup>L. K. Grover, A fast quantum mechanical algorithm for
database search (1996), quant-ph/9605043.

<sup>3</sup>M. Boyer, G. Brassard, P. Høyer, and A. Tapp, Fortschr.
Physik 46, 493 (1998).

<sup>4</sup>G. Brassard, P. Høyer, M. Mosca, and A. Tapp, Commun.
Contemp. Math. , 53 (2002).

<sup>5</sup>M. Smelyanskiy, N. P. D. Sawaya, and A. Aspuru-Guzik,
qHiPSTER: The Quantum High Performance Software
Testing Environment (2016), 1601.07195 [quant-ph].

<sup>6</sup>M. Matsumoto and T. Nishimura, ACM Trans. Model.
Comput. Simul. 8, 3–30 (1998).

<sup>7</sup>D. Coppersmith, An approximate Fourier transform useful in quantum factoring (2002), arXiv:quant-ph/0201067
[quant-ph].

<sup>8</sup>T. G. Draper, Addition on a Quantum Computer (2000),
arXiv:quant-ph/0008033 [quant-ph].

<sup>9</sup>M. A. Nielsen and I. L. Chuang, *Quantum Computation and
Quantum Information: 10th Anniversary Edition,* 10th ed.
(Cambridge University Press, USA, 2011).

<sup>10</sup>M. D. Ercegovac and T. Lang, *Digital Arithmetic* (Elsevier,

2004).

<sup>11</sup>N. J. Cerf, L. K. Grover, and C. P. Williams, Phys. Rev. A
61, 032303 (2000).

<sup>12</sup>A. Montanaro, Phys. Rev. Res. 2, 013056 (2020).

<sup>13</sup>S. Chakrabarti, P. Minssen, R. Yalovetzky, and M. Pistoia, Universal Quantum Speedup for Branch-and-Bound,
Branch-and-Cut, and Tree-Search Algorithms (2022),
2210.03210 [quant-ph].

<sup>14</sup>D. Pisinger, Comput. Oper. Res. 32, 2271 (2005).

<sup>15</sup>S. Apers, A. Gilyén, and S. Jeffery, A unified framework of
quantum walk search (2019), arXiv:1912.04233 [quant-ph].

<sup>16</sup>A. Ambainis and M. Kokainis, in *Proceedings of the 49th
Annual ACM SIGACT Symposium on Theory of Computing,* STOC ’17 (ACM, 2017).

<sup>17</sup>A. Montanaro, Theory Comput. 14, 1 (2018).

<sup>18</sup>S. Martiel and M. Remaud, Practical implementation of a
quantum backtracking algorithm (2020).

<sup>19</sup>H. Kellerer, U. Pferschy, and D. Pisinger, *Knapsack Problems* (Springer, 2004).